import com.fischmacro.*;
import java.util.Random;
import java.util.ArrayDeque;

/** The reel controller alone: perfect measurements, true physics, input delay. No vision. */
public class CtlTest {
    static boolean HIDE = Boolean.getBoolean("hide");
    static double mA = 1, mG = 1, mD = 1, mL = 0.02;
    static double run(long seed, double A, double G, double D, double latS, boolean learn, double fishMul, double sens, boolean stunTest) {
        Random rnd = new Random(seed);
        ReelController ctl = new ReelController();
        ctl.hiddenPull = Double.parseDouble(System.getProperty("hp", "0.12")); ctl.hiddenVf = Double.parseDouble(System.getProperty("hv", "0.7"));
        ctl.learn = learn;
        if (!learn) { ctl.A = A * mA; ctl.G = G * mG; ctl.D = D * mD; ctl.lat = latS + mL; }
        ReelUi ui = new ReelUi();
        double pw = 413;
        ui.pillL = 0; ui.pillR = pw - 1; ui.pillT = 0; ui.pillB = 49;
        ui.hasProgress = true; ui.progL = 378; ui.progR = 891;
        double lo = ui.trackL() / pw + 0.5, hi = ui.trackR() / pw - 0.5;
        double c = 1.5, v = 0, f = 1.5, target = 1.5, fs = 1, next = 0, t = 0, dt = 0.002;
        ArrayDeque<double[]> q = new ArrayDeque<>();
        boolean eff = false, cmd = false;
        double inside = 0, total = 0, stunUntil = -1;
        ReelTracker.Measure m = new ReelTracker.Measure();
        double nextFrame = 0;
        for (int i = 0; i < 30000; i++) {
            t += dt;
            while (!q.isEmpty() && q.peek()[0] <= t) eff = q.poll()[1] > 0;
            if (t >= next) {
                target = lo - 0.35 + rnd.nextDouble() * (hi - lo + 0.7);
                fs = (0.4 + rnd.nextDouble() * 1.2) * fishMul;
                next = t + 0.4 + rnd.nextDouble() * 1.4;
            }
            if (stunTest && Math.abs(t - 20) < dt / 2) stunUntil = t + 4;
            if (t >= stunUntil) { double d = target - f; f += Math.signum(d) * Math.min(Math.abs(d), fs * dt); }
            v += ((eff ? A : -G) - D * v) * dt;
            c += v * dt;
            if (c < lo) { c = lo; if (v < 0) v = 0; }
            if (c > hi) { c = hi; if (v > 0) v = 0; }
            if (t > 3) { total += dt; if (Math.abs(f - c) <= 0.5) inside += dt; }
            if (t >= nextFrame) {
                nextFrame += 1.0 / 30;
                m.pillL = (c - 0.5) * pw; m.pillR = (c + 0.5) * pw - 1;
                m.fishFound = !HIDE || Math.abs(f - c) > 0.5; m.fishX = f * pw;
                boolean h = ctl.update(m, ui, (long) (t * 1e9), sens, t < stunUntil);
                if (h != cmd) { cmd = h; q.add(new double[] {t + latS, h ? 1 : 0}); }
            }
        }
        return inside / total;
    }

    public static void main(String[] a) {
        double[][] pert = {{1,1,1,0.02},{1.1,0.9,1.2,0.04},{1.2,1.2,1.5,0.02},{0.85,0.85,0.7,0.0},{1.1,1.1,1,0.06}};
        for (double[] pp : pert) {
            mA = pp[0]; mG = pp[1]; mD = pp[2]; mL = pp[3];
            double r = 0; for (long sd = 1; sd <= 5; sd++) r += run(sd, 9, 11, 2.5, 0.07, false, 1, 1, false);
            System.out.printf("  frozen model x(A%.2f G%.2f D%.2f) lat+%.0fms : in-bar %.0f%%%n", pp[0], pp[1], pp[2], pp[3]*1000, r / 5 * 100);
        }
        mA = mG = mD = 1; mL = 0.02;
        String[] names = {"true model, lat 70ms", "learned model", "fast fish x1.5", "slow bar (A5,G6,D1.5)", "lat 150ms"};
        double[] r = new double[5];
        for (long s = 1; s <= 5; s++) {
            r[0] += run(s, 9, 11, 2.5, 0.07, false, 1, 1, false);
            r[1] += run(s, 9, 11, 2.5, 0.07, true, 1, 1, false);
            r[2] += run(s, 9, 11, 2.5, 0.07, true, 1.5, 1, false);
            r[3] += run(s, 5, 6, 1.5, 0.07, true, 1, 1, false);
            r[4] += run(s, 9, 11, 2.5, 0.15, true, 1, 1, false);
        }
        for (int i = 0; i < 5; i++) System.out.printf("  %-26s in-bar %.0f%%%n", names[i], r[i] / 5 * 100);
    }
}
