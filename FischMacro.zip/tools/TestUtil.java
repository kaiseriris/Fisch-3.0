import com.fischmacro.ArrayFrame;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.File;

/** Small helpers shared by the desktop tests. */
public final class TestUtil {
    private TestUtil() {}

    public static ArrayFrame load(String path) throws Exception {
        BufferedImage im = ImageIO.read(new File(path));
        return fromImage(im);
    }

    public static ArrayFrame fromImage(BufferedImage im) {
        int w = im.getWidth(), h = im.getHeight();
        ArrayFrame f = new ArrayFrame(w, h);
        for (int y = 0; y < h; y++)
            for (int x = 0; x < w; x++) f.px[y * w + x] = im.getRGB(x, y) & 0xFFFFFF;
        return f;
    }

    public static BufferedImage toImage(ArrayFrame f) {
        BufferedImage im = new BufferedImage(f.w, f.h, BufferedImage.TYPE_INT_RGB);
        for (int y = 0; y < f.h; y++)
            for (int x = 0; x < f.w; x++) im.setRGB(x, y, f.px[y * f.w + x]);
        return im;
    }

    /** Bilinear resize. */
    public static ArrayFrame resize(ArrayFrame src, int nw, int nh) {
        ArrayFrame out = new ArrayFrame(nw, nh);
        for (int y = 0; y < nh; y++) {
            double sy = (y + 0.5) * src.h / nh - 0.5;
            int y0 = (int) Math.floor(sy);
            double fy = sy - y0;
            for (int x = 0; x < nw; x++) {
                double sx = (x + 0.5) * src.w / nw - 0.5;
                int x0 = (int) Math.floor(sx);
                double fx = sx - x0;
                int r = 0, g = 0, b = 0;
                double[] wts = {(1 - fx) * (1 - fy), fx * (1 - fy), (1 - fx) * fy, fx * fy};
                int[] xs = {x0, x0 + 1, x0, x0 + 1}, ys = {y0, y0, y0 + 1, y0 + 1};
                double rr = 0, gg = 0, bb = 0;
                for (int k = 0; k < 4; k++) {
                    int xx = Math.max(0, Math.min(src.w - 1, xs[k])), yy = Math.max(0, Math.min(src.h - 1, ys[k]));
                    int p = src.px[yy * src.w + xx];
                    rr += wts[k] * ((p >> 16) & 255);
                    gg += wts[k] * ((p >> 8) & 255);
                    bb += wts[k] * (p & 255);
                }
                out.px[y * nw + x] = ((int) Math.round(rr) << 16) | ((int) Math.round(gg) << 8) | (int) Math.round(bb);
            }
        }
        return out;
    }
}
