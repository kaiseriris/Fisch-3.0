import com.fischmacro.*;

/** Sweeps the control bar across the track in the simulator and compares the tracker with the truth. */
public class TrackCheck {
    public static void main(String[] a) throws Exception {
        double scale = a.length > 0 ? Double.parseDouble(a[0]) : 1.0;
        Sim sim = new Sim(scale, 0, 0, 1);
        sim.st = Sim.St.REEL;
        sim.progress = 0.5;
        sim.barU = 1.5; sim.fishU = 0.8;
        ReelFinder rf = new ReelFinder();
        ReelUi ui = rf.search(sim.render(), 1.0);
        System.out.println("found: " + (ui != null) + (ui == null ? "" : String.format(" pill %.0f-%.0f", ui.pillL, ui.pillR)));
        if (ui == null) return;
        ReelTracker tr = new ReelTracker();
        tr.lock(ui);
        ReelTracker.Measure m = new ReelTracker.Measure();
        double[] fishPos = {0.85, 2.25};
        for (double fp : fishPos) {
            sim.fishU = fp;
            for (int dir = 0; dir < 2; dir++) {
                for (int i = 0; i <= 40; i++) {
                    double u = dir == 0 ? 1.0 + i * 0.03 : 2.2 - i * 0.03;
                    sim.barU = u;
                    tr.track(sim.render(), m);
                    double truthL = sim.barPx() - 206.5 * scale, truthR = sim.barPx() + 206.5 * scale;
                    double eL = m.pillL - truthL, eR = m.pillR - truthR;
                    if (i % 8 == 0 || Math.abs(eL) > 6 || Math.abs(eR) > 6)
                        System.out.printf("fish %.2f dir %d u=%.2f ok=%b L err %+.0f R err %+.0f  fish %b %.0f(truth %.0f) prog %.2f conf %.2f%n",
                                fp, dir, u, m.ok, eL, eR, m.fishFound, m.fishX, sim.fishPx(), m.progress, m.conf);
                }
            }
        }
    }
}
