import com.fischmacro.*;

/** Standard-UI detector checks: finding, no false positives, tracking accuracy on drawn frames. */
public class StdTest {
    static int fails = 0;
    static void check(String n, boolean ok, String d) { System.out.println((ok ? "  PASS  " : "  FAIL  ") + n + "  " + d); if (!ok) fails++; }

    public static void main(String[] a) throws Exception {
        for (double[] cfg : new double[][] {{1.0, 0, 0}, {0.7, -60, -25}, {0.5, 100, 30}}) {
            double s = cfg[0];
            System.out.println("[scale " + s + "]");
            Sim sim = new Sim(s, cfg[1], cfg[2], 1, true);
            sim.st = Sim.St.REEL;
            StdReel sr = new StdReel();
            // search on a frame with the bar at several places
            sim.barU = 1.5; sim.fishU = 1.8; sim.progress = 0.4;
            ReelUi ui = sr.search(sim.render());
            check("found", ui != null, ui == null ? String.format("best %.2f", sr.lastBest) : String.format("conf %.2f bar %.0f-%.0f (truth %.0f)", ui.conf, ui.pillL, ui.pillR, sim.barPx()));
            if (ui == null) continue;
            sr.lock(ui);
            ReelTracker.Measure m = new ReelTracker.Measure();
            double eb = 0, ef = 0, ep = 0; int n = 0, fmiss = 0, nf = 0;
            java.util.Random r = new java.util.Random(5);
            for (int i = 0; i < 600; i++) {
                sim.barU = sim.LO + r.nextDouble() * (sim.HI - sim.LO);
                sim.fishU = sim.LO - 0.35 + r.nextDouble() * (sim.HI - sim.LO + 0.7);
                sim.progress = r.nextDouble();
                ArrayFrame fr = sim.render();
                sr.track(fr, m);
                if (!m.ok) { fmiss++; continue; }
                n++;
                eb += Math.abs((m.pillL + m.pillR + 1) / 2 - sim.barPx());
                if (m.fishFound) { double e = Math.abs(m.fishX - sim.fishPx()); ef += Math.min(e, 200); nf++; if (e > 6 * s + 3) fmiss++; }
                else fmiss++;
                if (m.progressOk) ep += Math.abs(m.progress - sim.progress);
            }
            check("bar error", eb / n < 2 * s + 1, String.format("%.2f px", eb / n));
            check("fish error", ef / Math.max(1, nf) < 3 * s + 1, String.format("%.2f px, wrong or missed %d of 600", ef / Math.max(1, nf), fmiss));
            check("progress error", ep / n < 0.03, String.format("%.3f", ep / n));
            // false positives
            sim.st = Sim.St.IDLE;
            check("nothing on idle frame", new StdReel().search(sim.render()) == null, "");
            Sim z = new Sim(s, cfg[1], cfg[2], 1, false);
            z.st = Sim.St.REEL; z.barU = 1.5; z.fishU = 1.8; z.progress = 0.5;
            check("not fooled by Zanshin Zen UI", new StdReel().search(z.render()) == null, "");
            check("Zanshin finder not fooled by standard UI", new ReelFinder().search(ssim(s, cfg), 1.0) == null, "");
        }
        System.out.println(fails == 0 ? "ALL PASSED" : fails + " FAILED");
    }
    static ArrayFrame ssim(double s, double[] c) throws Exception {
        Sim q = new Sim(s, c[1], c[2], 1, true); q.st = Sim.St.REEL; q.barU = 1.5; q.fishU = 1.8; q.progress = 0.5; return q.render().copy();
    }
}
