"""Builds test assets from the real Zanshin Zen screenshot (tools/testdata/real_ui.jpg):
   bg_clean.png  - the frame with the control pill and fish marker removed
   pill.png      - RGBA cut-out of the control pill (with outline)
   kunai.png     - RGBA cut-out of the fish marker
   meta.json     - where everything was in the original
Run: python3 tools/make_assets.py
"""
import json, os
import numpy as np, cv2
D = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'testdata')
img = cv2.imread(os.path.join(D, 'real_ui.jpg'))
H, W = img.shape[:2]
luma = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# --- pill ---
dark = (luma < 45).astype(np.uint8)
n, lab, st, cen = cv2.connectedComponentsWithStats(dark, connectivity=8)
pill = None
for i in range(1, n):
    x, y, w, h, a = st[i]
    if w / max(h, 1) > 5 and a / (w * h) > 0.75 and w > 200:
        pill = (x, y, w, h)
px, py, pw, ph = pill
pad = 4
pm = np.zeros((H, W), np.uint8)
cv2.rectangle(pm, (px - pad, py - pad), (px + pw + pad - 1, py + ph + pad - 1), 255, -1)
# round the corners a little
pm = cv2.morphologyEx(pm, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (15, 15)))
x0, y0, x1, y1 = px - pad - 2, py - pad - 2, px + pw + pad + 2, py + ph + pad + 2
pill_rgba = np.dstack([img[y0:y1, x0:x1], pm[y0:y1, x0:x1]])
cv2.imwrite(os.path.join(D, 'pill.png'), pill_rgba)

# --- kunai (swirl + blade) ---
kx0, kx1, ky0, ky1 = 336, 376, 1288, 1482
sub = luma[ky0:ky1, kx0:kx1]
km = (sub < 95).astype(np.uint8) * 255
km = cv2.dilate(km, np.ones((3, 3), np.uint8), iterations=1)
# drop anything connected to the (far away) hole edges: keep the largest vertical component
nn, ll, ss, cc = cv2.connectedComponentsWithStats((km > 0).astype(np.uint8), connectivity=8)
keep = np.zeros_like(km)
for i in range(1, nn):
    if ss[i][4] > 60:
        keep[ll == i] = 255
kunai_rgba = np.dstack([img[ky0:ky1, kx0:kx1], keep])
cv2.imwrite(os.path.join(D, 'kunai.png'), kunai_rgba)

# --- clean background: inpaint pill and kunai ---
full = np.zeros((H, W), np.uint8)
full[y0:y1, x0:x1] = pm[y0:y1, x0:x1]
full[ky0:ky1, kx0:kx1] = np.maximum(full[ky0:ky1, kx0:kx1], keep)
full = cv2.dilate(full, np.ones((3, 3), np.uint8))
bg = cv2.inpaint(img, full, 7, cv2.INPAINT_TELEA)
# the blade behind the pill is smeared by inpainting; rebuild it from the blade strip right of the pill
blade_src = bg[py - 2:py + ph + 2, px + pw + 8: px + pw + 8 + 60]
for xx in range(px - 6, px + pw + 6, 60):
    seg = blade_src[:, : min(60, px + pw + 6 - xx)]
    bg[py - 2:py + ph + 2, xx: xx + seg.shape[1]] = seg
cv2.imwrite(os.path.join(D, 'bg_clean.png'), bg)

# --- progress bar geometry ---
meta = dict(
    width=W, height=H,
    pill=dict(x=int(px), y=int(py), w=int(pw), h=int(ph)),
    pill_cut=dict(x=int(x0), y=int(y0), w=int(x1 - x0), h=int(y1 - y0)),
    kunai_cut=dict(x=kx0, y=ky0, w=kx1 - kx0, h=ky1 - ky0, stem_x=355),
    progress=dict(x0=372, x1=898, y0=1462, y1=1484, fill_end=717),
    dot=dict(x=637, y=1154, r=21),
    knife=dict(x0=360, x1=915, y0=960, y1=1110),
    banner=dict(x0=104, x1=1165, y0=178, y1=482),
)
json.dump(meta, open(os.path.join(D, 'meta.json'), 'w'), indent=1)
print('ok', meta['pill'])

# ---- Soul Judgement test assets: knife patch + a background with the knife painted out ----
kx0, ky0, kx1, ky1 = 330, 930, 945, 1255
cv2.imwrite(os.path.join(D, 'knife_patch.png'), img[ky0:ky1, kx0:kx1])
km2 = np.zeros((H, W), np.uint8)
km2[ky0:ky1, kx0:kx1] = 255
bg2 = cv2.imread(os.path.join(D, 'bg_clean.png'))
bg2 = cv2.inpaint(bg2, km2, 9, cv2.INPAINT_TELEA)
cv2.imwrite(os.path.join(D, 'bg_clean.png'), bg2)
meta['knife_patch'] = dict(x=kx0, y=ky0, w=kx1 - kx0, h=ky1 - ky0)
json.dump(meta, open(os.path.join(D, 'meta.json'), 'w'), indent=1)
print('knife assets ok')
