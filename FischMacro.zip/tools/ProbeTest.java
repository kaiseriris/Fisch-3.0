import com.fischmacro.*;

/** Runs the bar-response probe against the simulator and compares the fit with the simulator's true physics. */
public class ProbeTest {
    public static void main(String[] a) throws Exception {
        Sim sim = new Sim(1.0, 0, 0, 5);
        sim.knifeEnabled = false;
        sim.st = Sim.St.REEL;
        Config cfg = new Config();
        Diag diag = new Diag();
        Macro macro = new Macro(cfg, diag, sim);
        macro.checkMode = true;
        double dt = 0.005, next = 0;
        boolean started = false;
        for (int i = 0; i < 4000; i++) {
            sim.step(dt);
            sim.progress = 0.5;
            long now = (long) (sim.t * 1e9);
            if (sim.t >= next) {
                next += 1 / 30.0;
                macro.onFrame(sim.render(), now);
                if (!started && sim.t > 0.5) { macro.startProbe(); started = true; }
            }
        }
        System.out.println(diag.eventLog(10));
        macro.liveView = true;
        macro.onFrame(sim.render(), (long) (sim.t * 1e9) + 1_000_000_000L);
        java.awt.image.BufferedImage bi = new java.awt.image.BufferedImage(diag.thumbW, diag.thumbH, java.awt.image.BufferedImage.TYPE_INT_ARGB);
        bi.setRGB(0, 0, diag.thumbW, diag.thumbH, diag.thumb, 0, diag.thumbW);
        double[] v = diag.vis;
        if (v != null) {
            java.awt.Graphics2D g = bi.createGraphics();
            double sx = diag.thumbW / v[5], sy = diag.thumbH / v[6];
            g.setColor(java.awt.Color.GREEN);
            g.drawRect((int) (v[0] * sx), (int) (v[1] * sy), (int) ((v[2] - v[0]) * sx), (int) ((v[3] - v[1]) * sy));
            if (v[10] >= 0) { g.setColor(java.awt.Color.BLUE); g.drawRect((int) (v[10] * sx), (int) (v[11] * sy), (int) ((v[12] - v[10]) * sx), (int) ((v[13] - v[11]) * sy)); }
            g.dispose();
        }
        javax.imageio.ImageIO.write(bi, "png", new java.io.File(System.getProperty("out", "thumb.png")));
        System.out.printf("fit A=%.1f G=%.1f D=%.1f lat=%.0f ms   (sim truth A=%.1f G=%.1f D=%.1f lat=70 ms)  vis=%s note=%s%n",
                macro.ctl.A, macro.ctl.G, macro.ctl.D, macro.ctl.lat * 1000, sim.A, sim.G, sim.Dr, diag.vis == null ? "none" : "ok", diag.visNote);
    }
}
