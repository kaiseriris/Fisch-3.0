import com.fischmacro.*;

import java.io.File;

/** Desktop tests for the whole macro. Exit code 1 if anything fails. Run from the project root. */
public class FullLoopTest {
    static int fails = 0;

    static void check(String name, boolean ok, String detail) {
        System.out.println((ok ? "  PASS  " : "  FAIL  ") + name + "  " + detail);
        if (!ok) fails++;
    }

    // ---- 1. real screenshot ------------------------------------------------------------------
    static void realFrame() throws Exception {
        System.out.println("[1] Real Zanshin Zen screenshot (1310x1640)");
        ArrayFrame f = TestUtil.load("tools/testdata/real_ui.jpg");
        ReelFinder rf = new ReelFinder();
        ReelUi ui = rf.search(f, 1.0);
        check("reel interface found", ui != null, ui == null ? "" : String.format("conf %.2f", ui.conf));
        if (ui == null) return;
        check("pill edges", Math.abs(ui.pillL - 489) <= 3 && Math.abs(ui.pillR - 901) <= 3,
                String.format("x %.0f-%.0f (truth 489-901)", ui.pillL, ui.pillR));
        ReelTracker tr = new ReelTracker();
        tr.lock(ui);
        ReelTracker.Measure m = new ReelTracker.Measure();
        for (int i = 0; i < 3; i++) tr.track(f, m);
        check("fish marker located", m.fishFound && Math.abs(m.fishX - 355) <= 6, String.format("x=%.1f (truth ~355)", m.fishX));
        check("progress meter read", m.progressOk && Math.abs(m.progress - 0.66) <= 0.04, String.format("%.3f (truth ~0.66)", m.progress));

        SoulJudgement sj = new SoulJudgement();
        SoulJudgement.Target t = sj.find(f, ui.pillT, 1.0);
        check("Soul Judgement target found", t != null && Math.hypot(t.cx - 637, t.cy - 1154) <= 5,
                t == null ? "none" : String.format("centre (%.0f,%.0f) conf %.2f ring %.2f blade %.2f", t.cx, t.cy, t.sRing > 0 ? t.conf : 0, t.sRing, t.sBlade));
        ArrayFrame clean = TestUtil.load("tools/testdata/bg_clean.png");
        check("no false Soul Judgement on clean frame", sj.find(clean, 1377, 1.0) == null, "");
        check("no reel found on clean frame", new ReelFinder().search(clean, 1.0) == null, "");
    }

    // ---- 2. full loop -------------------------------------------------------------------------
    static Macro.Stage lastStage;
    static int dbgN = 0, cntReel, cntNotReel, cntOut, cntOutMissed, cntNotOk, cntStun;

    static void loop(String name, double scale, double ox, double oy, double seconds, boolean dead, long seed,
                     int minCatches, double minInBar) throws Exception {
        String only = System.getProperty("only");
        if (only != null && !name.startsWith(only)) return;
        System.out.println("[" + name + "]");
        boolean std = !(name.startsWith("2") || name.startsWith("3") || name.startsWith("4") || name.startsWith("5"));
        Sim sim = new Sim(scale, ox, oy, seed, std);
        if (name.startsWith("5")) { sim.knifeEnabled = false; sim.fishSpeedMul = 1.5; }
        if (name.startsWith("8")) sim.fishSpeedMul = 1.5;
        if (name.startsWith("9")) { sim.pattern = 1; sim.gainRate = 0.05; sim.lossRate = 0.03; }
        if (name.startsWith("10")) sim.pattern = 2;
        if (name.startsWith("11")) sim.fishLoss = true;
        if (name.startsWith("14")) sim.invertHold = true;
        Config cfg = new Config();
        cfg.cooldownMs = 1500;
        Diag diag = new Diag();
        Macro macro = new Macro(cfg, diag, sim);
        // teach the shake button from a frame that shows it
        ArrayFrame shot = sim.base.copy();
        Sim.drawButton(shot, 300, 60, scale);
        int tsize = (int) Math.round(64 * scale);
        boolean taught = System.getProperty("noteach") != null || macro.shake.teach(shot, 300 + (int) (100 * scale), 60 + (int) (40 * scale), tsize);
        check("shake button taught", taught, "");

        if (System.getProperty("pulse") != null) cfg.pulseMode = !System.getProperty("pulse").equals("0");
        if (System.getProperty("minflip") != null) cfg.holdMinMs = Integer.parseInt(System.getProperty("minflip"));
        if (System.getProperty("noauto") != null) cfg.autoModel = false;
        if (System.getProperty("truth") != null) { String[] tv = System.getProperty("truth").split(","); macro.ctl.A = Double.parseDouble(tv[0]); macro.ctl.G = Double.parseDouble(tv[1]); macro.ctl.D = Double.parseDouble(tv[2]); macro.ctl.lat = Double.parseDouble(tv[3]); macro.ctl.learn = false; macro.modelFrozen = true; }
        if (System.getProperty("stopc") != null) cfg.stopAfterCatches = Integer.parseInt(System.getProperty("stopc"));
        if (System.getProperty("nobite") != null) { cfg.maxNoBites = Integer.parseInt(System.getProperty("nobite")); cfg.biteTimeoutMs = 1500; }
        if (System.getProperty("mode") != null) cfg.detectMode = Integer.parseInt(System.getProperty("mode"));
        if (System.getProperty("calib") != null || System.getProperty("boxes") != null || cfg.detectMode == 2) {
            // teach colours exactly like the phone does: from one rendered reel frame and two taps
            Sim.St keep = sim.st; sim.st = Sim.St.REEL; sim.barU = 1.5; sim.fishU = 1.5 + 0.9; sim.progress = 0.5;
            ArrayFrame cf = sim.render().copy(); sim.st = keep;
            if (System.getProperty("boxes") != null) {
                double W = cf.w, H = cf.h;
                double bx = sim.barPx(), by0 = sim.Y(1371), fy0 = sim.Y(1288), fx0 = sim.fishPx();
                // a hand-placed box is never exact: bar box a little loose, fish box clearly looser than the icon
                double[] barB = {(bx - sim.pill.w / 2.0 - 4) / W, (by0 - 2) / H, (bx + sim.pill.w / 2.0 + 4) / W, (by0 + sim.pill.h + 2) / H};
                double[] fishB = {(fx0 - sim.kunai.w / 2.0 - 10) / W, (fy0 - 8) / H, (fx0 + sim.kunai.w / 2.0 + 10) / W, (fy0 + sim.kunai.h + 8) / H};
                double[] trackB = {sim.X(125.5) / W, (by0 + 8) / H, sim.X(1143.5) / W, (by0 + sim.pill.h - 8) / H};
                double[] meterB = {(sim.X(378) - 6) / W, (sim.Y(1462) - 3) / H, (sim.X(891) + 6) / W, (sim.Y(1483) + 3) / H};
                String e = ColorReel.calibrateBoxes(cf, barB, fishB, trackB, meterB, macro.colorReel.profile);
                ColorProfile q = macro.colorReel.profile;
                System.out.printf("  boxes: warn=[%s] track=%b %.3f-%.3f meter=%b fill=%.0f,%.0f,%.0f%n", macro.colorReel.profile.warning, macro.colorReel.profile.hasTrack, macro.colorReel.profile.trackLFrac, macro.colorReel.profile.trackRFrac, macro.colorReel.profile.hasProg, macro.colorReel.profile.progFillR, macro.colorReel.profile.progFillG, macro.colorReel.profile.progFillB);
                System.out.printf("  boxes: %s barRGB %.0f,%.0f,%.0f w=%.3f h=%.3f boxed=%b fishRGB %.0f,%.0f,%.0f w=%.3f%n", e, q.barR, q.barG, q.barB, q.barWFrac, q.barHFrac, q.boxed, q.fishR, q.fishG, q.fishB, q.fishWFrac);
                cf = null;
            }
            int by = (int) Math.round(sim.Y(1371) + sim.pill.h / 2.0);
            String e1 = cf == null ? "boxes" : ColorReel.calibrateBar(cf, (int) Math.round(sim.barPx()), by, 1.0, macro.colorReel.profile);
            String e2 = cf == null ? "boxes" : ColorReel.calibrateFish(cf, (int) Math.round(sim.fishPx()), (int) Math.round(sim.Y(1288) + sim.kunai.h / 2.0), 1.0, macro.colorReel.profile);
            ColorProfile cp = macro.colorReel.profile;
            System.out.printf("  calibrate bar: %s  fish: %s  barRGB %.0f,%.0f,%.0f w=%.3f h=%.3f  fishRGB %.0f,%.0f,%.0f w=%.3f%n", e1, e2,
                    cp.barR, cp.barG, cp.barB, cp.barWFrac, cp.barHFrac, cp.fishR, cp.fishG, cp.fishB, cp.fishWFrac);
        }
        double dt = 0.005, nextFrame = 0, errFish = 0, errBar = 0, errProg = 0;
        int nErr = 0, nBar = 0, reelsWithDead = 0;
        double lastReelStart = -1; Macro.Stage lastStage = null;
        if (System.getProperty("fixmodel") != null) { macro.ctl.learn = false; macro.ctl.A = 9; macro.ctl.G = 11; macro.ctl.D = 2.5; macro.ctl.lat = 0.09; }
        if (System.getProperty("hz") != null) macro.ctl.HZ = Double.parseDouble(System.getProperty("hz"));
        if (System.getProperty("fg") != null) macro.ctl.fishGain = Double.parseDouble(System.getProperty("fg"));
        if (System.getProperty("pen") != null) macro.ctl.outPen = Double.parseDouble(System.getProperty("pen"));
        if (System.getProperty("outat") != null) macro.ctl.outAt = Double.parseDouble(System.getProperty("outat"));
        macro.start(0);
        if (System.getProperty("secs") != null) seconds = Double.parseDouble(System.getProperty("secs"));
        int steps = (int) (seconds / dt);
        long worstProc = 0;
        for (int i = 0; i < steps; i++) {
            sim.step(dt);
            long now = (long) (sim.t * 1e9);
            if (i % 3 == 0) macro.tick(now);
            if (sim.t >= nextFrame) {
                nextFrame += 1 / 30.0;
                if (dead && sim.st == Sim.St.REEL && sim.reelT > 1.5 && sim.reelT < 1.7 && sim.deadTo < sim.t && reelsWithDead < 3) {
                    sim.deadFrom = sim.t;
                    sim.deadTo = sim.t + 2.5;
                    reelsWithDead++; System.out.printf("  [dead window armed t=%.2f reelT=%.2f]%n", sim.t, sim.reelT);
                }
                long t0 = System.nanoTime();
                macro.onFrame(sim.render(), now);
                worstProc = Math.max(worstProc, System.nanoTime() - t0);
                ReelTracker.Measure m = macro.lastMeasure();
                if (System.getProperty("trace") != null && (sim.st == Sim.St.REEL || System.getProperty("tracem") != null) && sim.t > Double.parseDouble(System.getProperty("t0","6")) && sim.t < Double.parseDouble(System.getProperty("t1","9")))
                    {ReelUi uu = macro.tracker.model(); if (uu != null) System.out.printf("UI %.0f %.0f %.0f %b%n", uu.progL, uu.progR, uu.pillW(), uu.hasProgress);} System.out.printf("LH %.3f %.3f%nT %.2f fish=%.2f bar=%.2f barV=%.2f eff=%b | ctl push=%b c=%.2f v=%.2f f=%.2f vf=%.2f found=%b stage=%s mp=%.2f ok=%b pok=%b sp=%.2f health=%d%n", macro.ctl.loEst(), macro.ctl.hiEst(), sim.t, sim.fishU, sim.barU, sim.barV, sim.effHold, macro.ctl.lastHold, macro.ctl.cEst(), macro.ctl.barVel(), macro.ctl.fEst(), macro.ctl.fishVel(), m.fishFound, macro.stage(), m.progress, m.ok, m.progressOk, sim.progress, macro.ctl.health);
                if (System.getProperty("dbgst") != null && macro.stage() != lastStage) { System.out.printf("  [t=%.2f macro %s -> %s, sim.st=%s progress=%.2f fish=%.2f bar=%.2f]%n", sim.t, lastStage, macro.stage(), sim.st, sim.progress, sim.fishU, sim.barU); lastStage = macro.stage(); if (macro.stage()==Macro.Stage.REEL) { ReelUi u = macro.tracker.model(); System.out.printf("   meter %.0f-%.0f (truth %.0f-%.0f) pill %.0f-%.0f%n", u.progL, u.progR, sim.X(378), sim.X(891), u.pillL, u.pillR); } }
                if (sim.st == Sim.St.REEL) {
                    cntReel++;
                    if (macro.stage() != Macro.Stage.REEL) cntNotReel++;
                    else {
                        if (Math.abs(sim.fishU - sim.barU) > 0.5) { cntOut++; if (!m.fishFound) cntOutMissed++; }
                        if (!m.ok) cntNotOk++;
                    }
                    if (sim.t < sim.stunUntil) cntStun++;
                }
                if (sim.st == Sim.St.REEL && macro.stage() == Macro.Stage.REEL && m.ok && m.fishFound && sim.reelT > 1.0) {
                    double fishErr = Math.abs(m.fishX - sim.fishPx());
                    if (System.getProperty("dbg") != null && fishErr > 40 && Math.abs(sim.fishU - sim.barU) > 0.62 && dbgN++ < 25)
                        System.out.printf("   dbg t=%.2f fishU=%.2f barU=%.2f meas=%.0f truth=%.0f conf=%.2f stunned=%b reelT=%.1f%n", sim.t, sim.fishU, sim.barU, m.fishX, sim.fishPx(), m.fishConf, sim.t < sim.stunUntil, sim.reelT);
                    if (Math.abs(sim.fishU - sim.barU) > 0.62) { // only count when the fish is visible outside the bar
                        errFish += fishErr;
                        nErr++;
                    }
                    errBar += Math.abs((m.pillL + m.pillR + 1) / 2 - sim.barPx());
                    nBar++;
                    if (m.progressOk) errProg += Math.abs(m.progress - sim.progress);
                }
            }
        }
        double inBar = sim.reelTime > 0 ? sim.inBarTime / sim.reelTime : 0;
        System.out.println("  stats: [" + diag.stats + "] stopReason=[" + macro.stopReason + "] running=" + macro.isRunning());
        { String tr = macro.lastReelTrace; int tot = 0, hid = 0; for (String ln : tr.split("\n")) if (ln.matches("[0-9.]+,[0-9]+,.*,[01],[01]")) { tot++; if (ln.contains("hidden")) hid++; } System.out.printf("  last reel: fish hidden in %d of %d samples%n", hid, tot); }
        System.out.printf("  sim: presses=%d pulses=%d casts=%d shakeTaps=%d catches=%d escapes=%d inBar=%.0f%% knives=%d sjHits=%d sjDup=%d resets=%d%n",
                sim.toggles, sim.pulses, sim.casts, sim.shakeHits, sim.catches, sim.escapes, inBar * 100, sim.knivesShown, sim.sjHits, sim.sjDup, sim.resets);
        System.out.printf("  metrics: time in bar %.1f%%, mean bar-to-fish distance %.2f bar widths, fish left the bar %d times (%.1f per min), mean time to get back %.2f s, worst miss %.2f widths%n",
                inBar * 100, sim.errT > 0 ? sim.errSum / sim.errT : 0, sim.exits, sim.reelTime > 0 ? sim.exits * 60.0 / sim.reelTime : 0, sim.recN > 0 ? sim.recSum / sim.recN : 0, sim.peakErr);
        System.out.printf("  macro: %s%n", diag.summary().replace("\n", " | "));
        System.out.printf("  worst frame %.1f ms%n", worstProc / 1e6);
        System.out.printf("  reel frames %d: macro not in REEL %d, tracker not ok %d, fish outside bar %d (fish missed %d), stunned %d%n", cntReel, cntNotReel, cntNotOk, cntOut, cntOutMissed, cntStun);
        cntReel = cntNotReel = cntOut = cntOutMissed = cntNotOk = cntStun = 0;
        {
            ReelFinder rf0 = new ReelFinder();
            ArrayFrame idle = sim.base.copy();
            Sim.drawButton(idle, 200, 80, scale);
            check("no false reel on idle frame (with shake button)", rf0.search(idle, 1.0) == null, "");
        }
        if (System.getProperty("events") != null) System.out.println(diag.eventLog(60));
        check("catches", sim.catches >= minCatches, sim.catches + " (need " + minCatches + ")");
        check("fish kept in bar", inBar >= minInBar, String.format("%.0f%% (need %.0f%%)", inBar * 100, minInBar * 100));
        check("macro agrees with game on catches", Math.abs(diag.catches - sim.catches) <= 1, diag.catches + " vs " + sim.catches);
        if (sim.knivesShown > 0) {
            check("Soul Judgement used on knives", sim.sjHits >= sim.knivesShown - 1, sim.sjHits + "/" + sim.knivesShown);
            check("no duplicate Soul Judgement taps", sim.sjDup == 0, "dups " + sim.sjDup);
        }
        if (nErr > 20) {
            check("fish tracking error under 12 px", errFish / nErr < 12 * scale + 2, String.format("%.1f px", errFish / nErr));
            check("bar tracking error under 8 px", errBar / Math.max(1, nBar) < 8 * scale + 2, String.format("%.1f px", errBar / Math.max(1, nBar)));
        }
        if (dead) {
            check("recovered from dead input", diag.recoveries >= 1 && sim.resets >= 1, "recoveries " + diag.recoveries + ", resets " + sim.resets);
        }
    }

    public static void main(String[] args) throws Exception {
        realFrame();
        loop("2 full loop, 150 s", 1.0, 0, 0, 150, false, 1, 6, 0.80);
        loop("3 UI smaller (x0.7) and moved", 0.7, -60, -25, 100, false, 2, 4, 0.75);
        loop("4 inputs stop reaching the game (3 times)", 1.0, 0, 0, 150, true, 3, 5, 0.70);
        loop("5 faster fish, no knife", 1.0, 0, 0, 90, false, 4, 3, 0.70);
        loop("6 standard UI, 150 s", 1.0, 0, 0, 150, false, 5, 6, 0.90);
        loop("7 standard UI smaller (x0.7) and moved", 0.7, -60, -25, 100, false, 6, 4, 0.90);
        loop("8 standard UI, faster fish", 1.0, 0, 0, 90, false, 7, 3, 0.85);
        loop("9 Scylla-style, fast and erratic (assumed behaviour)", 1.0, 0, 0, 120, false, 8, 0, 0.55);
        loop("10 sudden end-to-end reversals", 1.0, 0, 0, 90, false, 9, 2, 0.75);
        loop("11 fish marker lost 0.4 s every 3 s", 1.0, 0, 0, 90, false, 10, 3, 0.85);
        loop("12 inputs stop reaching the game (3 times), standard UI", 1.0, 0, 0, 120, true, 11, 3, 0.80);
        loop("13 long run, 600 s", 1.0, 0, 0, 600, false, 12, 20, 0.90);
        loop("14 hold direction swapped", 1.0, 0, 0, 120, false, 13, 3, 0.70);
        System.out.println(fails == 0 ? "ALL PASSED" : (fails + " FAILED"));
        System.exit(fails == 0 ? 0 : 1);
    }
}
