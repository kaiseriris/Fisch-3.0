import com.fischmacro.*;

import java.io.File;

/** Desktop tests for the whole macro. Exit code 1 if anything fails. Run from the project root. */
public class FullLoopTest {
    static int fails = 0;

    static void check(String name, boolean ok, String detail) {
        System.out.println((ok ? "  PASS  " : "  FAIL  ") + name + "  " + detail);
        if (!ok) fails++;
    }

    // ---- 1. real screenshot ------------------------------------------------------------------
    static void realFrame() throws Exception {
        System.out.println("[1] Real Zanshin Zen screenshot (1310x1640)");
        ArrayFrame f = TestUtil.load("tools/testdata/real_ui.jpg");
        ReelFinder rf = new ReelFinder();
        ReelUi ui = rf.search(f, 1.0);
        check("reel interface found", ui != null, ui == null ? "" : String.format("conf %.2f", ui.conf));
        if (ui == null) return;
        check("pill edges", Math.abs(ui.pillL - 489) <= 3 && Math.abs(ui.pillR - 901) <= 3,
                String.format("x %.0f-%.0f (truth 489-901)", ui.pillL, ui.pillR));
        ReelTracker tr = new ReelTracker();
        tr.lock(ui);
        ReelTracker.Measure m = new ReelTracker.Measure();
        for (int i = 0; i < 3; i++) tr.track(f, m);
        check("fish marker located", m.fishFound && Math.abs(m.fishX - 355) <= 6, String.format("x=%.1f (truth ~355)", m.fishX));
        check("progress meter read", m.progressOk && Math.abs(m.progress - 0.66) <= 0.04, String.format("%.3f (truth ~0.66)", m.progress));

        SoulJudgement sj = new SoulJudgement();
        SoulJudgement.Target t = sj.find(f, ui.pillT, 1.0);
        check("Soul Judgement target found", t != null && Math.hypot(t.cx - 637, t.cy - 1154) <= 5,
                t == null ? "none" : String.format("centre (%.0f,%.0f) conf %.2f ring %.2f blade %.2f", t.cx, t.cy, t.sRing > 0 ? t.conf : 0, t.sRing, t.sBlade));
        ArrayFrame clean = TestUtil.load("tools/testdata/bg_clean.png");
        check("no false Soul Judgement on clean frame", sj.find(clean, 1377, 1.0) == null, "");
        check("no reel found on clean frame", new ReelFinder().search(clean, 1.0) == null, "");
    }

    // ---- 2. full loop -------------------------------------------------------------------------
    static Macro.Stage lastStage;
    static int dbgN = 0, cntReel, cntNotReel, cntOut, cntOutMissed, cntNotOk, cntStun;

    static void loop(String name, double scale, double ox, double oy, double seconds, boolean dead, long seed,
                     int minCatches, double minInBar) throws Exception {
        String only = System.getProperty("only");
        if (only != null && !name.startsWith(only)) return;
        System.out.println("[" + name + "]");
        Sim sim = new Sim(scale, ox, oy, seed);
        if (name.startsWith("5")) { sim.knifeEnabled = false; sim.fishSpeedMul = 1.5; }
        Config cfg = new Config();
        cfg.cooldownMs = 1500;
        Diag diag = new Diag();
        Macro macro = new Macro(cfg, diag, sim);
        // teach the shake button from a frame that shows it
        ArrayFrame shot = sim.base.copy();
        Sim.drawButton(shot, 300, 60, scale);
        int tsize = (int) Math.round(64 * scale);
        boolean taught = macro.shake.teach(shot, 300 + (int) (100 * scale), 60 + (int) (40 * scale), tsize);
        check("shake button taught", taught, "");

        double dt = 0.005, nextFrame = 0, errFish = 0, errBar = 0, errProg = 0;
        int nErr = 0, reelsWithDead = 0;
        double lastReelStart = -1;
        if (System.getProperty("fixmodel") != null) { macro.ctl.learn = false; macro.ctl.A = 9; macro.ctl.G = 11; macro.ctl.D = 2.5; macro.ctl.lat = 0.09; }
        macro.start(0);
        if (System.getProperty("secs") != null) seconds = Double.parseDouble(System.getProperty("secs"));
        int steps = (int) (seconds / dt);
        long worstProc = 0;
        for (int i = 0; i < steps; i++) {
            sim.step(dt);
            long now = (long) (sim.t * 1e9);
            if (i % 3 == 0) macro.tick(now);
            if (sim.t >= nextFrame) {
                nextFrame += 1 / 30.0;
                if (dead && sim.st == Sim.St.REEL && sim.reelT > 5 && sim.reelT < 5.2 && sim.deadTo < sim.t && reelsWithDead < 3) {
                    sim.deadFrom = sim.t;
                    sim.deadTo = sim.t + 2.5;
                    reelsWithDead++;
                }
                long t0 = System.nanoTime();
                macro.onFrame(sim.render(), now);
                worstProc = Math.max(worstProc, System.nanoTime() - t0);
                ReelTracker.Measure m = macro.lastMeasure();
                if (sim.st == Sim.St.REEL) {
                    cntReel++;
                    if (macro.stage() != Macro.Stage.REEL) cntNotReel++;
                    else {
                        if (Math.abs(sim.fishU - sim.barU) > 0.5) { cntOut++; if (!m.fishFound) cntOutMissed++; }
                        if (!m.ok) cntNotOk++;
                    }
                    if (sim.t < sim.stunUntil) cntStun++;
                }
                if (sim.st == Sim.St.REEL && macro.stage() == Macro.Stage.REEL && m.ok && m.fishFound && sim.reelT > 1.0) {
                    double fishErr = Math.abs(m.fishX - sim.fishPx());
                    if (System.getProperty("dbg") != null && fishErr > 40 && Math.abs(sim.fishU - sim.barU) > 0.62 && dbgN++ < 25)
                        System.out.printf("   dbg t=%.2f fishU=%.2f barU=%.2f meas=%.0f truth=%.0f conf=%.2f stunned=%b reelT=%.1f%n", sim.t, sim.fishU, sim.barU, m.fishX, sim.fishPx(), m.fishConf, sim.t < sim.stunUntil, sim.reelT);
                    if (Math.abs(sim.fishU - sim.barU) > 0.62) { // only count when the fish is visible outside the bar
                        errFish += fishErr;
                        nErr++;
                    }
                    errBar += Math.abs((m.pillL + m.pillR + 1) / 2 - sim.barPx());
                    if (m.progressOk) errProg += Math.abs(m.progress - sim.progress);
                }
            }
        }
        double inBar = sim.reelTime > 0 ? sim.inBarTime / sim.reelTime : 0;
        System.out.printf("  sim: casts=%d shakeTaps=%d catches=%d escapes=%d inBar=%.0f%% knives=%d sjHits=%d sjDup=%d resets=%d%n",
                sim.casts, sim.shakeHits, sim.catches, sim.escapes, inBar * 100, sim.knivesShown, sim.sjHits, sim.sjDup, sim.resets);
        System.out.printf("  macro: %s%n", diag.summary().replace("\n", " | "));
        System.out.printf("  worst frame %.1f ms%n", worstProc / 1e6);
        System.out.printf("  reel frames %d: macro not in REEL %d, tracker not ok %d, fish outside bar %d (fish missed %d), stunned %d%n", cntReel, cntNotReel, cntNotOk, cntOut, cntOutMissed, cntStun);
        cntReel = cntNotReel = cntOut = cntOutMissed = cntNotOk = cntStun = 0;
        {
            ReelFinder rf0 = new ReelFinder();
            ArrayFrame idle = sim.base.copy();
            Sim.drawButton(idle, 200, 80, scale);
            check("no false reel on idle frame (with shake button)", rf0.search(idle, 1.0) == null, "");
        }
        if (System.getProperty("events") != null) System.out.println(diag.eventLog(60));
        check("catches", sim.catches >= minCatches, sim.catches + " (need " + minCatches + ")");
        check("fish kept in bar", inBar >= minInBar, String.format("%.0f%% (need %.0f%%)", inBar * 100, minInBar * 100));
        check("macro agrees with game on catches", Math.abs(diag.catches - sim.catches) <= 1, diag.catches + " vs " + sim.catches);
        if (sim.knivesShown > 0) {
            check("Soul Judgement used on knives", sim.sjHits >= sim.knivesShown - 1, sim.sjHits + "/" + sim.knivesShown);
            check("no duplicate Soul Judgement taps", sim.sjDup == 0, "dups " + sim.sjDup);
        }
        if (nErr > 20) {
            check("fish tracking error under 12 px", errFish / nErr < 12 * scale + 2, String.format("%.1f px", errFish / nErr));
            check("bar tracking error under 8 px", errBar / Math.max(1, nErr) < 8 * scale + 2, String.format("%.1f px", errBar / nErr));
        }
        if (dead) {
            check("recovered from dead input", diag.recoveries >= 1 && sim.resets >= 1, "recoveries " + diag.recoveries + ", resets " + sim.resets);
        }
    }

    public static void main(String[] args) throws Exception {
        realFrame();
        loop("2 full loop, 150 s", 1.0, 0, 0, 150, false, 1, 6, 0.80);
        loop("3 UI smaller (x0.7) and moved", 0.7, -60, -25, 100, false, 2, 4, 0.75);
        loop("4 inputs stop reaching the game (3 times)", 1.0, 0, 0, 150, true, 3, 5, 0.70);
        loop("5 faster fish, no knife", 1.0, 0, 0, 90, false, 4, 3, 0.70);
        System.out.println(fails == 0 ? "ALL PASSED" : (fails + " FAILED"));
        System.exit(fails == 0 ? 0 : 1);
    }
}
