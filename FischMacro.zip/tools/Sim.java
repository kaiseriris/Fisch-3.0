import com.fischmacro.*;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayDeque;
import java.util.Random;

/**
 * A stand-in for the game. It draws the REAL Zanshin Zen art (cut from the screenshot you sent) into
 * frames, moves the control bar with Fisch-style hold/release physics, and runs the whole cast, shake,
 * reel, catch cycle plus the Soul Judgement knife. The macro sees only pixels and can only press.
 * The physics numbers are invented, so this tests the logic, not the real game's feel.
 */
public class Sim implements Macro.Input {
    static final String D = "tools/testdata/";
    static final int CROP_Y = 850;
    double TL = 125.5, TR = 1143.5, PW = 413;
    double LO = TL / PW + 0.5, HI = TR / PW - 0.5;
    /** True for the default Fisch reel UI (white bar on a dark track, visible fish, thin progress meter). */
    final boolean std;
    // standard UI geometry in frame coordinates at scale 1 (crop coordinates): track box, bar width, meter box
    static final double S_TL = 215, S_TR = 1095, S_TT = CROP_Y + 520, S_TH = 44, S_BW = 396, S_FW = 8, S_FH = 70;
    static final double S_ML = 417, S_MR = 893, S_MT = CROP_Y + 604, S_MH = 11;
    static final double DOT_X = 637, DOT_Y = 1154;

    static final class Img { int w, h; int[] argb; }

    enum St { IDLE, BITE_WAIT, SHAKE, REEL, CATCH }

    final double s, ox, oy;
    final ArrayFrame base, work;
    final Img pill, kunai, knife;
    final int[] filledCol = new int[24], emptyCol = new int[24];
    final Random rnd;

    // knobs
    double latency = 0.07, dropRate = 0.03, deadFrom = -1, deadTo = -1;
    boolean knifeEnabled = true;
    double A = 9, G = 11, Dr = 2.5;
    double fishSpeedMul = 1.0;
    /** Fish behaviour: 0 normal, 1 Scylla-style (ASSUMED: fast, frequent reversals, slow progress), 2 sudden end-to-end reversals. */
    int pattern = 0;
    /** Hide the fish marker for 0.4 s out of every 3 s (tracking loss). */
    boolean fishLoss = false;
    /** Hold and release swapped (the bar goes left while held). */
    boolean invertHold = false;
    double gainRate = 0.09, lossRate = 0.06;
    // metrics over the reel: mean distance between bar and fish (bar widths), times the fish left the bar, time to get back, worst miss
    double errSum, errT, recSum, peakErr, curPeak, exitAt;
    int exits, recN;
    boolean wasInside = true;
    int toggles;

    // state
    St st = St.IDLE;
    double t;
    double barU = 1.5, barV, fishU = 1.5, fishTarget = 1.5, fishSpeed = 0.8, nextPick;
    double progress, reelT, biteAt, pressT, catchUntil, stunUntil;
    boolean effHold, lastCmd, knife_on, knifeUsed;
    double knifeUntil;
    int shakeHitsNeeded, btnX, btnY;
    boolean btnOn;
    final ArrayDeque<double[]> q = new ArrayDeque<>();

    // stats
    int catches, escapes, sjHits, sjDup, sjTaps, shakeHits, casts, resets;
    double reelTime, inBarTime;
    int knivesShown;

    Sim(double scale, double ox, double oy, long seed) throws Exception {
        this(scale, ox, oy, seed, false);
    }

    Sim(double scale, double ox, double oy, long seed, boolean std) throws Exception {
        this.std = std;
        // physics overrides for robustness sweeps: -Dsa -Dsg -Dsd -Dslat -Ddrop -Dfmul
        if (System.getProperty("sa") != null) A = Double.parseDouble(System.getProperty("sa"));
        if (System.getProperty("sg") != null) G = Double.parseDouble(System.getProperty("sg"));
        if (System.getProperty("sd") != null) Dr = Double.parseDouble(System.getProperty("sd"));
        if (Boolean.getBoolean("real")) latency = 0.10;
        if (System.getProperty("slat") != null) latency = Double.parseDouble(System.getProperty("slat"));
        if (System.getProperty("drop") != null) dropRate = Double.parseDouble(System.getProperty("drop"));
        if (System.getProperty("fmul") != null) fishSpeedMul = Double.parseDouble(System.getProperty("fmul"));
        if (std) { TL = S_TL; TR = S_TR; PW = S_BW; LO = TL / PW + 0.5; HI = TR / PW - 0.5; knifeEnabled = false; }
        this.s = scale;
        this.ox = ox;
        this.oy = oy;
        rnd = new Random(seed);
        ArrayFrame full = TestUtil.load(D + "bg_clean.png");
        ArrayFrame crop = new ArrayFrame(full.w, full.h - CROP_Y);
        System.arraycopy(full.px, CROP_Y * full.w, crop.px, 0, crop.px.length);
        base = scale == 1.0 ? crop : TestUtil.resize(crop, (int) Math.round(crop.w * scale), (int) Math.round(crop.h * scale));
        work = base.copy();
        pill = loadImg(D + "pill.png", scale);
        kunai = loadImg(D + "kunai.png", scale);
        knife = loadImg(D + "knife_patch.png", scale);
        ArrayFrame real = TestUtil.load(D + "real_ui.jpg");
        for (int i = 0; i < 24; i++) {
            filledCol[i] = real.px[(1462 + i) * real.w + 500];
            emptyCol[i] = real.px[(1462 + i) * real.w + 800];
        }
    }

    static Img loadImg(String path, double scale) throws Exception {
        BufferedImage im = ImageIO.read(new File(path));
        if (scale != 1.0) {
            int nw = (int) Math.round(im.getWidth() * scale), nh = (int) Math.round(im.getHeight() * scale);
            BufferedImage o = new BufferedImage(nw, nh, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = o.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.drawImage(im, 0, 0, nw, nh, null);
            g.dispose();
            im = o;
        }
        Img r = new Img();
        r.w = im.getWidth();
        r.h = im.getHeight();
        r.argb = new int[r.w * r.h];
        for (int y = 0; y < r.h; y++) for (int x = 0; x < r.w; x++) r.argb[y * r.w + x] = im.getRGB(x, y);
        return r;
    }

    double X(double x) { return x * s + ox; }
    double Y(double y) { return (y - CROP_Y) * s + oy; }

    // ---- Macro.Input ---------------------------------------------------------------------------

    @Override
    public void hold(boolean down) {
        if (t >= deadFrom && t < deadTo) return;
        if (down != lastCmd) {
            if (rnd.nextDouble() < dropRate) return;
            lastCmd = down;
            if (down) toggles++;
            q.add(new double[] {t + latency, down ? 1 : 0});
        }
    }

    @Override
    public void tap(float fx, float fy) {
        double px = fx * base.w, py = fy * base.h;
        if (st == St.SHAKE && btnOn) {
            double bw = 200 * s, bh = 80 * s;
            if (px >= btnX && px <= btnX + bw && py >= btnY && py <= btnY + bh) {
                shakeHits++;
                if (--shakeHitsNeeded <= 0) startReel();
                else placeButton();
            }
        }
        double dx = px - X(DOT_X), dy = py - Y(DOT_Y);
        boolean near = Math.hypot(dx, dy) <= 30 * s;
        if (near) sjTaps++;
        if (st == St.REEL && knife_on && near) {
            sjHits++;
            knife_on = false;
            knifeUsed = true;
            progress = Math.min(1.0, progress + 0.55);
            stunUntil = t + 4.0;
        } else if (near && st == St.REEL) {
            sjDup++;
        }
    }

    @Override
    public void pulse(int ms) {
        q.add(new double[] {t + latency, 1});
        q.add(new double[] {t + latency + ms / 1000.0, 0});
        pulses++;
    }

    int pulses;
    double pressEndT = -1;

    @Override
    public void pressFor(int ms) {
        q.add(new double[] {t + latency, 1});
        q.add(new double[] {t + latency + ms / 1000.0, 0});
        pressEndT = t + latency + ms / 1000.0;
        pressStartT = t + latency;
    }

    double pressStartT;

    @Override
    public int pressState() { return pressEndT < 0 ? 0 : (t >= pressEndT ? 1 : 0); }

    @Override
    public long pressMeasuredMs() { return Math.round((pressEndT - pressStartT) * 1000); }

    @Override
    public void resetInput() {
        resets++;
        deadTo = -1;
        q.clear();
        lastCmd = false;
    }

    // ---- game ----------------------------------------------------------------------------------

    void placeButton() {
        btnX = (int) (40 * s + rnd.nextDouble() * (base.w - 300 * s));
        btnY = (int) (20 * s + rnd.nextDouble() * 140 * s);
    }

    void startReel() {
        st = St.REEL;
        barU = 1.5;
        barV = 0;
        fishU = 1.5 + (rnd.nextDouble() - 0.5);
        fishTarget = fishU;
        nextPick = 0;
        progress = 0.3;
        reelT = 0;
        knife_on = false;
        knifeUsed = false;
        btnOn = false;
        q.clear();
        lastCmd = false;
        effHold = false;
    }

    void step(double dt) {
        t += dt;
        hist.addLast(new double[] {t, barU, fishU});
        while (hist.size() > 1 && hist.peekFirst()[0] < t - 1.5) hist.pollFirst();
        while (!q.isEmpty() && q.peek()[0] <= t) {
            boolean h = q.poll()[1] > 0;
            if (h && !effHold && st == St.IDLE) pressT = t;
            if (!h && effHold && st == St.IDLE && t - pressT >= 0.8) {
                casts++;
                st = St.BITE_WAIT;
                biteAt = t + 1.5 + rnd.nextDouble() * 2.0;
            }
            effHold = invertHold && st == St.REEL ? !h : h;
        }
        if (t >= deadFrom && t < deadTo) effHold = false;
        switch (st) {
            case BITE_WAIT:
                if (t >= biteAt) {
                    st = St.SHAKE;
                    shakeHitsNeeded = 3;
                    btnOn = true;
                    placeButton();
                }
                break;
            case REEL:
                reelT += dt;
                if (t >= nextPick) {
                    double lo = LO - 0.35, hi = HI + 0.35;
                    if (pattern == 1) {
                        fishTarget = lo + rnd.nextDouble() * (hi - lo);
                        fishSpeed = (1.3 + rnd.nextDouble() * 1.5) * fishSpeedMul;
                        if (rnd.nextDouble() < 0.2) fishSpeed = 3.0;
                        nextPick = t + 0.15 + rnd.nextDouble() * 0.55;
                    } else if (pattern == 2) {
                        fishTarget = fishU < (lo + hi) / 2 ? hi : lo;
                        fishSpeed = (1.8 + rnd.nextDouble() * 0.6) * fishSpeedMul;
                        nextPick = t + 0.9 + rnd.nextDouble() * 0.5;
                    } else {
                        fishTarget = lo + rnd.nextDouble() * (hi - lo);
                        fishSpeed = (0.4 + rnd.nextDouble() * 1.2) * fishSpeedMul;
                        nextPick = t + 0.4 + rnd.nextDouble() * 1.4;
                    }
                }
                if (t >= stunUntil) {
                    double d = fishTarget - fishU;
                    fishU += Math.signum(d) * Math.min(Math.abs(d), fishSpeed * dt);
                }
                double acc = effHold ? A : -G;
                barV += (acc - Dr * barV) * dt;
                barU += barV * dt;
                if (barU < LO) { barU = LO; if (barV < 0) barV = 0; }
                if (barU > HI) { barU = HI; if (barV > 0) barV = 0; }
                boolean inside = Math.abs(fishU - barU) <= 0.5;
                if (!(t >= deadFrom && t < deadTo)) { // time while inputs are cut is not counted: nothing can be done then
                    reelTime += dt;
                    if (inside) inBarTime += dt;
                }
                double dist = Math.abs(fishU - barU);
                errSum += dist * dt;
                errT += dt;
                if (reelT > 1.0) {
                    if (wasInside && !inside) { exits++; exitAt = t; curPeak = dist; }
                    else if (!inside) curPeak = Math.max(curPeak, dist);
                    else if (!wasInside && inside) { recSum += t - exitAt; recN++; peakErr = Math.max(peakErr, curPeak); }
                    wasInside = inside;
                }
                progress += (inside ? gainRate : -lossRate) * dt;
                if (knifeEnabled && !knife_on && !knifeUsed && reelT > 3.0) {
                    knife_on = true;
                    knifeUntil = t + 8;
                    knivesShown++;
                }
                if (knife_on && t > knifeUntil) { knife_on = false; knifeUsed = true; }
                if (progress >= 1.0) { catches++; st = St.CATCH; catchUntil = t + 1.2; knife_on = false; }
                else if (progress <= 0) { escapes++; st = St.IDLE; knife_on = false; }
                break;
            case CATCH:
                if (t >= catchUntil) st = St.IDLE;
                break;
            default:
                break;
        }
    }

    // ---- drawing -------------------------------------------------------------------------------

    static void blit(ArrayFrame f, Img im, int dx, int dy, boolean opaque) {
        for (int y = 0; y < im.h; y++) {
            int fy = dy + y;
            if (fy < 0 || fy >= f.h) continue;
            for (int x = 0; x < im.w; x++) {
                int fx = dx + x;
                if (fx < 0 || fx >= f.w) continue;
                int p = im.argb[y * im.w + x];
                if (opaque || (p >>> 24) >= 128) f.px[fy * f.w + fx] = p & 0xFFFFFF;
            }
        }
    }

    static void drawButton(ArrayFrame f, int x, int y, double s) {
        int w = (int) (200 * s), h = (int) (80 * s), b = Math.max(2, (int) (4 * s));
        for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) {
            boolean edge = i < b || j < b || i >= w - b || j >= h - b;
            f.set(x + i, y + j, edge ? 0x101010 : 0xE6E6E6);
        }
        for (int k = 0; k < 4; k++) {
            int bx = (int) ((24 + k * 42) * s), bw = (int) (26 * s), by = (int) ((26 + (k % 2) * 8) * s), bh = (int) (28 * s);
            for (int j = 0; j < bh; j++) for (int i = 0; i < bw; i++) f.set(x + bx + i, y + by + j, 0x202020);
        }
    }

    // capture latency + measurement jitter (-Dcaplat seconds, -Djit bar widths, or -Dreal=true for both plus slower touch)
    double capLat = Boolean.getBoolean("real") ? 0.10 : Double.parseDouble(System.getProperty("caplat", "0"));
    double jit = Boolean.getBoolean("real") ? 0.03 : Double.parseDouble(System.getProperty("jit", "0"));
    final ArrayDeque<double[]> hist = new ArrayDeque<>();

    ArrayFrame render() {
        if ((capLat <= 0 && jit <= 0) || st != St.REEL) return render0();
        double sb = barU, sf = fishU;
        double db = barU, df = fishU;
        for (double[] h : hist) { if (h[0] <= t - capLat) { db = h[1]; df = h[2]; } else break; }
        barU = db + rnd.nextGaussian() * jit;
        fishU = df + rnd.nextGaussian() * jit;
        ArrayFrame r = render0();
        barU = sb;
        fishU = sf;
        return r;
    }

    ArrayFrame render0() {
        System.arraycopy(base.px, 0, work.px, 0, base.px.length);
        if (st == St.SHAKE && btnOn) drawButton(work, btnX, btnY, s);
        if (st == St.REEL && std) {
            drawStd();
        } else if (st == St.REEL) {
            if (knife_on) blit(work, knife, (int) Math.round(X(330)), (int) Math.round(Y(930)), true);
            // progress meter
            int xa = (int) Math.round(X(384)), xb = (int) Math.round(X(885));
            int ya = (int) Math.round(Y(1462)), yb = (int) Math.round(Y(1483));
            double edge = X(378) + progress * 513 * s;
            for (int y = ya; y <= yb; y++) {
                int src = Math.max(0, Math.min(23, (int) Math.round((y - Y(1462)) / s)));
                for (int x = xa; x <= xb; x++) work.set(x, y, x < edge ? filledCol[src] : emptyCol[src]);
            }
            // control bar and fish marker
            blit(work, pill, (int) Math.round(X(barU * PW) - pill.w / 2.0), (int) Math.round(Y(1371)), false);
            blit(work, kunai, (int) Math.round(X(fishU * PW) - 19 * s), (int) Math.round(Y(1288)), false);
        }
        return work;
    }

    void fillRect(double x0, double y0, double x1, double y1, int rgb) {
        for (int y = (int) Math.round(y0); y < (int) Math.round(y1); y++)
            for (int x = (int) Math.round(x0); x < (int) Math.round(x1); x++) work.set(x, y, rgb);
    }

    /** Draws the default Fisch minigame UI as measured from a screenshot of it. */
    void drawStd() {
        double tl = X(S_TL), tr = X(S_TR), tt = Y(S_TT), tb = Y(S_TT + S_TH);
        // red end markers, track with a faint frame
        for (int k = 0; k < 2; k++) {
            double cx = k == 0 ? tl - 14 * s : tr + 14 * s;
            for (int j = 0; j < 14 * s; j++) for (int i = 0; i < (14 * s - j) ; i++) {
                int x = (int) Math.round(k == 0 ? cx - 6 * s + i * 0.6 : cx + 6 * s - i * 0.6);
                work.set(x, (int) Math.round((tt + tb) / 2 - 7 * s + j), 0x823a34);
            }
        }
        fillRect(tl - 1, tt - 1, tr + 1, tb + 1, 0x1d211f);
        fillRect(tl, tt, tr, tb, 0x131a17);
        // control bar
        double cxp = barPx();
        double hw = S_BW * s / 2;
        fillRect(cxp - hw, tt + 1, cxp + hw, tb - 1, 0xF1F1F1);
        // fish marker (hidden now and then when testing tracking loss)
        boolean hideFish = fishLoss && (t % 3.0) < 0.4;
        double fx = fishPx(), fw = S_FW * s, fh = S_FH * s, cy = (tt + tb) / 2;
        if (!hideFish) {
            fillRect(fx - fw / 2, cy - fh / 2, fx + fw / 2, cy + fh / 2, 0x485061);
            fillRect(fx - fw / 2 + 1, cy - fh / 2, fx + fw / 2 - 1, cy + fh / 2 - 0, 0x4A5260);
        }
        // progress meter: white fill from the left, dark remainder, thin lighter frame
        double ml = X(S_ML), mr = X(S_MR), mt = Y(S_MT), mb = Y(S_MT + S_MH);
        fillRect(ml - 1, mt - 1, mr + 1, mb + 1, 0x2a3a31);
        double edge = ml + Math.max(0, Math.min(1, progress)) * (mr - ml);
        fillRect(ml, mt, mr, mb, 0x141e19);
        fillRect(ml, mt, edge, mb, 0xFAFAF7);
    }

    double barPx() { return X(barU * PW); }
    double fishPx() { return X(fishU * PW); }
}
