import com.fischmacro.*;

import javax.imageio.ImageIO;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayDeque;
import java.util.Random;

/**
 * A stand-in for the game. It draws the REAL Zanshin Zen art (cut from the screenshot you sent) into
 * frames, moves the control bar with Fisch-style hold/release physics, and runs the whole cast, shake,
 * reel, catch cycle plus the Soul Judgement knife. The macro sees only pixels and can only press.
 * The physics numbers are invented, so this tests the logic, not the real game's feel.
 */
public class Sim implements Macro.Input {
    static final String D = "tools/testdata/";
    static final int CROP_Y = 850;
    static final double TL = 125.5, TR = 1143.5, PW = 413;
    static final double LO = TL / PW + 0.5, HI = TR / PW - 0.5;
    static final double DOT_X = 637, DOT_Y = 1154;

    static final class Img { int w, h; int[] argb; }

    enum St { IDLE, BITE_WAIT, SHAKE, REEL, CATCH }

    final double s, ox, oy;
    final ArrayFrame base, work;
    final Img pill, kunai, knife;
    final int[] filledCol = new int[24], emptyCol = new int[24];
    final Random rnd;

    // knobs
    double latency = 0.07, dropRate = 0.03, deadFrom = -1, deadTo = -1;
    boolean knifeEnabled = true;
    double A = 9, G = 11, Dr = 2.5;
    double fishSpeedMul = 1.0;

    // state
    St st = St.IDLE;
    double t;
    double barU = 1.5, barV, fishU = 1.5, fishTarget = 1.5, fishSpeed = 0.8, nextPick;
    double progress, reelT, biteAt, pressT, catchUntil, stunUntil;
    boolean effHold, lastCmd, knife_on, knifeUsed;
    double knifeUntil;
    int shakeHitsNeeded, btnX, btnY;
    boolean btnOn;
    final ArrayDeque<double[]> q = new ArrayDeque<>();

    // stats
    int catches, escapes, sjHits, sjDup, sjTaps, shakeHits, casts, resets;
    double reelTime, inBarTime;
    int knivesShown;

    Sim(double scale, double ox, double oy, long seed) throws Exception {
        this.s = scale;
        this.ox = ox;
        this.oy = oy;
        rnd = new Random(seed);
        ArrayFrame full = TestUtil.load(D + "bg_clean.png");
        ArrayFrame crop = new ArrayFrame(full.w, full.h - CROP_Y);
        System.arraycopy(full.px, CROP_Y * full.w, crop.px, 0, crop.px.length);
        base = scale == 1.0 ? crop : TestUtil.resize(crop, (int) Math.round(crop.w * scale), (int) Math.round(crop.h * scale));
        work = base.copy();
        pill = loadImg(D + "pill.png", scale);
        kunai = loadImg(D + "kunai.png", scale);
        knife = loadImg(D + "knife_patch.png", scale);
        ArrayFrame real = TestUtil.load(D + "real_ui.jpg");
        for (int i = 0; i < 24; i++) {
            filledCol[i] = real.px[(1462 + i) * real.w + 500];
            emptyCol[i] = real.px[(1462 + i) * real.w + 800];
        }
    }

    static Img loadImg(String path, double scale) throws Exception {
        BufferedImage im = ImageIO.read(new File(path));
        if (scale != 1.0) {
            int nw = (int) Math.round(im.getWidth() * scale), nh = (int) Math.round(im.getHeight() * scale);
            BufferedImage o = new BufferedImage(nw, nh, BufferedImage.TYPE_INT_ARGB);
            Graphics2D g = o.createGraphics();
            g.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g.drawImage(im, 0, 0, nw, nh, null);
            g.dispose();
            im = o;
        }
        Img r = new Img();
        r.w = im.getWidth();
        r.h = im.getHeight();
        r.argb = new int[r.w * r.h];
        for (int y = 0; y < r.h; y++) for (int x = 0; x < r.w; x++) r.argb[y * r.w + x] = im.getRGB(x, y);
        return r;
    }

    double X(double x) { return x * s + ox; }
    double Y(double y) { return (y - CROP_Y) * s + oy; }

    // ---- Macro.Input ---------------------------------------------------------------------------

    @Override
    public void hold(boolean down) {
        if (t >= deadFrom && t < deadTo) return;
        if (down != lastCmd) {
            if (rnd.nextDouble() < dropRate) return;
            lastCmd = down;
            q.add(new double[] {t + latency, down ? 1 : 0});
        }
    }

    @Override
    public void tap(float fx, float fy) {
        double px = fx * base.w, py = fy * base.h;
        if (st == St.SHAKE && btnOn) {
            double bw = 200 * s, bh = 80 * s;
            if (px >= btnX && px <= btnX + bw && py >= btnY && py <= btnY + bh) {
                shakeHits++;
                if (--shakeHitsNeeded <= 0) startReel();
                else placeButton();
            }
        }
        double dx = px - X(DOT_X), dy = py - Y(DOT_Y);
        boolean near = Math.hypot(dx, dy) <= 30 * s;
        if (near) sjTaps++;
        if (st == St.REEL && knife_on && near) {
            sjHits++;
            knife_on = false;
            knifeUsed = true;
            progress = Math.min(1.0, progress + 0.55);
            stunUntil = t + 4.0;
        } else if (near && st == St.REEL) {
            sjDup++;
        }
    }

    double pressEndT = -1;

    @Override
    public void pressFor(int ms) {
        q.add(new double[] {t + latency, 1});
        q.add(new double[] {t + latency + ms / 1000.0, 0});
        pressEndT = t + latency + ms / 1000.0;
        pressStartT = t + latency;
    }

    double pressStartT;

    @Override
    public int pressState() { return pressEndT < 0 ? 0 : (t >= pressEndT ? 1 : 0); }

    @Override
    public long pressMeasuredMs() { return Math.round((pressEndT - pressStartT) * 1000); }

    @Override
    public void resetInput() {
        resets++;
        deadTo = -1;
        q.clear();
        lastCmd = false;
    }

    // ---- game ----------------------------------------------------------------------------------

    void placeButton() {
        btnX = (int) (40 * s + rnd.nextDouble() * (base.w - 300 * s));
        btnY = (int) (20 * s + rnd.nextDouble() * 140 * s);
    }

    void startReel() {
        st = St.REEL;
        barU = 1.5;
        barV = 0;
        fishU = 1.5 + (rnd.nextDouble() - 0.5);
        fishTarget = fishU;
        nextPick = 0;
        progress = 0.3;
        reelT = 0;
        knife_on = false;
        knifeUsed = false;
        btnOn = false;
        q.clear();
        lastCmd = false;
        effHold = false;
    }

    void step(double dt) {
        t += dt;
        while (!q.isEmpty() && q.peek()[0] <= t) {
            boolean h = q.poll()[1] > 0;
            if (h && !effHold && st == St.IDLE) pressT = t;
            if (!h && effHold && st == St.IDLE && t - pressT >= 0.8) {
                casts++;
                st = St.BITE_WAIT;
                biteAt = t + 1.5 + rnd.nextDouble() * 2.0;
            }
            effHold = h;
        }
        if (t >= deadFrom && t < deadTo) effHold = false;
        switch (st) {
            case BITE_WAIT:
                if (t >= biteAt) {
                    st = St.SHAKE;
                    shakeHitsNeeded = 3;
                    btnOn = true;
                    placeButton();
                }
                break;
            case REEL:
                reelT += dt;
                if (t >= nextPick) {
                    double lo = LO - 0.35, hi = HI + 0.35;
                    fishTarget = lo + rnd.nextDouble() * (hi - lo);
                    fishSpeed = (0.4 + rnd.nextDouble() * 1.2) * fishSpeedMul;
                    nextPick = t + 0.4 + rnd.nextDouble() * 1.4;
                }
                if (t >= stunUntil) {
                    double d = fishTarget - fishU;
                    fishU += Math.signum(d) * Math.min(Math.abs(d), fishSpeed * dt);
                }
                double acc = effHold ? A : -G;
                barV += (acc - Dr * barV) * dt;
                barU += barV * dt;
                if (barU < LO) { barU = LO; if (barV < 0) barV = 0; }
                if (barU > HI) { barU = HI; if (barV > 0) barV = 0; }
                boolean inside = Math.abs(fishU - barU) <= 0.5;
                reelTime += dt;
                if (inside) inBarTime += dt;
                progress += (inside ? 0.09 : -0.06) * dt;
                if (knifeEnabled && !knife_on && !knifeUsed && reelT > 3.0) {
                    knife_on = true;
                    knifeUntil = t + 8;
                    knivesShown++;
                }
                if (knife_on && t > knifeUntil) { knife_on = false; knifeUsed = true; }
                if (progress >= 1.0) { catches++; st = St.CATCH; catchUntil = t + 1.2; knife_on = false; }
                else if (progress <= 0) { escapes++; st = St.IDLE; knife_on = false; }
                break;
            case CATCH:
                if (t >= catchUntil) st = St.IDLE;
                break;
            default:
                break;
        }
    }

    // ---- drawing -------------------------------------------------------------------------------

    static void blit(ArrayFrame f, Img im, int dx, int dy, boolean opaque) {
        for (int y = 0; y < im.h; y++) {
            int fy = dy + y;
            if (fy < 0 || fy >= f.h) continue;
            for (int x = 0; x < im.w; x++) {
                int fx = dx + x;
                if (fx < 0 || fx >= f.w) continue;
                int p = im.argb[y * im.w + x];
                if (opaque || (p >>> 24) >= 128) f.px[fy * f.w + fx] = p & 0xFFFFFF;
            }
        }
    }

    static void drawButton(ArrayFrame f, int x, int y, double s) {
        int w = (int) (200 * s), h = (int) (80 * s), b = Math.max(2, (int) (4 * s));
        for (int j = 0; j < h; j++) for (int i = 0; i < w; i++) {
            boolean edge = i < b || j < b || i >= w - b || j >= h - b;
            f.set(x + i, y + j, edge ? 0x101010 : 0xE6E6E6);
        }
        for (int k = 0; k < 4; k++) {
            int bx = (int) ((24 + k * 42) * s), bw = (int) (26 * s), by = (int) ((26 + (k % 2) * 8) * s), bh = (int) (28 * s);
            for (int j = 0; j < bh; j++) for (int i = 0; i < bw; i++) f.set(x + bx + i, y + by + j, 0x202020);
        }
    }

    ArrayFrame render() {
        System.arraycopy(base.px, 0, work.px, 0, base.px.length);
        if (st == St.SHAKE && btnOn) drawButton(work, btnX, btnY, s);
        if (st == St.REEL) {
            if (knife_on) blit(work, knife, (int) Math.round(X(330)), (int) Math.round(Y(930)), true);
            // progress meter
            int xa = (int) Math.round(X(384)), xb = (int) Math.round(X(885));
            int ya = (int) Math.round(Y(1462)), yb = (int) Math.round(Y(1483));
            double edge = X(378) + progress * 513 * s;
            for (int y = ya; y <= yb; y++) {
                int src = Math.max(0, Math.min(23, (int) Math.round((y - Y(1462)) / s)));
                for (int x = xa; x <= xb; x++) work.set(x, y, x < edge ? filledCol[src] : emptyCol[src]);
            }
            // control bar and fish marker
            blit(work, pill, (int) Math.round(X(barU * PW) - pill.w / 2.0), (int) Math.round(Y(1371)), false);
            blit(work, kunai, (int) Math.round(X(fishU * PW) - 19 * s), (int) Math.round(Y(1288)), false);
        }
        return work;
    }

    double barPx() { return X(barU * PW); }
    double fishPx() { return X(fishU * PW); }
}
