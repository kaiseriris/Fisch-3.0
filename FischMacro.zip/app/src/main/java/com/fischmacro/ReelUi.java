package com.fischmacro;

/**
 * Where the Zanshin Zen reel interface is on screen right now, in frame pixels. Everything is
 * measured from the picture, nothing is a fixed coordinate, so it follows the UI when it moves or
 * changes size.
 */
public final class ReelUi {
    // control bar (the black pill with the kanji)
    public double pillL, pillR, pillT, pillB;
    // progress meter (thin bar under the track)
    public double progL, progR, progT, progB;
    public boolean hasProgress;
    // overall confidence 0..1 and the parts it came from
    public double conf, sFill, sOutline, sKanji, sBlade, sProgress;

    public double pillW() { return pillR - pillL + 1; }
    public double pillH() { return pillB - pillT + 1; }
    public double pillCx() { return (pillL + pillR + 1) * 0.5; }
    public double pillCy() { return (pillT + pillB + 1) * 0.5; }

    /** Horizontal middle of the whole interface: the progress meter is centered on it. */
    public double anchorX() {
        return hasProgress ? (progL + progR + 1) * 0.5 : pillCx();
    }

    /** Estimated left end of the blade track. The blade is about twice as long as the progress meter. */
    public double trackL() {
        double half = hasProgress ? (progR - progL + 1) * 0.99 : pillW() * 2.5;
        return anchorX() - half;
    }

    public double trackR() {
        double half = hasProgress ? (progR - progL + 1) * 0.99 : pillW() * 2.5;
        return anchorX() + half;
    }

    public ReelUi copy() {
        ReelUi r = new ReelUi();
        r.pillL = pillL; r.pillR = pillR; r.pillT = pillT; r.pillB = pillB;
        r.progL = progL; r.progR = progR; r.progT = progT; r.progB = progB;
        r.hasProgress = hasProgress;
        r.conf = conf; r.sFill = sFill; r.sOutline = sOutline; r.sKanji = sKanji;
        r.sBlade = sBlade; r.sProgress = sProgress;
        return r;
    }
}
