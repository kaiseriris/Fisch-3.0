package com.fischmacro;

/**
 * Finds the shake button by matching a picture of it that the user taught once ("Teach shake" in the
 * dashboard). Matching is by brightness pattern, so it works wherever the button pops up on screen.
 * The game's exact button art could not be confirmed from public sources, which is why it is taught
 * instead of hard-coded.
 */
public final class ShakeFinder {

    public static final class Match {
        public int cx, cy;
        public double mad;
    }

    private int[] tpl;
    private int tw, th;
    private int[] tx = new int[0], ty = new int[0], tv = new int[0];

    public boolean has() { return tpl != null; }
    public int size() { return tw; }
    public int[] data() { return tpl; }

    /** Learns the button from a square patch around (cx, cy). Returns false if the patch is too flat to match reliably. */
    public boolean teach(Frame f, int cx, int cy, int size) {
        size = Math.max(24, Math.min(96, size)) & ~1;
        int x0 = Math.max(0, Math.min(f.w - size, cx - size / 2));
        int y0 = Math.max(0, Math.min(f.h - size, cy - size / 2));
        int[] d = new int[size * size];
        double sum = 0, sum2 = 0;
        for (int y = 0; y < size; y++) {
            for (int x = 0; x < size; x++) {
                int l = f.luma(x0 + x, y0 + y);
                d[y * size + x] = l;
                sum += l;
                sum2 += (double) l * l;
            }
        }
        double mean = sum / d.length, std = Math.sqrt(Math.max(0, sum2 / d.length - mean * mean));
        if (std < 14) return false;
        load(d, size);
        return true;
    }

    public void load(int[] luma, int size) {
        tpl = luma;
        tw = th = size;
        int n = 0;
        int step = Math.max(2, size / 14);
        int cnt = ((size + step - 1) / step) * ((size + step - 1) / step);
        tx = new int[cnt];
        ty = new int[cnt];
        tv = new int[cnt];
        for (int y = 0; y < size; y += step) {
            for (int x = 0; x < size; x += step) {
                tx[n] = x;
                ty[n] = y;
                tv[n] = luma[y * size + x];
                n++;
            }
        }
        if (n != cnt) {
            tx = java.util.Arrays.copyOf(tx, n);
            ty = java.util.Arrays.copyOf(ty, n);
            tv = java.util.Arrays.copyOf(tv, n);
        }
    }

    public void clear() {
        tpl = null;
    }

    /** @param maxMad largest mean brightness difference still counted as a match (about 12 to 30) */
    public Match find(Frame f, double maxMad) {
        if (tpl == null || f.w < tw || f.h < th) return null;
        int n = tx.length;
        double best = Double.MAX_VALUE;
        int bx = -1, by = -1;
        final int stride = 3;
        for (int y = 0; y <= f.h - th; y += stride) {
            for (int x = 0; x <= f.w - tw; x += stride) {
                double limit = Math.min(best, maxMad * 1.6) * n;
                double sum = 0;
                int k = 0;
                for (; k < n; k++) {
                    sum += Math.abs(f.luma(x + tx[k], y + ty[k]) - tv[k]);
                    if (sum > limit) break;
                }
                if (k == n && sum / n < best) {
                    best = sum / n;
                    bx = x;
                    by = y;
                }
            }
        }
        if (bx < 0) return null;
        // refine around the coarse hit
        for (int y = Math.max(0, by - stride); y <= Math.min(f.h - th, by + stride); y++) {
            for (int x = Math.max(0, bx - stride); x <= Math.min(f.w - tw, bx + stride); x++) {
                double sum = 0;
                for (int k = 0; k < n; k++) sum += Math.abs(f.luma(x + tx[k], y + ty[k]) - tv[k]);
                if (sum / n < best) {
                    best = sum / n;
                    bx = x;
                    by = y;
                }
            }
        }
        if (best > maxMad) return null;
        Match m = new Match();
        m.cx = bx + tw / 2;
        m.cy = by + th / 2;
        m.mad = best;
        return m;
    }
}
