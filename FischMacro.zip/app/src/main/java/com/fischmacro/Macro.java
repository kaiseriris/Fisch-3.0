package com.fischmacro;

/**
 * The whole fishing loop: cast -> wait for bite (shake) -> reel -> catch/escape -> cooldown -> cast.
 * Pure Java. The Android layer feeds it frames and a ticking clock, and gives it an Input to press with.
 * All calls must come from one thread.
 */
public final class Macro {

    public interface Input {
        /** Press (true) or lift (false) the finger at the configured hold point. */
        void hold(boolean down);
        /** One quick tap at a screen fraction. Any hold is released first by the caller. */
        void tap(float fx, float fy);
        /** Drop and re-establish the touch (used when presses are not reaching the game). */
        void resetInput();
        /** True once Android has confirmed that the latest press reached the screen. */
        default boolean pressAccepted() { return true; }
        /** Press and hold for exactly this many ms as ONE continuous touch (used to charge a cast). */
        void pressFor(int ms);
        /** 0 = pressing or not started, 1 = finished and confirmed, -1 = refused or cancelled. */
        int pressState();
        /** How long the last timed press really lasted. */
        long pressMeasuredMs();
    }

    public enum Stage { IDLE, CAST, WAIT_BITE, REEL, COOLDOWN }

    public final Config cfg;
    public final Diag diag;
    public final ReelFinder finder = new ReelFinder();
    public final ReelTracker tracker = new ReelTracker();
    public final ReelController ctl = new ReelController();
    public final SoulJudgement sj = new SoulJudgement();
    public final ShakeFinder shake = new ShakeFinder();
    public final ShakeWatcher watcher = new ShakeWatcher();
    private int castFails, autoTaps;

    private final Input in;
    private final ReelTracker.Measure meas = new ReelTracker.Measure();

    private volatile boolean running, paused, manual;
    private volatile Stage stage = Stage.IDLE;
    private long lastSoulMs = -100000, lastHighMs = -100000, stageStartMs, lastFrameMs, lastSearchMs, lastShakeMs, lastSjMs, lastGoodMs, lastStaleMs, castAtMs;
    private boolean castHeld;
    private double progress = -1, maxProgress;
    private int doneStreak, lowConf;

    // Soul Judgement activation: 0 idle, 1 released and waiting to tap, 2 tapped and verifying
    private int sjPhase, sjTries, sjMissing;
    private long sjAtMs, stunUntilMs;
    private float sjFx, sjFy;
    private double sjPre;

    public Macro(Config cfg, Diag diag, Input in) {
        this.cfg = cfg;
        this.diag = diag;
        this.in = in;
    }

    // ---- controls ------------------------------------------------------------------------------

    public void start(long nowNs) {
        long now = nowNs / 1_000_000L;
        running = true;
        paused = false;
        lastFrameMs = now;
        diag.event("Start");
        enter(cfg.autoCast ? Stage.CAST : Stage.WAIT_BITE, now);
    }

    public void pause() {
        if (!running) return;
        paused = true;
        in.hold(false);
        castHeld = false;
        diag.event("Paused");
        diag.stage = "Paused";
    }

    public void resume(long nowNs) {
        if (!running) return;
        long now = nowNs / 1_000_000L;
        paused = false;
        lastFrameMs = now;
        diag.event("Resumed");
        sjPhase = 0;
        tracker.unlock();
        enter(cfg.autoCast ? Stage.CAST : Stage.WAIT_BITE, now);
    }

    public void stop() {
        running = false;
        paused = false;
        castHeld = false;
        sjPhase = 0;
        in.hold(false);
        tracker.unlock();
        stage = Stage.IDLE;
        diag.stage = "Idle";
        diag.event("Stopped");
    }

    /** Manual override: keep watching but send no inputs, so you can play yourself. */
    public void setManual(boolean m) {
        manual = m;
        if (m) in.hold(false);
        diag.event(m ? "Manual override ON" : "Manual override OFF");
    }

    /** Throw away the current lock and search the whole screen again. */
    public void recalibrate() {
        tracker.unlock();
        lastSearchMs = 0;
        diag.researches++;
        diag.event("Recalibrating");
    }

    public boolean isRunning() { return running; }
    public boolean isPaused() { return paused; }
    public boolean isManual() { return manual; }
    public Stage stage() { return stage; }
    public double progress() { return progress; }
    public ReelTracker.Measure lastMeasure() { return meas; }
    public boolean wantsFastFrames() { return running && !paused && stage == Stage.REEL; }

    private boolean canAct() { return running && !paused && !manual; }

    private void hold(boolean h) {
        in.hold(canAct() && h);
    }

    private void enter(Stage s, long now) {
        stage = s;
        stageStartMs = now;
        castHeld = false;
        diag.stage = s.name();
        if (s == Stage.WAIT_BITE) { watcher.reset(); autoTaps = 0; }
        if (s != Stage.WAIT_BITE) diag.detail = "";
        if (s == Stage.CAST || s == Stage.COOLDOWN || s == Stage.WAIT_BITE) hold(false);
    }

    // ---- frames --------------------------------------------------------------------------------

    public void onFrame(Frame f, long nowNs) {
        long now = nowNs / 1_000_000L;
        diag.clockMs = now;
        lastFrameMs = now;
        diag.frames++;
        if (!running || paused) return;
        long t0 = System.nanoTime();
        try {
            if (stage == Stage.WAIT_BITE) waitBite(f, now);
            else if (stage == Stage.REEL) reel(f, nowNs, now);
        } catch (RuntimeException e) {
            diag.event("vision error: " + e);
        }
        diag.procMsAvg = 0.9 * diag.procMsAvg + 0.1 * (System.nanoTime() - t0) / 1e6;
    }

    private void waitBite(Frame f, long now) {
        // 1. Is the reel minigame on screen? Look often, and get a little more forgiving the longer we wait.
        if (now - lastSearchMs >= 100) {
            lastSearchMs = now;
            diag.searches++;
            double tol = cfg.detectionTolerance * (1.0 + Math.min(0.3, (now - stageStartMs) / 40000.0));
            ReelUi ui = finder.search(f, tol);
            diag.reelConf = ui == null ? finder.lastBest : ui.conf;
            if (ui != null) {
                startReel(ui, now);
                return;
            }
        }
        // 2. Shake prompt: a taught button if there is one, otherwise a new button-sized object that appears.
        if (cfg.autoShake && now - stageStartMs > 500) {
            float tx = -1, ty = -1;
            if (shake.has()) {
                if (now - lastShakeMs >= 200) {
                    lastShakeMs = now;
                    ShakeFinder.Match mt = shake.find(f, 14.0 * cfg.detectionTolerance + 4);
                    diag.shakeConf = mt == null ? 0 : Math.max(0, 1.0 - mt.mad / 30.0);
                    if (mt != null) {
                        tx = (float) mt.cx / f.w;
                        ty = (float) mt.cy / f.h;
                    }
                }
            } else {
                ShakeWatcher.Hit h = watcher.update(f, now);
                diag.shakeConf = watcher.lastBlob > 0 ? Math.min(1.0, watcher.lastBlob / 0.06) : 0;
                if (h != null) {
                    tx = h.fx;
                    ty = h.fy;
                }
            }
            if (tx >= 0 && canAct()) {
                in.tap(tx, ty);
                diag.shakeTaps++;
                autoTaps++;
                lastShakeMs = now + 60;
                diag.event(String.format("Shake tap at %.0f%%, %.0f%%", tx * 100, ty * 100));
            }
        }
        diag.detail = String.format("waiting %ds, shake taps %d, reel match %.0f%%",
                (now - stageStartMs) / 1000, autoTaps, diag.reelConf * 100);
    }

    private void startReel(ReelUi ui, long now) {
        tracker.lock(ui);
        ctl.reset();
        sj.reset();
        sjPhase = 0;
        sjTries = 0;
        stunUntilMs = 0;
        progress = -1;
        maxProgress = 0;
        lastHighMs = -100000;
        doneStreak = 0;
        lowConf = 0;
        lastGoodMs = now;
        diag.pillWidthPx = ui.pillW();
        diag.pillHeightPx = ui.pillH();
        diag.event(String.format("Reel found (conf %.2f, bar %.0fpx)", ui.conf, ui.pillW()));
        enter(Stage.REEL, now);
    }

    private void reel(Frame f, long nowNs, long now) {
        if (!tracker.locked()) {
            relock(f, now, "lost");
            if (now - lastGoodMs > 1500) finishReel(nearEnd(now), now);
            return;
        }
        tracker.track(f, meas);
        diag.reelConf = meas.conf;
        diag.fishConf = meas.fishFound ? meas.fishConf : 0;
        if (meas.ok) {
            lastGoodMs = now;
            ReelUi ui = tracker.model();
            diag.pillWidthPx = ui.pillW();
            diag.pillHeightPx = ui.pillH();
            if (meas.progressOk) {
                progress = meas.progress;
                maxProgress = Math.max(maxProgress, progress);
                if (progress >= 0.8) lastHighMs = now;
                diag.progress = progress;
                diag.progressConf = meas.progressConf;
            }
            boolean stunned = now < stunUntilMs;
            boolean h = ctl.update(meas, ui, nowNs, cfg.sensitivity, stunned);
            diag.modelA = ctl.A;
            diag.modelG = ctl.G;
            diag.modelD = ctl.D;
            diag.latencyMs = ctl.lat * 1000;
            diag.inputInverted = ctl.invert;
            diag.inputHealth = ctl.health;
            if (ctl.needReset) {
                ctl.needReset = false;
                diag.recoveries++;
                diag.event("Presses not reaching the game: re-sending touch");
                in.resetInput();
            }
            if (sjPhase == 0 && cfg.autoReel) hold(h);
            else if (sjPhase == 0) in.hold(false);

            // automatic recalibration: low confidence for a while, or the UI changed size/position
            if (meas.conf < 0.5) lowConf++; else lowConf = 0;
            if ((lowConf >= 12 || tracker.geometryChanged) && now - lastSearchMs >= 500) {
                tracker.geometryChanged = false;
                lowConf = 0;
                relock(f, now, "low confidence or resize");
            }
            if (cfg.soulJudgement) handleSoul(f, ui, now);

            if (progress >= 0.99) {
                if (++doneStreak >= 4) finishReel(true, now);
            } else doneStreak = 0;
        } else {
            if (now - lastGoodMs > 350) in.hold(false);
            if (tracker.failStreak >= 6) relock(f, now, "lost");
            if (now - lastGoodMs > (nearEnd(now) ? 500 : 1500)) finishReel(nearEnd(now), now);
        }
    }

    private boolean nearEnd(long now) {
        // a landed Soul Judgement adds ~55%, so a reel that ended soon after one was almost surely caught
        return progress >= 0.4 || now - lastHighMs < 2500 || (progress >= 0.25 && now - lastSoulMs < 10000);
    }

    private void relock(Frame f, long now, String why) {
        if (now - lastSearchMs < 200) return;
        lastSearchMs = now;
        diag.researches++;
        ReelUi ui = finder.search(f, cfg.detectionTolerance);
        if (ui != null) {
            ReelUi cur = tracker.model();
            if (cur != null && meas.ok && (ui.pillW() < 0.7 * cur.pillW() || ui.pillW() > 1.4 * cur.pillW())
                    && !"lost".equals(why)) {
                diag.event(String.format("Ignored odd re-lock candidate (%.0f px vs %.0f px)", ui.pillW(), cur.pillW()));
                return;
            }
            tracker.lock(ui);
            lastGoodMs = now;
            diag.event(String.format("Reel re-locked [%s] (conf %.2f)", why, ui.conf));
        }
    }

    private void finishReel(boolean caught, long now) {
        in.hold(false);
        tracker.unlock();
        sjPhase = 0;
        if (caught) {
            diag.catches++;
            diag.event("Caught a fish");
        } else {
            diag.escapes++;
            diag.event("Fish escaped / reel lost");
        }
        enter(Stage.COOLDOWN, now);
    }

    // ---- Soul Judgement -----------------------------------------------------------------------

    private void handleSoul(Frame f, ReelUi ui, long now) {
        if (sjPhase == 1) {
            if (now >= sjAtMs) {
                if (canAct()) in.tap(sjFx, sjFy);
                sjPhase = 2;
                sjAtMs = now + 1300;
                sjTries++;
                lastSjMs = now;
                sjMissing = 0;
            }
            return;
        }
        if (now - lastSjMs < 150) return;
        lastSjMs = now;
        SoulJudgement.Target t = sj.find(f, ui.pillT, cfg.detectionTolerance);
        diag.sjConf = t == null ? 0 : t.conf;
        if (sjPhase == 0) {
            if (t != null && sj.ready(t, now)) {
                if (!canAct()) return;
                sjFx = (float) (t.cx / f.w);
                sjFy = (float) (t.cy / f.h);
                sjPre = progress;
                sjPhase = 1;
                sjAtMs = now + 90;
                in.hold(false);
                diag.event("Soul Judgement ready: tapping centre");
            } else if (t == null) {
                sj.ready(null, now);
            }
        } else if (sjPhase == 2) {
            if (t == null) sjMissing++; else sjMissing = 0;
            boolean jump = progress >= 0 && sjPre >= 0 && progress - sjPre >= 0.2;
            if (jump || sjMissing >= 2) {
                stunUntilMs = now + 4000;
                lastSoulMs = now;
                sj.fired(now);
                diag.soulCount++;
                diag.event(String.format("Soul Judgement landed%s; fish stunned 4s",
                        jump ? String.format(" (+%.0f%% progress)", (progress - sjPre) * 100) : ""));
                sjPhase = 0;
                sjTries = 0;
            } else if (now >= sjAtMs) {
                if (sjTries < 3) {
                    sjPhase = 1;
                    sjAtMs = now + 90;
                    diag.event("Soul Judgement tap not confirmed: retrying");
                } else {
                    sj.fired(now);
                    sjPhase = 0;
                    sjTries = 0;
                    diag.event("Soul Judgement gave up after 3 taps");
                }
            }
        }
    }

    // ---- clock ---------------------------------------------------------------------------------

    public void tick(long nowNs) {
        long now = nowNs / 1_000_000L;
        if (!running || paused) return;
        if (now - lastFrameMs > 2500) {
            in.hold(false);
            if (now - lastStaleMs > 5000) {
                lastStaleMs = now;
                diag.event("No screen frames for 2.5 s");
            }
            return;
        }
        switch (stage) {
            case CAST:
                if (!castHeld) {
                    if (now - stageStartMs >= cfg.stageSettleMs && canAct()) {
                        castHeld = true;
                        castAtMs = now;
                        in.pressFor(cfg.castHoldMs);
                    }
                } else {
                    int ps = in.pressState();
                    if (ps == 1) {
                        long real = in.pressMeasuredMs();
                        castHeld = false;
                        diag.casts++;
                        castFails = 0;
                        diag.event("Cast: held " + real + " ms (asked " + cfg.castHoldMs + ")");
                        if (real < cfg.castHoldMs * 0.8) diag.event("Warning: the press ended early; raise the cast hold time");
                        enter(Stage.WAIT_BITE, now);
                    } else if (ps < 0 || now - castAtMs > cfg.castHoldMs + 2000) {
                        castHeld = false;
                        in.resetInput();
                        castFails++;
                        diag.recoveries++;
                        diag.event("Cast press was not completed by Android (" + castFails + "); trying again");
                        stageStartMs = now + 600;
                    }
                }
                break;
            case WAIT_BITE:
                if (now - stageStartMs > cfg.biteTimeoutMs) {
                    diag.recoveries++;
                    diag.event("No bite or shake: casting again");
                    enter(cfg.autoCast ? Stage.CAST : Stage.WAIT_BITE, now);
                }
                break;
            case COOLDOWN:
                if (now - stageStartMs >= cfg.cooldownMs) enter(cfg.autoCast ? Stage.CAST : Stage.WAIT_BITE, now);
                break;
            case REEL:
                if (now - stageStartMs > 90000) {
                    diag.recoveries++;
                    diag.event("Reel took over 90 s: resetting");
                    finishReel(false, now);
                }
                break;
            default:
                break;
        }
    }
}
