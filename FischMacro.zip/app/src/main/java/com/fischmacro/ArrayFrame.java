package com.fischmacro;

/** A frame held in an int array (0xRRGGBB per pixel). Used by tests and by the Android capture code. */
public final class ArrayFrame extends Frame {
    public final int[] px;

    public ArrayFrame(int w, int h) {
        super(w, h);
        px = new int[w * h];
    }

    public ArrayFrame(int w, int h, int[] pixels) {
        super(w, h);
        px = pixels;
    }

    @Override
    public int rgb(int x, int y) {
        return px[y * w + x];
    }

    public void set(int x, int y, int rgb) {
        if (x >= 0 && y >= 0 && x < w && y < h) px[y * w + x] = rgb & 0xFFFFFF;
    }

    public ArrayFrame copy() {
        return new ArrayFrame(w, h, px.clone());
    }
}
