package com.fischmacro;

/**
 * Finds the Soul Judgement graphic: a large chrome knife with a diamond hanging under it whose centre
 * is a black dot. The dot is the thing to tap.
 *
 * Detection: a round, near-black blob (the dot), surrounded by bright metal (the diamond), with a wide
 * band of chrome above it (the blade). The blade check is what rules out other dark round things.
 */
public final class SoulJudgement {

    public static final class Target {
        public double cx, cy, r, conf;
        public double sRound, sRing, sBlade;
    }

    private final DarkShapes shapes = new DarkShapes();
    private Target last;
    private int stable;
    private long lockoutUntilMs;
    public static final int STABLE_NEEDED = 2;

    public void reset() {
        last = null;
        stable = 0;
        lockoutUntilMs = 0;
    }

    /** @param yEnd only look above this row (the reel bar), so the reel art cannot be mistaken for it */
    public Target find(Frame f, double yEnd, double tolerance) {
        int yMax = (int) Math.min(f.h, yEnd > 0 ? yEnd : f.h);
        int minRun = Math.max(3, (int) (f.w * 0.008));
        shapes.find(f, (int) (f.h * 0.10), yMax, 55, minRun);
        double tol = Math.max(0.6, Math.min(1.5, tolerance));
        Target best = null;
        for (int i = 0; i < shapes.count; i++) {
            int w = shapes.maxX[i] - shapes.minX[i] + 1, h = shapes.maxY[i] - shapes.minY[i] + 1;
            if (w < f.w * 0.012 || w > f.w * 0.09 || h < f.w * 0.012) continue;
            double aspect = (double) w / h;
            if (aspect < 0.8 || aspect > 1.25) continue;
            double fill = (double) shapes.area[i] / (w * h);
            if (fill < 0.62 || fill > 0.92) continue;
            Target t = new Target();
            t.cx = (shapes.minX[i] + shapes.maxX[i] + 1) * 0.5;
            t.cy = (shapes.minY[i] + shapes.maxY[i] + 1) * 0.5;
            t.r = 0.25 * (w + h);
            t.sRound = 1.0 - Math.min(1.0, Math.abs(fill - 0.785) / 0.15);
            t.sRing = ring(f, t);
            t.sBlade = blade(f, t);
            t.conf = 0.2 * t.sRound + 0.4 * t.sRing + 0.4 * t.sBlade;
            if (t.sRing < 0.5 || t.sBlade < 0.4) continue;
            if (best == null || t.conf > best.conf) best = t;
        }
        if (best == null || best.conf < 0.55 / tol) return null;
        return best;
    }

    /** Fraction of points on a circle around the dot (1.4 to 2.0 radii out) that are bright metal. */
    private double ring(Frame f, Target t) {
        int hit = 0, tot = 0;
        for (double k = 1.4; k <= 2.0; k += 0.3) {
            for (int a = 0; a < 24; a++) {
                double th = a * Math.PI / 12;
                int x = (int) Math.round(t.cx + k * t.r * Math.cos(th));
                int y = (int) Math.round(t.cy + k * t.r * Math.sin(th));
                int l = f.lumaSafe(x, y);
                if (l < 0) continue;
                tot++;
                if (l > 110) hit++;
            }
        }
        return tot < 20 ? 0 : (double) hit / tot;
    }

    /** Fraction of a wide band above the dot that is bright (the chrome blade). */
    private double blade(Frame f, Target t) {
        double dd = 2 * t.r;
        int hit = 0, tot = 0;
        for (double dy = 1.6; dy <= 4.0; dy += 0.2) {
            int y = (int) Math.round(t.cy - dy * dd);
            for (double dx = -5.5; dx <= 5.5; dx += 0.2) {
                int x = (int) Math.round(t.cx + dx * dd);
                int l = f.lumaSafe(x, y);
                if (l < 0) continue;
                tot++;
                if (l > 140) hit++;
            }
        }
        if (tot < 100) return 0;
        double frac = (double) hit / tot;
        return Math.min(1.0, frac / 0.35);
    }

    /** True once the same target has been seen steadily and we are not locked out after a recent hit. */
    public boolean ready(Target t, long nowMs) {
        if (t == null) {
            stable = 0;
            last = null;
            return false;
        }
        if (last != null && Math.hypot(t.cx - last.cx, t.cy - last.cy) <= 0.6 * t.r) stable++;
        else stable = 1;
        last = t;
        return stable >= STABLE_NEEDED && nowMs >= lockoutUntilMs;
    }

    public void fired(long nowMs) {
        lockoutUntilMs = nowMs + 8000;
        stable = 0;
        last = null;
    }

    public boolean lockedOut(long nowMs) {
        return nowMs < lockoutUntilMs;
    }
}
