package com.fischmacro;

import java.util.List;

/**
 * Fits the bar's response model (dv/dt = (held ? A : -G) - D*v, with an input delay) to a recorded probe: the bar's
 * position over time while the screen was held and released on a known schedule. Positions are in bar widths.
 * Plain coordinate search with several starting points; no libraries.
 */
final class ProbeFit {
    private ProbeFit() {}

    /** @return {A, G, D, lat, rmsError} or null when the bar did not move enough or the fit is poor. */
    static double[] fit(List<double[]> samples, List<double[]> cmds, double a0, double g0, double d0, double l0) {
        int n = samples.size();
        if (n < 20 || cmds.isEmpty()) return null;
        double[][] s = samples.toArray(new double[0][]);
        double[][] c = cmds.toArray(new double[0][]);
        double lo = 1e9, hi = -1e9;
        for (double[] p : s) { lo = Math.min(lo, p[1]); hi = Math.max(hi, p[1]); }
        if (hi - lo < 0.12) return null;
        lo -= 0.03;
        hi += 0.03;

        double[] best = null;
        double bestE = 1e18;
        double[] as = {a0, 5, 10, 18}, gs = {g0, 5, 10, 18}, ds = {d0, 1, 3, 6}, ls = {l0, 0.06, 0.12};
        for (double A : as) for (double G : gs) for (double D : ds) for (double L : ls) {
            double[] p = {A, G, D, L, 0};
            double e = err(s, c, p, lo, hi);
            double sa = 1.3, sl = 0.02, sv = 1.0;
            for (int round = 0; round < 28; round++) {
                boolean any = false;
                for (int k = 0; k < 5; k++) {
                    for (int dir = -1; dir <= 1; dir += 2) {
                        double[] q = p.clone();
                        if (k < 3) q[k] = dir > 0 ? q[k] * sa : q[k] / sa;
                        else if (k == 3) q[k] += dir * sl;
                        else q[k] += dir * sv;
                        q[0] = clamp(q[0], 2, 40); q[1] = clamp(q[1], 2, 40); q[2] = clamp(q[2], 0.2, 12);
                        q[3] = clamp(q[3], 0.02, 0.4); q[4] = clamp(q[4], -6, 6);
                        double e2 = err(s, c, q, lo, hi);
                        if (e2 < e) { e = e2; p = q; any = true; }
                    }
                }
                if (!any) { sa = 1 + (sa - 1) * 0.6; sl *= 0.6; sv *= 0.6; }
            }
            if (e < bestE) { bestE = e; best = p; }
        }
        if (best == null || bestE > 0.2) return null;
        return new double[] {best[0], best[1], best[2], best[3], bestE};
    }

    private static double clamp(double v, double a, double b) { return Math.max(a, Math.min(b, v)); }

    /** RMS distance (bar widths) between the simulated and the seen bar positions. */
    private static double err(double[][] s, double[][] c, double[] p, double lo, double hi) {
        double A = p[0], G = p[1], D = p[2], lat = p[3];
        double pos = s[0][1], v = p[4], dt = 0.005, sum = 0;
        int si = 0, ci = 0, n = 0;
        boolean cmd = false;
        double tEnd = s[s.length - 1][0];
        for (double t = s[0][0]; t <= tEnd; t += dt) {
            double tc = t - lat;
            while (ci < c.length && c[ci][0] <= tc) { cmd = c[ci][1] > 0.5; ci++; }
            v += ((cmd ? A : -G) - D * v) * dt;
            pos += v * dt;
            if (pos < lo) { pos = lo; if (v < 0) v = 0; }
            if (pos > hi) { pos = hi; if (v > 0) v = 0; }
            while (si < s.length && s[si][0] <= t) {
                double d = pos - s[si][1];
                sum += d * d;
                n++;
                si++;
            }
        }
        return n == 0 ? 1e9 : Math.sqrt(sum / n);
    }
}
