package com.fischmacro;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.View;

/**
 * Small live picture of what the macro is looking at: a shrunken copy of the captured screen with the control bar (green),
 * the fish (red), the progress meter (blue), the shake button (yellow) and the Soul Judgement target (magenta) drawn on it,
 * plus the confidence of each detection underneath.
 */
final class PreviewView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG), bg = new Paint();
    private Bitmap bmp;
    private int[] lastPx;

    PreviewView(Context c) {
        super(c);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(3);
        txt.setColor(Color.WHITE);
        txt.setTextSize(22);
        txt.setTypeface(android.graphics.Typeface.MONOSPACE);
        bg.setColor(Color.argb(200, 0, 0, 0));
    }

    @Override
    protected void onDraw(Canvas cv) {
        Diag d = Shared.diag;
        int[] px = d.thumb;
        int tw = d.thumbW, th = d.thumbH;
        int w = getWidth();
        cv.drawRect(0, 0, w, getHeight(), bg);
        if (px == null || tw <= 0) {
            cv.drawText("Live view: waiting for the first captured frame...", 8, 30, txt);
            return;
        }
        if (bmp == null || bmp.getWidth() != tw || bmp.getHeight() != th) bmp = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888);
        if (px != lastPx) {
            bmp.setPixels(px, 0, tw, 0, 0, tw, th);
            lastPx = px;
        }
        float sc = (float) w / tw;
        int ph = Math.round(th * sc);
        cv.drawBitmap(bmp, null, new Rect(0, 0, w, ph), null);

        double[] v = d.vis;
        long now = System.nanoTime() / 1_000_000L;
        if (v != null) {
            double sx = w / v[5], sy = ph / v[6];
            p.setColor(Color.rgb(60, 255, 90));
            cv.drawRect((float) (v[0] * sx), (float) (v[1] * sy), (float) ((v[2] + 1) * sx), (float) ((v[3] + 1) * sy), p);
            if (v[4] >= 0) {
                p.setColor(Color.rgb(255, 60, 60));
                float fx = (float) (v[4] * sx);
                float bh = (float) ((v[3] - v[1]) * sy);
                cv.drawLine(fx, (float) (v[1] * sy) - bh, fx, (float) (v[3] * sy) + bh * 0.3f, p);
            }
            if (v.length >= 14 && v[10] >= 0) {
                p.setColor(Color.rgb(80, 160, 255));
                cv.drawRect((float) (v[10] * sx), (float) (v[11] * sy), (float) ((v[12] + 1) * sx), (float) ((v[13] + 1) * sy), p);
            }
        }
        mark(cv, d.shakeMark, w, ph, Color.YELLOW, now);
        mark(cv, d.soulMark, w, ph, Color.MAGENTA, now);

        String via = v == null ? "-" : (v[9] > 1.5 ? "colour" : "shape");
        float y = ph + 26;
        String[] lines = {
            String.format("%s  via %s", d.stage, via),
            String.format("bar %3.0f%%  fish %3.0f%%  meter %3.0f%%", d.reelConf * 100, d.fishConf * 100, d.progressConf * 100),
            String.format("shake %3.0f%%  soul %3.0f%%  caught %d", d.shakeConf * 100, d.sjConf * 100, d.catches),
            d.detail == null ? "" : d.detail,
            "green=bar red=fish blue=meter yellow=shake pink=soul"
        };
        for (String s : lines) {
            cv.drawText(s, 8, y, txt);
            y += 26;
        }
    }

    private void mark(Canvas cv, double[] m, int w, int ph, int color, long nowMs) {
        if (m == null) return;
        // the marks carry the macro's own clock, which differs from ours, so just keep showing the latest one
        p.setColor(color);
        float x = (float) (m[0] * w), y = (float) (m[1] * ph);
        cv.drawCircle(x, y, 18, p);
    }
}
