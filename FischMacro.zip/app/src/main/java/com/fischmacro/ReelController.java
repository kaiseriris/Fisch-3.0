package com.fischmacro;

/**
 * Predictive reel controller. Replaces the old duty-cycle controller.
 *
 * It keeps a small physics model of the control bar (how fast it speeds up while the screen is held,
 * how fast it falls back when released, and drag), learns that model live from what it sees, and every
 * frame picks "hold" or "release" by simulating both a short time ahead (including the input delay) and
 * choosing the one that ends closer to where the fish will be. Because it decides from a prediction,
 * holds and releases come out as long, purposeful presses instead of fast flutter, which is what makes
 * the bar actually move.
 *
 * All positions are measured in control-bar widths, so the same numbers work at any UI size.
 */
public final class ReelController {

    // learned model: dv/dt = (pushing ? A : -G) - D*v   (units: bar widths per second)
    public double A = 10, G = 10, D = 3;
    /** Input delay in seconds (touch -> game reacts -> we see it). Measured live. */
    public double lat = 0.09;
    public boolean invert;
    /** Set false to freeze the model (used by tests). */
    public boolean learn = true;
    public int health = 100;
    public boolean needReset;
    // the last model that a proper fit produced; restored when dead input has poisoned the live estimate
    private double goodA = 10, goodG = 10, goodD = 3, goodLat = 0.09;

    /** Call when the current model came from a trustworthy fit. */
    public void markGood() { goodA = A; goodG = G; goodD = D; goodLat = lat; }
    public boolean lastHold;

    private static final int N = 96;
    private final long[] hT = new long[N];
    private final boolean[] hP = new boolean[N];
    private int hCount, hHead;

    private boolean inited, push;
    private long lastT, lastFlipT, lastResetT;
    private double cMin = 1e9, cMax = -1e9;
    private double c, v, f, vf, vPrev, vAtFlip, lo, hi;
    private boolean awaitingResponse;
    private int invVotes, invRel;

    public void reset() {
        inited = false;
        pendingPulseMs = 0;
        pulseEndNs = 0;
        cMin = 1e9;
        cMax = -1e9;
        hCount = 0;
        hHead = 0;
        push = false;
        health = 100;
        needReset = false;
        awaitingResponse = false;
        invVotes = 0;
        invRel = 0;
        vf = 0;
        v = 0;
        smN = 0;
        hvN = 0;
        runStart = 0;
        stuckT = 0;
        forceUntil = 0;
        dI = 0;
    }

    private void record(long t, boolean p) {
        hHead = (hHead + 1) % N;
        hT[hHead] = t;
        hP[hHead] = p;
        if (hCount < N) hCount++;
    }

    /** The effective (push-right) command that was in force at time t. */
    private boolean cmdAt(long t) {
        for (int i = 0; i < hCount; i++) {
            int k = (hHead - i + N) % N;
            if (hT[k] <= t) return hP[k];
        }
        return hCount > 0 ? hP[(hHead - hCount + 1 + N) % N] : false;
    }

    /** @return true if the screen should be held down now. */
    public boolean update(ReelTracker.Measure m, ReelUi ui, long tNs, double sens, boolean stunned) {
        double pw = Math.max(8, m.pillR - m.pillL + 1);
        // Keep all positions in the same screen-origin coordinate system, scaled by pill width.
        // The first real measurement seeds the observed range; never include the Java default c=0.
        double cNow = (m.pillL + m.pillR + 1) * 0.5 / pw;
        double nextLo = ui.trackL() / pw + 0.5;
        double nextHi = ui.trackR() / pw - 0.5;
        if (nextHi < nextLo + 0.3) {
            double mid = (nextLo + nextHi) * 0.5;
            nextLo = mid - 0.6;
            nextHi = mid + 0.6;
        }

        if (!inited) {
            inited = true;
            c = cNow;
            f = m.fishFound ? m.fishX / pw : cNow;
            cMin = cMax = cNow;
            lo = Math.min(nextLo, cNow);
            hi = Math.max(nextHi, cNow);
            v = 0;
            vf = 0;
            vPrev = 0;
            lastT = tNs;
            lastFlipT = tNs;
            push = false;
            record(tNs, false);
            lastHold = false;
            return false;
        }

        lo = nextLo;
        hi = nextHi;
        // Widen only from positions actually observed after initialization.
        if (c < cMin) cMin = c;
        if (c > cMax) cMax = c;
        lo = Math.min(lo, cMin);
        hi = Math.max(hi, cMax);
        double dt = (tNs - lastT) / 1e9;
        lastT = tNs;
        if (dt < 0.004) dt = 0.004;
        if (dt > 0.12) dt = 0.12;

        // alpha-beta filters
        double pc = c + v * dt, rc = cNow - pc;
        c = pc + 0.85 * rc;
        v += 0.55 * rc / dt;
        double pf = f + vf * dt;
        if (m.fishFound) {
            // Confidence-weighted alpha-beta update. A weak visual match should correct the
            // prediction gently instead of yanking the estimated fish position across the track.
            double conf = Math.max(0.0, Math.min(1.0, m.fishConf));
            // Confidence-weighted correction: a strong match is trusted fully, a weak one only nudges the estimate.
            double alpha = Math.min(0.6, 0.22 + 0.8 * conf);
            double beta = Math.min(0.35, 0.06 + 0.5 * conf);
            double rf = m.fishX / pw - pf;
            double maxCorrection = 0.6 + 0.4 * conf;
            rf = Math.max(-maxCorrection, Math.min(maxCorrection, rf));
            f = pf + alpha * rf;
            vf += beta * rf / dt;
            // Limit implausible one-frame velocity spikes caused by a false marker match.
            vf = Math.max(-5.0, Math.min(5.0, vf));
        } else {
            // When covered by the bar, retain the last trajectory briefly. Gently constrain
            // the position to the bar rather than snapping it to centre on every missing frame.
            double hid = Math.max(c - 0.5, Math.min(c + 0.5, pf));
            f = hid + hiddenPull * (c - hid);
            vf *= hiddenVf;
        }
        if (stunned) vf = 0;

        if (learn) {
            learn(dt, tNs);
            measureLatency(tNs);
        }
        checkResponse(dt, tNs);
        if (probeUntil > tNs && !pulseMode) {
            if (push != probePush) {
                push = probePush;
                lastFlipT = tNs;
                record(tNs, push);
            }
            boolean moved = probeUp ? v > 0.8 && c < hi - 0.3 : v < -0.8 && c > lo + 0.3;
            if (moved && (tNs - probeFrom) / 1e9 > 0.15) {
                invert = !invert;
                invVotes = 0;
                invRel = 0;
                A = 10; G = 10; D = 3;
                smN = 0;
                hCount = 0;
                probeUntil = 0;
                health = 100;
                record(tNs, push);
            }
            vPrev = v;
            lastHold = push ^ invert;
            return lastHold;
        }

        // ---- choose hold / release by looking ahead -------------------------------------
        // Candidate plans: "do X now, switch to the opposite after tau" (tau=0 means the opposite from the start,
        // tau>=horizon means X throughout). Each plan is simulated through the input delay and scored by how far the
        // bar stays from the predicted fish along the whole path, so braking and overshoot are accounted for.
        double s = Math.max(0.5, Math.min(2.0, sens));
        double H = lat + Math.max(0.30, Math.min(0.70, (stunned ? HZ + 0.1 : HZ) / s));
        double fv = stunned ? 0 : vf;
        if (pulseMode) {
            // Each push is ONE committed touch of a chosen length (it cannot be cut short once sent), so pick the length
            // that the look-ahead likes best, then wait for it to end before deciding again.
            if (push && tNs >= pulseEndNs) {
                push = false;
                lastFlipT = tNs;
                record(tNs, false);
            }
            if (!push && (tNs - lastFlipT) / 1e9 >= MIN_GAP) {
                double bp = 1e18, bt = 0;
                for (int ti = 0; ti < TAUS.length; ti++) {
                    if (TAUS[ti] < MIN_PULSE) continue;
                    double cost = plan(true, TAUS[ti], tNs, H, f, fv, stunned ? 0.2 : 0.1);
                    if (cost < bp) { bp = cost; bt = Math.min(TAUS[ti], MAX_PULSE); }
                }
                double br = plan(false, 9, tNs, H, f, fv, stunned ? 0.2 : 0.1);
                if (bp < br - 0.002) {
                    push = true;
                    pulseEndNs = tNs + (long) (bt * 1e9);
                    pendingPulseMs = (int) Math.round(bt * 1000);
                    lastFlipT = tNs;
                    vAtFlip = v;
                    awaitingResponse = true;
                    record(tNs, true);
                }
            }
            vPrev = v;
            lastHold = push;
            return lastHold;
        }
        // ---- steady follow ------------------------------------------------------------------------------------------------
        // e = where the fish is relative to where the bar is heading (in bar widths).
        //   fish well to the right of the bar centre -> hold,   fish well to the left -> let go,
        //   fish around the middle of the bar        -> click quickly (hold/release inside every period) so the bar hovers there.
        // While hovering, the share of each period spent holding follows the error and the bar speed, plus a slowly learned
        // balance point, so it needs no assumed physics beyond "hold moves right".
        if (steady && !pulseMode) {
            double L = Math.max(0.05, Math.min(0.35, lat)) + 0.08;
            double cp = c + Math.max(-1.2, Math.min(1.2, v * L));
            double fp = f + (stunned ? 0 : Math.max(-0.8, Math.min(0.8, vf * L * 0.6)));
            double e = fp - cp;
            double Z = Math.max(0.08, steadyBand);
            double sec = (tNs - lastFlipT) / 1e9;
            boolean want = push;
            // The calculator: where would the bar be, relative to the fish, over the next moment if the screen were held (or
            // let go) completely? If only one of those keeps the fish inside the bar, do that one. If both do, the fish is in the
            // middle and the bar is kept there with quick clicks; if neither does, chase the fish with a full hold or release.
            double Hh = lat + 0.35;
            double wRel = reach(false, tNs, Hh, f, stunned ? 0 : vf);
            double wHold = reach(true, tNs, Hh, f, stunned ? 0 : vf);
            double fit = 0.38;
            boolean relOk = wRel <= fit, holdOk = wHold <= fit;
            boolean hover = (relOk && holdOk) || (!relOk && !holdOk && Math.abs(e) <= Z);
            if (relOk && !holdOk) {
                want = false;
            } else if (holdOk && !relOk) {
                want = true;
            } else if (!hover) {
                want = e > 0;
            } else {
                double dtI = Math.min(dt, 0.1);
                dI = Math.max(-0.3, Math.min(0.3, dI + 0.4 * e * dtI));
                double d = 0.5 + dI + 1.5 * e - 0.12 * v;
                d = Math.max(0.15, Math.min(0.85, d));
                double per = Math.max(0.08, steadyPeriod);
                if (push) want = sec < d * per;
                else want = sec >= (1 - d) * per;
            }
            lastWRel = wRel; lastWHold = wHold;
            double minSw = hover ? 0.0 : steadyMin;
            if (want != push && sec >= minSw) {
                push = want;
                lastFlipT = tNs;
                vAtFlip = v;
                awaitingResponse = true;
                record(tNs, push);
            }
            vPrev = v;
            lastHold = push ^ invert;
            return lastHold;
        }
        // ---- model-free rescue: bar sitting still while the fish is clearly on the other side ----------------------------
        // Whatever the model, the filters or the input-health logic believe, a bar that has not moved for half a second while a
        // clearly visible fish is a full bar width away must be pushed towards it. The push is held for 0.6 s so the planner
        // cannot cancel it at once. If even that does not move the bar, the hold direction is assumed wrong and flipped.
        final boolean rescueOn = !NO_RESCUE;
        if (rescueOn && forceUntil != 0 && tNs >= forceUntil) {
            forceUntil = 0;
            if (Math.abs(c - cAtForce) < 0.12 && (tNs - lastInvFlipT) / 1e9 > 1.0) {
                invert = !invert;
                lastInvFlipT = tNs;
                A = 10; G = 10; D = 3;
                smN = 0;
                invVotes = 0; invRel = 0;
                hCount = 0;
                forcedFlips++;
            }
        }
        if (forceUntil > tNs) {
            vPrev = v;
            lastHold = push ^ invert;
            return lastHold;
        }
        {
            boolean fishClear = rescueOn && m.fishFound && m.fishConf > 0.3 && !stunned;
            double off = f - c;
            boolean wantRight = fishClear && off > 0.8, wantLeft = fishClear && off < -0.8;
            boolean wrong = (wantRight && !push) || (wantLeft && push);
            if (wrong && Math.abs(v) < 0.6) stuckT += dt; else stuckT = 0;
            if (stuckT > 0.5) {
                stuckT = 0;
                push = wantRight;
                lastFlipT = tNs;
                vAtFlip = v;
                awaitingResponse = true;
                forceUntil = tNs + 600_000_000L;
                cAtForce = c;
                forcedPushes++;
                record(tNs, push);
                vPrev = v;
                lastHold = push ^ invert;
                return lastHold;
            }
        }
        double bestPush = 1e18, bestRel = 1e18;
        for (int first = 0; first < 2; first++) {
            boolean x = first == 0;
            for (int ti = 0; ti < TAUS.length; ti++) {
                // "X first, then the opposite after tau": a plan that starts with X for less than the shortest allowed press is
                // really the opposite plan, and counting it on both sides made the two choices tie (the bar could sit at a wall
                // holding while the fish was far away). So each side only gets plans that really commit to X.
                if (TAUS[ti] < Math.max(minFlip, 0.04) - 1e-9) continue;
                double cost = plan(x, TAUS[ti], tNs, H, f, fv, stunned ? 0.2 : 0.1);
                if (x) bestPush = Math.min(bestPush, cost); else bestRel = Math.min(bestRel, cost);
            }
        }
        double cur = push ? bestPush : bestRel, other = push ? bestRel : bestPush;
        boolean want = push;
        if (other < cur * HY - 0.002 && (tNs - lastFlipT) / 1e9 >= minFlip) want = !push;
        if (want != push) {
            push = want;
            lastFlipT = tNs;
            vAtFlip = v;
            awaitingResponse = true;
            record(tNs, push);
        }
        vPrev = v;
        lastHold = push ^ invert;
        return lastHold;
    }

    // ---- model learning: least squares over the last ~2 s of samples, pulled gently toward sane defaults ----
    private static final int W = 60;
    private final double[] smV = new double[W], smD = new double[W], smP = new double[W];
    private int smN, smI, sinceSolve;
    private final double[] hv = new double[3], ht = new double[3];
    private int hvN;

    private void learn(double dt, long tNs) {
        double tNow = tNs / 1e9;
        for (int i = 2; i > 0; i--) { hv[i] = hv[i - 1]; ht[i] = ht[i - 1]; }
        hv[0] = v;
        ht[0] = tNow;
        if (hvN < 3) { hvN++; return; }
        double span = ht[0] - ht[2];
        if (span <= 0.02 || span > 0.2) return;
        if ((c <= lo + 0.02 && v < 0.2) || (c >= hi - 0.02 && v > -0.2)) return;
        double dvdt = (hv[0] - hv[2]) / span;
        double p = 0.5 * ((cmdAt((long) ((ht[0] - lat) * 1e9)) ? 1 : 0) + (cmdAt((long) ((ht[2] - lat) * 1e9)) ? 1 : 0));
        smV[smI] = 0.5 * (hv[0] + hv[2]);
        smD[smI] = Math.max(-80, Math.min(80, dvdt));
        smP[smI] = p;
        smI = (smI + 1) % W;
        if (smN < W) smN++;
        if (++sinceSolve >= 6 && smN >= 20) {
            sinceSolve = 0;
            solve();
        }
    }

    private void solve() {
        double[][] M = new double[3][4];
        double[] prior = {10, 10, 3};
        for (int i = 0; i < smN; i++) {
            double p = smP[i];
            double[] x = {p, -(1 - p), -smV[i]};
            for (int r = 0; r < 3; r++) {
                for (int q = 0; q < 3; q++) M[r][q] += x[r] * x[q];
                M[r][3] += x[r] * smD[i];
            }
        }
        double lam = 4.0;
        for (int r = 0; r < 3; r++) { M[r][r] += lam; M[r][3] += lam * prior[r]; }
        for (int col = 0; col < 3; col++) {
            int piv = col;
            for (int r = col + 1; r < 3; r++) if (Math.abs(M[r][col]) > Math.abs(M[piv][col])) piv = r;
            double[] tmp = M[col]; M[col] = M[piv]; M[piv] = tmp;
            if (Math.abs(M[col][col]) < 1e-9) return;
            for (int r = 0; r < 3; r++) {
                if (r == col) continue;
                double fct = M[r][col] / M[col][col];
                for (int q = col; q < 4; q++) M[r][q] -= fct * M[col][q];
            }
        }
        double nA = M[0][3] / M[0][0], nG = M[1][3] / M[1][1], nD = M[2][3] / M[2][2];
        A = 0.6 * A + 0.4 * Math.max(3, Math.min(60, nA));
        G = 0.6 * G + 0.4 * Math.max(3, Math.min(60, nG));
        D = 0.6 * D + 0.4 * Math.max(0.1, Math.min(12, nD));
    }

    private void measureLatency(long tNs) {
        if (!awaitingResponse) return;
        double since = (tNs - lastFlipT) / 1e9;
        double dv = v - vAtFlip;
        boolean responded = push ? dv > 0.3 : dv < -0.3;
        if (responded) {
            awaitingResponse = false;
            double meas = since - 0.3 / Math.max(2, push ? A : G);
            lat = 0.8 * lat + 0.2 * Math.max(0.02, Math.min(0.25, meas));
        } else if (since > 0.5) {
            awaitingResponse = false;
        }
    }

    private boolean runCmd;
    private long runStart;
    // After a stretch where the input seemed to do nothing, try the opposite command briefly: if THAT moves the bar the way the
    // first command should have, the hold direction is simply inverted; if nothing moves either way, the input is dead.
    private long probeUntil, probeFrom;
    private boolean probePush, probeUp;
    private double runPeak, runTrough;

    /**
     * Detects inputs that never reach the game, a stuck touch, and an inverted hold direction. A dead input shows as ONE long
     * unbroken hold (or release) during which the bar never moved the way it should; short alternating holds that keep the
     * bar still are normal and must not count.
     */
    private void checkResponse(double dt, long tNs) {
        boolean pDel = cmdAt(tNs - (long) (lat * 1e9));
        if (runStart == 0 || pDel != runCmd) {
            runCmd = pDel;
            runStart = tNs;
            runPeak = v;
            runTrough = v;
        } else {
            runPeak = Math.max(runPeak, v);
            runTrough = Math.min(runTrough, v);
        }
        double runLen = (tNs - runStart) / 1e9;
        boolean noResp = runCmd
                ? (runLen > (pulseMode ? 0.22 : 0.5) && runPeak < 0.3 && c < hi - 0.3 && c < cMax - 0.12)
                : (runLen > (pulseMode ? 0.5 : 0.5) && runTrough > -0.3 && c > lo + 0.3 && c > cMin + 0.12);
        if (noResp) {
            health = Math.max(0, health - (int) Math.ceil(dt * 80));
            if (health < 50 && (tNs - lastResetT) / 1e9 > 1.5) {
                needReset = true;
                lastResetT = tNs;
                // whatever was learned while the input was dead is wrong: go back to the last good model
                A = goodA; G = goodG; D = goodD; lat = goodLat;
                smN = 0;
                health = 70;
                probePush = !runCmd;
                probeUp = runCmd;
                probeFrom = tNs;
                probeUntil = tNs + 900_000_000L;
                runStart = 0;
            }
        } else if (health < 100) {
            health = Math.min(100, health + 1);
        }
        // Hold direction inverted? Then holding makes the bar fall AND releasing makes it rise. Dead input only shows the first
        // half (the bar falls whatever we do), so both halves are required before the direction is flipped.
        double steady = (tNs - lastFlipT) / 1e9;
        if (steady > 0.35) {
            if (push) {
                if (v < -0.8 && c > lo + 0.3) invVotes++;
                else if (v > 0.8) invVotes = Math.max(0, invVotes - 2);
            } else {
                if (v > 0.8 && c < hi - 0.3) invRel++;
                else if (v < -0.8) invRel = Math.max(0, invRel - 2);
            }
        }
        if (invVotes >= 12 && invRel >= 12) {
            invert = !invert;
            invVotes = 0;
            invRel = 0;
            A = 10; G = 10; D = 3;
            smN = 0;
            hCount = 0;
            record(tNs, push);
        }
    }

    private static final boolean NO_RESCUE = Boolean.getBoolean("norescue");
    private double stuckT, cAtForce;
    private long forceUntil, lastInvFlipT;
    public int forcedPushes, forcedFlips;
    static final double HY = 1.0;
    /** Planning horizon (s), how far ahead the fish is extrapolated (gain), and extra cost for being outside the bar. */
    /** While the fish is hidden inside the bar: how strongly the estimate is pulled to the bar centre, and how fast its speed estimate fades. */
    public double hiddenPull = 0.12, hiddenVf = 0.7;
    public double HZ = 0.25, fishGain = 1.4, outPen = 8, outAt = 0.25;
    /** Longest single press and shortest gap between presses, in seconds (set from Config). */
    /** Follow mode: shortest time the screen stays held or released before it may switch (seconds). */
    public double minFlip = 0.12;
    public double MAX_PULSE = 0.60, MIN_GAP = 0.15, MIN_PULSE = 0.18;
    /** true: each push is one committed touch (see update); false: the screen is held and released continuously. */
    public boolean pulseMode;
    /** Steady follow: dead-band controller with look-ahead; see update(). */
    public boolean steady = false;
    public double steadyMin = 0.10, steadyBand = 0.30, steadyPeriod = 0.20;
    private double dI;
    private long pulseEndNs;
    private int pendingPulseMs;

    /** Length in ms of a new press to send now (0 if none). Only used in pulse mode. */
    public int takePulse() {
        int p = pendingPulseMs;
        pendingPulseMs = 0;
        return p;
    }
    private static final double[] TAUS = {0, 0.04, 0.08, 0.12, 0.18, 0.26, 0.4, 0.6, 9};

    /** Cost of: command x from now (after the input delay) until tau, then the opposite. Lower is better. */
    private double lastWRel, lastWHold;

    /** Largest distance (bar widths) between the bar and the fish over the next H seconds if x (hold) or !x is done from now on. */
    private double reach(boolean x, long tNs, double H, double fish, double fishV) {
        double cc = c, vv = v, dt = 0.01, worst = 0;
        int steps = (int) Math.ceil(H / dt);
        for (int i = 0; i < steps; i++) {
            double tm = i * dt;
            boolean p = tm < lat ? cmdAt(tNs + (long) ((tm - lat) * 1e9)) : x;
            vv += ((p ? A : -G) - D * vv) * dt;
            cc += vv * dt;
            if (cc < lo) { cc = lo; if (vv < 0) vv = 0; }
            if (cc > hi) { cc = hi; if (vv > 0) vv = 0; }
            double ft = Math.max(lo - 0.3, Math.min(hi + 0.3, fish + fishV * Math.min(tm, 0.4) * 0.8));
            worst = Math.max(worst, Math.abs(cc - ft));
        }
        return worst;
    }

    private double plan(boolean x, double tau, long tNs, double H, double fish, double fishV, double velW) {
        double cc = c, vv = v, dt = 0.01, cost = 0;
        int steps = (int) Math.ceil(H / dt);
        for (int i = 0; i < steps; i++) {
            double tm = i * dt;
            boolean p;
            if (tm < lat) p = cmdAt(tNs + (long) ((tm - lat) * 1e9));
            else p = (tm - lat < tau) ? x : !x;
            double acc = p ? A : -G;
            vv += (acc - D * vv) * dt;
            cc += vv * dt;
            if (cc < lo) { cc = lo; if (vv < 0) vv = 0; }
            if (cc > hi) { cc = hi; if (vv > 0) vv = 0; }
            double ft = fish + fishV * Math.min(tm, 0.4) * fishGain;
            ft = Math.max(lo - 0.3, Math.min(hi + 0.3, ft));
            double d = Math.abs(cc - ft);
            cost += (d + outPen * Math.max(0, d - outAt)) * dt;
        }
        // end state: should not be racing away from the fish
        double ftEnd = Math.max(lo - 0.3, Math.min(hi + 0.3, fish + fishV * Math.min(H, 0.4) * fishGain));
        cost += velW * 0.3 * Math.abs(vv - fishV) + 0.15 * Math.max(0, (cc - ftEnd) * Math.signum(vv) ) * Math.min(1, Math.abs(vv)) * 0;
        return cost;
    }

    public double cEst() { return c; }
    public double loEst() { return lo; }
    public double hiEst() { return hi; }
    public double fEst() { return f; }
    public double barVel() { return v; }
    public double fishVel() { return vf; }
}
