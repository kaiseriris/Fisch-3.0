package com.fischmacro;

/**
 * Predictive reel controller. Replaces the old duty-cycle controller.
 *
 * It keeps a small physics model of the control bar (how fast it speeds up while the screen is held,
 * how fast it falls back when released, and drag), learns that model live from what it sees, and every
 * frame picks "hold" or "release" by simulating both a short time ahead (including the input delay) and
 * choosing the one that ends closer to where the fish will be. Because it decides from a prediction,
 * holds and releases come out as long, purposeful presses instead of fast flutter, which is what makes
 * the bar actually move.
 *
 * All positions are measured in control-bar widths, so the same numbers work at any UI size.
 */
public final class ReelController {

    // learned model: dv/dt = (pushing ? A : -G) - D*v   (units: bar widths per second)
    public double A = 10, G = 10, D = 3;
    /** Input delay in seconds (touch -> game reacts -> we see it). Measured live. */
    public double lat = 0.09;
    public boolean invert;
    /** Set false to freeze the model (used by tests). */
    public boolean learn = true;
    public int health = 100;
    public boolean needReset;
    public boolean lastHold;

    private static final int N = 96;
    private final long[] hT = new long[N];
    private final boolean[] hP = new boolean[N];
    private int hCount, hHead;

    private boolean inited, push;
    private long lastT, lastFlipT, lastResetT;
    private double cMin = 1e9, cMax = -1e9;
    private double c, v, f, vf, vPrev, vAtFlip, lo, hi;
    private boolean awaitingResponse;
    private int invVotes;

    public void reset() {
        inited = false;
        pendingPulseMs = 0;
        pulseEndNs = 0;
        cMin = 1e9;
        cMax = -1e9;
        hCount = 0;
        hHead = 0;
        push = false;
        health = 100;
        needReset = false;
        awaitingResponse = false;
        invVotes = 0;
        vf = 0;
        v = 0;
        smN = 0;
        hvN = 0;
        pushDur = relDur = posVel = negVel = 0;
    }

    private void record(long t, boolean p) {
        hHead = (hHead + 1) % N;
        hT[hHead] = t;
        hP[hHead] = p;
        if (hCount < N) hCount++;
    }

    /** The effective (push-right) command that was in force at time t. */
    private boolean cmdAt(long t) {
        for (int i = 0; i < hCount; i++) {
            int k = (hHead - i + N) % N;
            if (hT[k] <= t) return hP[k];
        }
        return hCount > 0 ? hP[(hHead - hCount + 1 + N) % N] : false;
    }

    /** @return true if the screen should be held down now. */
    public boolean update(ReelTracker.Measure m, ReelUi ui, long tNs, double sens, boolean stunned) {
        double pw = Math.max(8, m.pillR - m.pillL + 1);
        double cNow = (m.pillL + m.pillR + 1) * 0.5 / pw;
        lo = ui.trackL() / pw + 0.5;
        hi = ui.trackR() / pw - 0.5;
        if (hi < lo + 0.3) { double mid = (lo + hi) * 0.5; lo = mid - 0.6; hi = mid + 0.6; }
        // the bar can never be somewhere the track does not reach: if it has been seen outside our estimate, widen it
        if (c < cMin) cMin = c;
        if (c > cMax) cMax = c;
        lo = Math.min(lo, cMin);
        hi = Math.max(hi, cMax);

        if (!inited) {
            inited = true;
            c = cNow;
            f = m.fishFound ? m.fishX / pw : cNow;
            v = 0;
            vf = 0;
            vPrev = 0;
            lastT = tNs;
            lastFlipT = tNs;
            push = false;
            record(tNs, false);
            lastHold = false;
            return false;
        }
        double dt = (tNs - lastT) / 1e9;
        lastT = tNs;
        if (dt < 0.004) dt = 0.004;
        if (dt > 0.12) dt = 0.12;

        // alpha-beta filters
        double pc = c + v * dt, rc = cNow - pc;
        c = pc + 0.85 * rc;
        v += 0.55 * rc / dt;
        double pf = f + vf * dt;
        if (m.fishFound) {
            double rf = m.fishX / pw - pf;
            f = pf + 0.6 * rf;
            vf += 0.35 * rf / dt;
        } else {
            // not seen: it is most likely hidden inside the (dark) control bar, so keep it there
            double hid = Math.max(c - 0.5, Math.min(c + 0.5, pf));
            f = hid + 0.04 * (c - hid) * 3;
            vf *= 0.7;
        }
        if (stunned) vf = 0;

        if (learn) {
            learn(dt, tNs);
            measureLatency(tNs);
        }
        checkResponse(dt, tNs);

        // ---- choose hold / release by looking ahead -------------------------------------
        // Candidate plans: "do X now, switch to the opposite after tau" (tau=0 means the opposite from the start,
        // tau>=horizon means X throughout). Each plan is simulated through the input delay and scored by how far the
        // bar stays from the predicted fish along the whole path, so braking and overshoot are accounted for.
        double s = Math.max(0.5, Math.min(2.0, sens));
        double H = lat + Math.max(0.30, Math.min(0.70, (stunned ? HZ + 0.1 : HZ) / s));
        double fv = stunned ? 0 : vf;
        if (pulseMode) {
            // Each push is ONE committed touch of a chosen length (it cannot be cut short once sent), so pick the length
            // that the look-ahead likes best, then wait for it to end before deciding again.
            if (push && tNs >= pulseEndNs) {
                push = false;
                lastFlipT = tNs;
                record(tNs, false);
            }
            if (!push && (tNs - lastFlipT) / 1e9 >= MIN_GAP) {
                double bp = 1e18, bt = 0;
                for (int ti = 0; ti < TAUS.length; ti++) {
                    if (TAUS[ti] < MIN_PULSE) continue;
                    double cost = plan(true, TAUS[ti], tNs, H, f, fv, stunned ? 0.2 : 0.1);
                    if (cost < bp) { bp = cost; bt = Math.min(TAUS[ti], MAX_PULSE); }
                }
                double br = plan(false, 9, tNs, H, f, fv, stunned ? 0.2 : 0.1);
                if (bp < br - 0.002) {
                    push = true;
                    pulseEndNs = tNs + (long) (bt * 1e9);
                    pendingPulseMs = (int) Math.round(bt * 1000);
                    lastFlipT = tNs;
                    vAtFlip = v;
                    awaitingResponse = true;
                    record(tNs, true);
                }
            }
            vPrev = v;
            lastHold = push;
            return lastHold;
        }
        double bestPush = 1e18, bestRel = 1e18;
        for (int first = 0; first < 2; first++) {
            boolean x = first == 0;
            for (int ti = 0; ti < TAUS.length; ti++) {
                double cost = plan(x, TAUS[ti], tNs, H, f, fv, stunned ? 0.2 : 0.1);
                if (x) bestPush = Math.min(bestPush, cost); else bestRel = Math.min(bestRel, cost);
            }
        }
        double cur = push ? bestPush : bestRel, other = push ? bestRel : bestPush;
        boolean want = push;
        if (other < cur * HY - 0.002 && (tNs - lastFlipT) / 1e9 >= minFlip) want = !push;
        if (want != push) {
            push = want;
            lastFlipT = tNs;
            vAtFlip = v;
            awaitingResponse = true;
            record(tNs, push);
        }
        vPrev = v;
        lastHold = push ^ invert;
        return lastHold;
    }

    // ---- model learning: least squares over the last ~2 s of samples, pulled gently toward sane defaults ----
    private static final int W = 60;
    private final double[] smV = new double[W], smD = new double[W], smP = new double[W];
    private int smN, smI, sinceSolve;
    private final double[] hv = new double[3], ht = new double[3];
    private int hvN;

    private void learn(double dt, long tNs) {
        double tNow = tNs / 1e9;
        for (int i = 2; i > 0; i--) { hv[i] = hv[i - 1]; ht[i] = ht[i - 1]; }
        hv[0] = v;
        ht[0] = tNow;
        if (hvN < 3) { hvN++; return; }
        double span = ht[0] - ht[2];
        if (span <= 0.02 || span > 0.2) return;
        if ((c <= lo + 0.02 && v < 0.2) || (c >= hi - 0.02 && v > -0.2)) return;
        double dvdt = (hv[0] - hv[2]) / span;
        double p = 0.5 * ((cmdAt((long) ((ht[0] - lat) * 1e9)) ? 1 : 0) + (cmdAt((long) ((ht[2] - lat) * 1e9)) ? 1 : 0));
        smV[smI] = 0.5 * (hv[0] + hv[2]);
        smD[smI] = Math.max(-80, Math.min(80, dvdt));
        smP[smI] = p;
        smI = (smI + 1) % W;
        if (smN < W) smN++;
        if (++sinceSolve >= 6 && smN >= 20) {
            sinceSolve = 0;
            solve();
        }
    }

    private void solve() {
        double[][] M = new double[3][4];
        double[] prior = {10, 10, 3};
        for (int i = 0; i < smN; i++) {
            double p = smP[i];
            double[] x = {p, -(1 - p), -smV[i]};
            for (int r = 0; r < 3; r++) {
                for (int q = 0; q < 3; q++) M[r][q] += x[r] * x[q];
                M[r][3] += x[r] * smD[i];
            }
        }
        double lam = 4.0;
        for (int r = 0; r < 3; r++) { M[r][r] += lam; M[r][3] += lam * prior[r]; }
        for (int col = 0; col < 3; col++) {
            int piv = col;
            for (int r = col + 1; r < 3; r++) if (Math.abs(M[r][col]) > Math.abs(M[piv][col])) piv = r;
            double[] tmp = M[col]; M[col] = M[piv]; M[piv] = tmp;
            if (Math.abs(M[col][col]) < 1e-9) return;
            for (int r = 0; r < 3; r++) {
                if (r == col) continue;
                double fct = M[r][col] / M[col][col];
                for (int q = col; q < 4; q++) M[r][q] -= fct * M[col][q];
            }
        }
        double nA = M[0][3] / M[0][0], nG = M[1][3] / M[1][1], nD = M[2][3] / M[2][2];
        A = 0.6 * A + 0.4 * Math.max(1, Math.min(60, nA));
        G = 0.6 * G + 0.4 * Math.max(1, Math.min(60, nG));
        D = 0.6 * D + 0.4 * Math.max(0.1, Math.min(12, nD));
    }

    private void measureLatency(long tNs) {
        if (!awaitingResponse) return;
        double since = (tNs - lastFlipT) / 1e9;
        double dv = v - vAtFlip;
        boolean responded = push ? dv > 0.3 : dv < -0.3;
        if (responded) {
            awaitingResponse = false;
            double meas = since - 0.3 / Math.max(2, push ? A : G);
            lat = 0.8 * lat + 0.2 * Math.max(0.02, Math.min(0.25, meas));
        } else if (since > 0.5) {
            awaitingResponse = false;
        }
    }

    private double pushDur, relDur, posVel, negVel;

    /** Detects inputs that never reach the game, a stuck touch, and an inverted hold direction. */
    private void checkResponse(double dt, long tNs) {
        boolean pDel = cmdAt(tNs - (long) (lat * 1e9));
        double dec = Math.exp(-dt / 0.8);
        pushDur = pushDur * dec + (pDel ? dt : 0);
        relDur = relDur * dec + (pDel ? 0 : dt);
        posVel = Math.max(posVel * dec, v);
        negVel = Math.min(negVel * dec, v);
        boolean noResp = (pushDur > (pulseMode ? 0.22 : 0.4) && posVel < 0.3 && c < hi - 0.3)
                || (relDur > (pulseMode ? 0.5 : 0.4) && negVel > -0.3 && c > lo + 0.3);
        if (noResp) {
            health = Math.max(0, health - (int) Math.ceil(dt * 80));
            if (health < 50 && (tNs - lastResetT) / 1e9 > 1.5) {
                needReset = true;
                lastResetT = tNs;
                health = 70;
                pushDur = relDur = 0;
                posVel = negVel = 0;
            }
        } else if (health < 100) {
            health = Math.min(100, health + 1);
        }
        // holding but the bar keeps going the wrong way: hold direction is inverted
        double steady = (tNs - lastFlipT) / 1e9;
        if (push && steady > 0.35 && v < -0.8 && c > lo + 0.3) invVotes++;
        else if (push && v > 0.8) invVotes = Math.max(0, invVotes - 2);
        if (invVotes >= 14) {
            invert = !invert;
            invVotes = 0;
            A = 10; G = 10; D = 3;
            smN = 0;
            hCount = 0;
            record(tNs, push);
        }
    }

    static final double HY = 1.0;
    /** Planning horizon (s), how far ahead the fish is extrapolated (gain), and extra cost for being outside the bar. */
    public double HZ = 0.30, fishGain = 0.8, outPen = 4, outAt = 0.4;
    /** Longest single press and shortest gap between presses, in seconds (set from Config). */
    /** Follow mode: shortest time the screen stays held or released before it may switch (seconds). */
    public double minFlip = 0.12;
    public double MAX_PULSE = 0.60, MIN_GAP = 0.15, MIN_PULSE = 0.18;
    /** true: each push is one committed touch (see update); false: the screen is held and released continuously. */
    public boolean pulseMode;
    private long pulseEndNs;
    private int pendingPulseMs;

    /** Length in ms of a new press to send now (0 if none). Only used in pulse mode. */
    public int takePulse() {
        int p = pendingPulseMs;
        pendingPulseMs = 0;
        return p;
    }
    private static final double[] TAUS = {0, 0.04, 0.08, 0.12, 0.18, 0.26, 0.4, 0.6, 9};

    /** Cost of: command x from now (after the input delay) until tau, then the opposite. Lower is better. */
    private double plan(boolean x, double tau, long tNs, double H, double fish, double fishV, double velW) {
        double cc = c, vv = v, dt = 0.01, cost = 0;
        int steps = (int) Math.ceil(H / dt);
        for (int i = 0; i < steps; i++) {
            double tm = i * dt;
            boolean p;
            if (tm < lat) p = cmdAt(tNs + (long) ((tm - lat) * 1e9));
            else p = (tm - lat < tau) ? x : !x;
            double acc = p ? A : -G;
            vv += (acc - D * vv) * dt;
            cc += vv * dt;
            if (cc < lo) { cc = lo; if (vv < 0) vv = 0; }
            if (cc > hi) { cc = hi; if (vv > 0) vv = 0; }
            double ft = fish + fishV * Math.min(tm, 0.4) * fishGain;
            ft = Math.max(lo - 0.3, Math.min(hi + 0.3, ft));
            double d = Math.abs(cc - ft);
            cost += (d + outPen * Math.max(0, d - outAt)) * dt;
        }
        // end state: should not be racing away from the fish
        double ftEnd = Math.max(lo - 0.3, Math.min(hi + 0.3, fish + fishV * Math.min(H, 0.4) * fishGain));
        cost += velW * 0.3 * Math.abs(vv - fishV) + 0.15 * Math.max(0, (cc - ftEnd) * Math.signum(vv) ) * Math.min(1, Math.abs(vv)) * 0;
        return cost;
    }

    public double cEst() { return c; }
    public double loEst() { return lo; }
    public double hiEst() { return hi; }
    public double fEst() { return f; }
    public double barVel() { return v; }
    public double fishVel() { return vf; }
}
