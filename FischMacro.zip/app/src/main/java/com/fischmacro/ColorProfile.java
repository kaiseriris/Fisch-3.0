package com.fischmacro;

/**
 * What the control bar and the fish look like on this phone and rod, taught by tapping them once (Calibrate colors).
 * Sizes are stored as fractions of the screen, so they hold if the capture size changes.
 */
public final class ColorProfile {
    public boolean hasBar, hasFish;
    /** Set when the bar was placed by hand (Boxes): colour search then only looks near that height. */
    public boolean boxed;
    /** Mean colors, 0..255. */
    public double barR, barG, barB, fishR, fishG, fishB;
    /** Bar size and height of its middle, as fractions of frame width / height. */
    public double barWFrac, barHFrac, barYFrac;
    /** Where the bar was horizontally (centre, fraction of width); the minigame sits in the same place each time. 0 = unknown. */
    public double barXFrac;
    /** Whole-minigame track (where the bar can travel): left and right ends as fractions of width. */
    public boolean hasTrack;
    public double trackLFrac, trackRFrac;
    /** Progress meter box (fractions) and the colour of its filled part. */
    public boolean hasProg;
    public double progLFrac, progTFrac, progRFrac, progBFrac, progFillR, progFillG, progFillB;
    /** Message for the user from the last calibration (not saved). */
    public String warning = "";
    /** Fish width as a fraction of frame width. */
    public double fishWFrac;

    public boolean ready() {
        return hasBar;
    }

    public static double dist(int rgb, double r, double g, double b) {
        double dr = ((rgb >> 16) & 255) - r, dg = ((rgb >> 8) & 255) - g, db = (rgb & 255) - b;
        return Math.sqrt(dr * dr + dg * dg + db * db);
    }

    public ColorProfile copy() {
        ColorProfile c = new ColorProfile();
        c.hasBar = hasBar; c.hasFish = hasFish; c.boxed = boxed;
        c.barR = barR; c.barG = barG; c.barB = barB;
        c.fishR = fishR; c.fishG = fishG; c.fishB = fishB;
        c.barWFrac = barWFrac; c.barHFrac = barHFrac; c.barYFrac = barYFrac; c.barXFrac = barXFrac;
        c.hasTrack = hasTrack; c.trackLFrac = trackLFrac; c.trackRFrac = trackRFrac;
        c.hasProg = hasProg; c.progLFrac = progLFrac; c.progTFrac = progTFrac; c.progRFrac = progRFrac; c.progBFrac = progBFrac;
        c.progFillR = progFillR; c.progFillG = progFillG; c.progFillB = progFillB; c.fishWFrac = fishWFrac;
        return c;
    }

    public double[] toArray() {
        return new double[] {hasBar ? 1 : 0, hasFish ? 1 : 0, barR, barG, barB, fishR, fishG, fishB,
                barWFrac, barHFrac, barYFrac, fishWFrac, boxed ? 1 : 0, barXFrac,
                hasTrack ? 1 : 0, trackLFrac, trackRFrac, hasProg ? 1 : 0, progLFrac, progTFrac, progRFrac, progBFrac, progFillR, progFillG, progFillB};
    }

    public static ColorProfile fromArray(double[] a) {
        ColorProfile c = new ColorProfile();
        if (a == null || a.length < 12) return c;
        c.hasBar = a[0] > 0.5; c.hasFish = a[1] > 0.5;
        c.barR = a[2]; c.barG = a[3]; c.barB = a[4];
        c.fishR = a[5]; c.fishG = a[6]; c.fishB = a[7];
        c.barWFrac = a[8]; c.barHFrac = a[9]; c.barYFrac = a[10]; c.fishWFrac = a[11];
        c.boxed = a.length > 12 && a[12] > 0.5;
        c.barXFrac = a.length > 13 ? a[13] : 0;
        if (a.length >= 25) {
            c.hasTrack = a[14] > 0.5; c.trackLFrac = a[15]; c.trackRFrac = a[16];
            c.hasProg = a[17] > 0.5; c.progLFrac = a[18]; c.progTFrac = a[19]; c.progRFrac = a[20]; c.progBFrac = a[21];
            c.progFillR = a[22]; c.progFillG = a[23]; c.progFillB = a[24];
        }
        return c;
    }
}
