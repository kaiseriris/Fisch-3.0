package com.fischmacro;

/**
 * What the control bar and the fish look like on this phone and rod, taught by tapping them once (Calibrate colors).
 * Sizes are stored as fractions of the screen, so they hold if the capture size changes.
 */
public final class ColorProfile {
    public boolean hasBar, hasFish;
    /** Mean colors, 0..255. */
    public double barR, barG, barB, fishR, fishG, fishB;
    /** Bar size and height of its middle, as fractions of frame width / height. */
    public double barWFrac, barHFrac, barYFrac;
    /** Fish width as a fraction of frame width. */
    public double fishWFrac;

    public boolean ready() {
        return hasBar;
    }

    public static double dist(int rgb, double r, double g, double b) {
        double dr = ((rgb >> 16) & 255) - r, dg = ((rgb >> 8) & 255) - g, db = (rgb & 255) - b;
        return Math.sqrt(dr * dr + dg * dg + db * db);
    }

    public ColorProfile copy() {
        ColorProfile c = new ColorProfile();
        c.hasBar = hasBar; c.hasFish = hasFish;
        c.barR = barR; c.barG = barG; c.barB = barB;
        c.fishR = fishR; c.fishG = fishG; c.fishB = fishB;
        c.barWFrac = barWFrac; c.barHFrac = barHFrac; c.barYFrac = barYFrac; c.fishWFrac = fishWFrac;
        return c;
    }

    public double[] toArray() {
        return new double[] {hasBar ? 1 : 0, hasFish ? 1 : 0, barR, barG, barB, fishR, fishG, fishB,
                barWFrac, barHFrac, barYFrac, fishWFrac};
    }

    public static ColorProfile fromArray(double[] a) {
        ColorProfile c = new ColorProfile();
        if (a == null || a.length < 12) return c;
        c.hasBar = a[0] > 0.5; c.hasFish = a[1] > 0.5;
        c.barR = a[2]; c.barG = a[3]; c.barB = a[4];
        c.fishR = a[5]; c.fishG = a[6]; c.fishB = a[7];
        c.barWFrac = a[8]; c.barHFrac = a[9]; c.barYFrac = a[10]; c.fishWFrac = a[11];
        return c;
    }
}
