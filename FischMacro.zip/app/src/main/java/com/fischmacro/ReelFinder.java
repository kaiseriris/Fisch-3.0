package com.fischmacro;

/**
 * Finds the Zanshin Zen reel interface anywhere on screen, at any size.
 *
 * How: the control bar is a near-black rounded pill with a white outline. We label every long run of
 * near-black pixels in the lower part of the frame, join touching runs into shapes, keep the ones with
 * pill proportions, then check each candidate against the rest of the art (outline, kanji, chrome
 * blade, progress meter). The best-scoring candidate becomes the reel interface.
 */
public final class ReelFinder {

    private static final int DARK = 50;

    private final DarkShapes shapes = new DarkShapes();

    /** Diagnostic: how many candidate shapes were examined on the last search. */
    public int lastCandidates;
    /** Diagnostic: score of the best candidate on the last search, even if it was rejected (0 if none). */
    public double lastBest;

    public ReelUi search(Frame f, double tolerance) {
        lastCandidates = 0;
        final int yStart = (int) (f.h * 0.25);
        final int minRun = Math.max(6, (int) (f.w * 0.02));
        shapes.find(f, yStart, f.h, DARK, minRun);

        double tol = Math.max(0.6, Math.min(1.5, tolerance));
        double threshold = Math.max(0.40, Math.min(0.80, 0.62 / tol));
        ReelUi best = null;

        // Join fragments that sit side by side at the same height: a fish marker or other art drawn over
        // the bar can cut it into pieces.
        int m = 0;
        int[] mnX = new int[shapes.count], mxX = new int[shapes.count], mnY = new int[shapes.count],
                mxY = new int[shapes.count], ar = new int[shapes.count];
        boolean[] alive = new boolean[shapes.count];
        for (int i = 0; i < shapes.count; i++) {
            if (shapes.maxY[i] - shapes.minY[i] + 1 < 5 || shapes.maxX[i] - shapes.minX[i] + 1 < f.w * 0.01) continue;
            mnX[m] = shapes.minX[i]; mxX[m] = shapes.maxX[i]; mnY[m] = shapes.minY[i]; mxY[m] = shapes.maxY[i];
            ar[m] = shapes.area[i]; alive[m] = true;
            m++;
        }
        boolean joined = true;
        while (joined) {
            joined = false;
            for (int i = 0; i < m; i++) {
                if (!alive[i]) continue;
                for (int j = i + 1; j < m; j++) {
                    if (!alive[j]) continue;
                    if (Math.abs(mnY[i] - mnY[j]) > 3 || Math.abs(mxY[i] - mxY[j]) > 3) continue;
                    int gap = Math.max(mnX[i], mnX[j]) - Math.min(mxX[i], mxX[j]) - 1;
                    int span = Math.max(mxX[i], mxX[j]) - Math.min(mnX[i], mnX[j]) + 1;
                    if (gap > 0.12 * span || gap > f.w * 0.08) continue;
                    int h = Math.max(mxY[i], mxY[j]) - Math.min(mnY[i], mnY[j]) + 1;
                    ar[i] += ar[j] + Math.max(0, gap) * h;
                    mnX[i] = Math.min(mnX[i], mnX[j]); mxX[i] = Math.max(mxX[i], mxX[j]);
                    mnY[i] = Math.min(mnY[i], mnY[j]); mxY[i] = Math.max(mxY[i], mxY[j]);
                    alive[j] = false;
                    joined = true;
                }
            }
        }
        for (int r = 0; r < m; r++) {
            if (!alive[r]) continue;
            int w = mxX[r] - mnX[r] + 1;
            int h = mxY[r] - mnY[r] + 1;
            if (h < 5 || w < f.w * 0.06 || w > f.w * 0.85) continue;
            double aspect = (double) w / h;
            if (aspect < 4.0 || aspect > 20.0) continue;
            double fill = Math.min(1.0, (double) ar[r] / (w * h));
            if (fill < 0.55) continue;
            lastCandidates++;
            ReelUi ui = verify(f, mnX[r], mxX[r], mnY[r], mxY[r], fill);
            if (ui != null && (best == null || ui.conf > best.conf)) best = ui;
        }
        lastBest = best == null ? 0 : best.conf;
        if (best == null || best.conf < threshold || best.sOutline < 0.3 || best.sFill < 0.4) return null;
        return best;
    }

    // ---- verification of one candidate -------------------------------------------------------

    static final double ASPECT = 413.0 / 50.0;

    private ReelUi verify(Frame f, int L, int R, int T, int B, double fill) {
        int[] ext = refine(f, L, R, T, B);
        L = ext[0];
        R = ext[1];
        ReelUi ui = new ReelUi();
        ui.pillL = L; ui.pillR = R; ui.pillT = T; ui.pillB = B;
        int pw = R - L + 1, ph = B - T + 1;

        ui.sFill = clamp01((fill - 0.55) / 0.30);

        // white outline hugging the top and bottom edges
        // (looked for in a band that grows with the bar, with a threshold low enough to survive a downscaled capture)
        int band = Math.max(3, ph / 8);
        double top = brightFrac(f, L + ph / 2, R - ph / 2, T - band, T - 1, 140);
        double bot = brightFrac(f, L + ph / 2, R - ph / 2, B + 1, B + band, 140);
        ui.sOutline = clamp01((Math.min(top, bot) - 0.25) / 0.45);

        // a few bright strokes inside (the kanji) but not a lot
        double inner = brightFrac(f, L + 3, R - 3, T + 3, B - 3, 170);
        ui.sKanji = (inner >= 0.004 && inner <= 0.25) ? 1.0 : 0.3;

        // metal blade on at least one side of the pill
        ui.sBlade = Math.max(chrome(f, L - 3 * ph, L - ph / 3, T, B), chrome(f, R + ph / 3, R + 3 * ph, T, B));

        findProgress(f, ui, pw, ph);
        // Merged with the fish marker or a bit of frame? The bar's shape is fixed (about 8.26 : 1 on this skin), so
        // when it comes out too long, cut off the end that lacks the white outline along the top and bottom edges.
        double expW = ASPECT * ph;
        if (pw > 1.04 * expW && pw < 1.5 * expW) {
            int extra = pw - (int) Math.round(expW);
            double oL = Math.min(brightFrac(f, L, L + extra, T - 3, T - 1, 170), brightFrac(f, L, L + extra, B + 1, B + 3, 170));
            double oR = Math.min(brightFrac(f, R - extra, R, T - 3, T - 1, 170), brightFrac(f, R - extra, R, B + 1, B + 3, 170));
            if (oL >= oR) ui.pillR = R = R - extra; else ui.pillL = L = L + extra;
            pw = R - L + 1;
            findProgress(f, ui, pw, ph);
        }
        ui.sProgress = ui.hasProgress ? 1.0 : 0.0;

        ui.conf = 0.30 * ui.sFill + 0.25 * ui.sOutline + 0.10 * ui.sKanji + 0.15 * ui.sBlade + 0.20 * ui.sProgress;
        return ui;
    }

    /**
     * Walks outward from the found shape along three rows and bridges the small gaps a fish marker can leave,
     * so thin pieces at the ends of the bar are not lost.
     */
    private int[] refine(Frame f, int L, int R, int T, int B) {
        int ph = B - T + 1, w = R - L + 1, yc = (T + B) / 2;
        int gapMax = Math.max(8, (int) (0.08 * w)), maxExt = (int) (0.2 * w);
        int[] ys = {yc - ph / 4, yc, yc + ph / 4};
        int[] ls = new int[3], rs = new int[3];
        for (int i = 0; i < 3; i++) {
            int y = Math.max(0, Math.min(f.h - 1, ys[i]));
            int last = L;
            for (int x = L; x > Math.max(0, L - maxExt) && last - x <= gapMax; x--) if (f.luma(x, y) < DARK) last = x;
            ls[i] = last;
            last = R;
            for (int x = R; x < Math.min(f.w - 1, R + maxExt) && x - last <= gapMax; x++) if (f.luma(x, y) < DARK) last = x;
            rs[i] = last;
        }
        java.util.Arrays.sort(ls);
        java.util.Arrays.sort(rs);
        return new int[] {Math.min(L, ls[1]), Math.max(R, rs[1])};
    }

    private double brightFrac(Frame f, int xa, int xb, int ya, int yb, int thr) {
        int hit = 0, tot = 0;
        for (int y = ya; y <= yb; y++) {
            for (int x = xa; x <= xb; x++) {
                int l = f.lumaSafe(x, y);
                if (l < 0) continue;
                tot++;
                if (l > thr) hit++;
            }
        }
        return tot == 0 ? 0 : (double) hit / tot;
    }

    /** Looks like polished metal: fairly bright, varied, nearly colorless. Returns 1 or 0. */
    private double chrome(Frame f, int xa, int xb, int T, int B) {
        int ya = T + (B - T) / 4, yb = B - (B - T) / 4;
        double sum = 0, sum2 = 0, sat = 0;
        int cnt = 0;
        for (int y = ya; y <= yb; y++) {
            for (int x = xa; x <= xb; x++) {
                if (!f.inside(x, y)) continue;
                int p = f.rgb(x, y);
                int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
                double l = (77 * r + 150 * g + 29 * b) / 256.0;
                sum += l;
                sum2 += l * l;
                sat += Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b));
                cnt++;
            }
        }
        if (cnt < 8) return 0;
        double mean = sum / cnt;
        double std = Math.sqrt(Math.max(0, sum2 / cnt - mean * mean));
        double s = sat / cnt;
        return (mean >= 90 && mean <= 250 && std >= 15 && s <= 48) ? 1.0 : 0.0;
    }

    /** The progress meter: a long thin dark bar a little below the pill. Fills ui.prog* when found. */
    static void findProgress(Frame f, ReelUi ui, int pw, int ph) {
        ui.hasProgress = false;
        int xa = Math.max(0, (int) ui.pillL - 2 * pw), xb = Math.min(f.w - 1, (int) ui.pillR + 2 * pw);
        int ya = (int) ui.pillB + Math.max(2, ph / 4);
        int yb = Math.min(f.h - 1, (int) ui.pillB + (int) (2.4 * ph));
        int minLen = (int) (0.8 * pw), maxLen = (int) (1.4 * pw);
        int gapMax = Math.max(3, (int) (0.3 * ph));

        int gTop = -1, gBottom = -1, gA = 0, gB = 0, lastY = -100, lenBest = 0, aBest = 0, bBest = 0;
        for (int y = ya; y <= yb; y++) {
            int bestA = -1, bestB = -1, bestLen = 0;
            int x = xa;
            while (x <= xb) {
                while (x <= xb && f.luma(x, y) >= 75) x++;
                int s = x;
                while (x <= xb && f.luma(x, y) < 75) x++;
                if (x - s > bestLen) { bestLen = x - s; bestA = s; bestB = x - 1; }
            }
            boolean valid = bestLen >= minLen && bestLen <= maxLen;
            if (valid && gTop >= 0 && y - lastY <= gapMax
                    && bestA <= gA + 0.06 * pw && bestB >= gB - 0.06 * pw) {
                // Rows through the lit-up fill are shorter than the rows along the meter's frame, so a row that starts
                // further left (or ends further right) is the real meter edge: widen the group to it.
                gA = Math.min(gA, bestA);
                gB = Math.max(gB, bestB);
                if (bestLen > lenBest) { lenBest = bestLen; aBest = bestA; bBest = bestB; }
                gBottom = y;
                lastY = y;
            } else if (valid && gTop < 0) {
                gTop = y; gBottom = y; gA = bestA; gB = bestB; lastY = y; lenBest = bestLen; aBest = bestA; bBest = bestB;
            } else if (gTop >= 0 && y - lastY > gapMax) {
                if (acceptGroup(ui, gTop, gBottom, aBest, bBest, ph)) return;
                gTop = -1;
                if (valid) { gTop = y; gBottom = y; gA = bestA; gB = bestB; lastY = y; }
            }
        }
        if (gTop >= 0) acceptGroup(ui, gTop, gBottom, aBest, bBest, ph);
    }

    private static boolean acceptGroup(ReelUi ui, int top, int bottom, int a, int b, int ph) {
        int height = bottom - top + 1;
        if (height < Math.max(3, (int) (0.2 * ph)) || height > 1.4 * ph) return false;
        ui.hasProgress = true;
        // the dark frame is a little wider than the part the fill travels along: use the inside
        int inset = (int) Math.round(0.0115 * (b - a + 1));
        a += inset;
        b -= inset;
        ui.progL = a; ui.progR = b; ui.progT = top; ui.progB = bottom;
        return true;
    }

    private static double clamp01(double v) {
        return v < 0 ? 0 : (v > 1 ? 1 : v);
    }
}
