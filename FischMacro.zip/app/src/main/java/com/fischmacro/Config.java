package com.fischmacro;

/** Every setting the automation reads. Plain fields so the dashboard can change them live. */
public final class Config {
    // automation toggles
    public volatile boolean autoCast = true;
    public volatile boolean autoShake = true;
    public volatile boolean autoReel = true;
    public volatile boolean soulJudgement = true;

    /** 0.5 (relaxed) .. 2.0 (aggressive). Scales how hard the reel controller corrects. */
    public volatile double sensitivity = 1.0;
    /** 0.5 (strict) .. 1.5 (lenient). Scales how easily the vision accepts weak matches. */
    public volatile double detectionTolerance = 1.0;

    /** Where to press and hold while reeling and casting, as a fraction of the screen. */
    public volatile float holdFx = 0.62f, holdFy = 0.40f;

    /** How long to hold the screen to charge a cast. */
    public volatile int castHoldMs = 1000;
    /** Give up waiting for a bite/shake after this long and cast again. */
    public volatile int biteTimeoutMs = 30000;
    /** Wait this long after a catch screen before casting again. */
    public volatile int cooldownMs = 1800;

    /** Pause between a stage change and the next input, so the game has time to react. */
    public volatile int stageSettleMs = 250;

    /** Save a diagnostic picture when something goes wrong. */
    public volatile boolean saveSnapshots = true;

    public Config copyOf() {
        Config c = new Config();
        c.autoCast = autoCast;
        c.autoShake = autoShake;
        c.autoReel = autoReel;
        c.soulJudgement = soulJudgement;
        c.sensitivity = sensitivity;
        c.detectionTolerance = detectionTolerance;
        c.holdFx = holdFx;
        c.holdFy = holdFy;
        c.castHoldMs = castHoldMs;
        c.biteTimeoutMs = biteTimeoutMs;
        c.cooldownMs = cooldownMs;
        c.stageSettleMs = stageSettleMs;
        c.saveSnapshots = saveSnapshots;
        return c;
    }
}
