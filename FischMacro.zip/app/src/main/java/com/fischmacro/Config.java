package com.fischmacro;

/** Every setting the automation reads. Plain fields so the dashboard can change them live. */
public final class Config {
    // automation toggles
    public volatile boolean autoCast = true;
    public volatile boolean autoShake = true;
    public volatile boolean autoReel = true;
    public volatile boolean soulJudgement = true;
    /** Reel with single-touch pulses of a chosen length (recommended) instead of one continuously held touch. */
    public volatile boolean pulseMode = false;

    /** 0.5 (relaxed) .. 2.0 (aggressive). Scales how hard the reel controller corrects. */
    public volatile double sensitivity = 1.0;
    /** 0.5 (strict) .. 1.5 (lenient). Scales how easily the vision accepts weak matches. */
    public volatile double detectionTolerance = 1.0;

    /** Where to press and hold while reeling and casting, as a fraction of the screen. */
    public volatile float holdFx = 0.62f, holdFy = 0.40f;

    /** How long to hold the screen to charge a cast. */
    public volatile int castHoldMs = 1000;
    /** Give up waiting for a bite/shake after this long and cast again. */
    public volatile int biteTimeoutMs = 30000;
    /** Wait this long after a catch screen before casting again. */
    public volatile int cooldownMs = 1800;

    /** Pause between a stage change and the next input, so the game has time to react. */
    public volatile int stageSettleMs = 250;

    /** Reel detection: 0 = Auto (shape recognition, colour as fallback), 1 = shapes only, 2 = colours only (needs Calibrate colors). */
    public volatile int detectMode = 0;
    /** 0.4 (strict) .. 2.5 (loose). How far a pixel may differ from the taught colour. */
    public volatile double colorTolerance = 1.0;
    /** Let the colour model slowly follow the bar/fish colours it sees. */
    public volatile boolean adaptiveColors = true;
    /** Longest single reel press and shortest gap between presses, in ms. */
    /** Follow mode: shortest hold or release before switching. */
    public volatile int holdMinMs = 120;
    public volatile int pulseMaxMs = 600, pulseGapMs = 150, pulseMinMs = 180;
    /** Shake finder: 0.5 (picky) .. 2.0 (eager), and the shortest time between shake taps. */
    public volatile double shakeSens = 1.0;
    public volatile int shakeGapMs = 200;
    /** Random extra cast hold (0..this many ms) so casts are not all identical. */
    public volatile int castJitterMs = 0;
    /** Give up on a reel that lasts longer than this. */
    public volatile int maxReelSec = 90;

    /** Save a diagnostic picture when something goes wrong. */
    public volatile boolean saveSnapshots = true;

    public Config copyOf() {
        Config c = new Config();
        c.autoCast = autoCast;
        c.autoShake = autoShake;
        c.autoReel = autoReel;
        c.soulJudgement = soulJudgement;
        c.pulseMode = pulseMode;
        c.sensitivity = sensitivity;
        c.detectionTolerance = detectionTolerance;
        c.holdFx = holdFx;
        c.holdFy = holdFy;
        c.castHoldMs = castHoldMs;
        c.biteTimeoutMs = biteTimeoutMs;
        c.cooldownMs = cooldownMs;
        c.stageSettleMs = stageSettleMs;
        c.detectMode = detectMode;
        c.colorTolerance = colorTolerance;
        c.adaptiveColors = adaptiveColors;
        c.pulseMaxMs = pulseMaxMs;
        c.pulseGapMs = pulseGapMs;
        c.holdMinMs = holdMinMs;
        c.pulseMinMs = pulseMinMs;
        c.shakeSens = shakeSens;
        c.shakeGapMs = shakeGapMs;
        c.castJitterMs = castJitterMs;
        c.maxReelSec = maxReelSec;
        c.saveSnapshots = saveSnapshots;
        return c;
    }
}
