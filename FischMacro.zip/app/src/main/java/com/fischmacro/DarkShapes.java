package com.fischmacro;

import java.util.Arrays;

/**
 * Labels connected shapes of near-black pixels. Works row by row on long runs of dark pixels and joins
 * runs that touch from one row to the next (union-find), so it is fast enough to run on a whole frame.
 */
final class DarkShapes {
    int count;
    int[] minX = new int[64], maxX = new int[64], minY = new int[64], maxY = new int[64], area = new int[64];

    private int[] rowOf = new int[2048], x0 = new int[2048], x1 = new int[2048], parent = new int[2048];
    private int n;
    private int[] rowLuma = new int[0];

    void find(Frame f, int yStart, int yEnd, int darkThr, int minRun) {
        n = 0;
        count = 0;
        if (rowLuma.length < f.w) rowLuma = new int[f.w];
        yEnd = Math.min(yEnd, f.h);
        int prevA = 0, prevB = 0;
        for (int y = Math.max(0, yStart); y < yEnd; y++) {
            for (int x = 0; x < f.w; x++) rowLuma[x] = f.luma(x, y);
            int curA = n;
            int x = 0;
            while (x < f.w) {
                while (x < f.w && rowLuma[x] >= darkThr) x++;
                int s = x;
                while (x < f.w && rowLuma[x] < darkThr) x++;
                if (x - s >= minRun) addRun(y, s, x - 1);
            }
            int curB = n;
            int i = prevA, j = curA;
            while (i < prevB && j < curB) {
                if (x0[i] <= x1[j] + 1 && x0[j] <= x1[i] + 1) union(i, j);
                if (x1[i] < x1[j]) i++; else j++;
            }
            prevA = curA;
            prevB = curB;
        }
        // collect one entry per root
        int[] slot = new int[n];
        Arrays.fill(slot, -1);
        for (int i = 0; i < n; i++) {
            int r = find(i);
            if (slot[r] < 0) {
                if (count == minX.length) grow();
                slot[r] = count++;
                minX[slot[r]] = Integer.MAX_VALUE;
                maxX[slot[r]] = Integer.MIN_VALUE;
                minY[slot[r]] = Integer.MAX_VALUE;
                maxY[slot[r]] = Integer.MIN_VALUE;
                area[slot[r]] = 0;
            }
            int s = slot[r];
            area[s] += x1[i] - x0[i] + 1;
            if (x0[i] < minX[s]) minX[s] = x0[i];
            if (x1[i] > maxX[s]) maxX[s] = x1[i];
            if (rowOf[i] < minY[s]) minY[s] = rowOf[i];
            if (rowOf[i] > maxY[s]) maxY[s] = rowOf[i];
        }
    }

    private void grow() {
        int c = minX.length * 2;
        minX = Arrays.copyOf(minX, c);
        maxX = Arrays.copyOf(maxX, c);
        minY = Arrays.copyOf(minY, c);
        maxY = Arrays.copyOf(maxY, c);
        area = Arrays.copyOf(area, c);
    }

    private void addRun(int y, int a, int b) {
        if (n == rowOf.length) {
            int c = n * 2;
            rowOf = Arrays.copyOf(rowOf, c);
            x0 = Arrays.copyOf(x0, c);
            x1 = Arrays.copyOf(x1, c);
            parent = Arrays.copyOf(parent, c);
        }
        rowOf[n] = y;
        x0[n] = a;
        x1[n] = b;
        parent[n] = n;
        n++;
    }

    private int find(int i) {
        while (parent[i] != i) {
            parent[i] = parent[parent[i]];
            i = parent[i];
        }
        return i;
    }

    private void union(int a, int b) {
        int ra = find(a), rb = find(b);
        if (ra != rb) parent[rb] = ra;
    }
}
