package com.fischmacro;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

/**
 * Full-screen, touch-through layer that draws what the vision currently sees: a green box on the control bar, a red line
 * on the fish, and a one-line readout. Used to check that detection is right before trusting the macro.
 */
final class VisView extends View {
    private final Paint box = new Paint(Paint.ANTI_ALIAS_FLAG), fish = new Paint(Paint.ANTI_ALIAS_FLAG),
            predicted = new Paint(Paint.ANTI_ALIAS_FLAG), edges = new Paint(Paint.ANTI_ALIAS_FLAG),
            txt = new Paint(Paint.ANTI_ALIAS_FLAG), bg = new Paint();

    VisView(Context c) {
        super(c);
        box.setStyle(Paint.Style.STROKE);
        box.setStrokeWidth(5);
        box.setColor(Color.rgb(60, 255, 90));
        fish.setStyle(Paint.Style.STROKE);
        fish.setStrokeWidth(6);
        fish.setColor(Color.rgb(255, 60, 60));
        predicted.setStyle(Paint.Style.STROKE);
        predicted.setStrokeWidth(5);
        predicted.setColor(Color.rgb(255, 170, 40));
        edges.setStyle(Paint.Style.STROKE);
        edges.setStrokeWidth(4);
        edges.setColor(Color.rgb(40, 220, 255));
        txt.setColor(Color.WHITE);
        txt.setTextSize(34);
        bg.setColor(Color.argb(170, 0, 0, 0));
    }

    @Override
    protected void onDraw(Canvas cv) {
        double[] v = Shared.diag.vis;
        String note = Shared.diag.visNote;
        String line;
        if (v == null) {
            line = note == null || note.isEmpty() ? "Check: looking for the reel minigame..." : note;
        } else {
            double sx = getWidth() / v[5], sy = getHeight() / v[6];
            float l = (float) (v[0] * sx), t = (float) (v[1] * sy), r = (float) ((v[2] + 1) * sx), b = (float) ((v[3] + 1) * sy);
            cv.drawRect(l, t, r, b, box);
            if (v.length >= 16) {
                float top = t - (b - t) * 1.1f, bottom = b + (b - t) * 0.5f;
                cv.drawLine((float) (v[14] * sx), top, (float) (v[14] * sx), bottom, edges);
                cv.drawLine((float) (v[15] * sx), top, (float) (v[15] * sx), bottom, edges);
            }
            if (v[4] >= 0) {
                float fx = (float) (v[4] * sx);
                cv.drawLine(fx, t - (b - t), fx, b + (b - t) * 0.3f, fish);
            }
            if (v.length >= 23 && v[16] >= 0) {
                float fx = (float) (v[16] * sx);
                cv.drawLine(fx, t - (b - t) * 1.3f, fx, b + (b - t) * 0.5f, predicted);
            }
            line = "Check: " + (note == null ? "" : note);
            if (v.length >= 23) line += String.format(" | %s | bar v %.2f fish v %.2f | %.0fms", v[20] > 0.5 ? "HOLD" : "RELEASE", v[18], v[19], v[21]);
        }
        cv.drawRect(0, 0, getWidth(), 56, bg);
        cv.drawText(line, 12, 40, txt);
    }
}
