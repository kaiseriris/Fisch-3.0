package com.fischmacro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.util.DisplayMetrics;
import android.view.Display;

import java.nio.ByteBuffer;

/**
 * Screen capture + the macro's brain. Runs as a mediaProjection foreground service (required on Android 14).
 * One worker thread owns the Macro: frames, the clock tick and all button presses are handled there.
 */
public class CaptureService extends Service {
    static final String EXTRA_CODE = "code";
    static final String EXTRA_DATA = "data";
    static final String ACTION_STOP = "com.fischmacro.STOP";
    private static final String CHANNEL = "fisch_capture";
    private static final int NOTE_ID = 7;

    private MediaProjection projection;
    private VirtualDisplay vd;
    private ImageReader reader;
    private HandlerThread thread;
    private Handler h;
    private Macro macro;
    private int capW, capH, dpi;
    private long lastProcMs, lastSizeCheckMs;
    private boolean stopping;

    // touch request from the "Teach Shake" overlay (fractions), consumed on the worker thread
    private volatile float[] teachAt;
    /** {fx, fy, step} where step 0 = control bar, 1 = fish. */
    private volatile float[] calibAt;

    private final MediaProjection.Callback projCb = new MediaProjection.Callback() {
        @Override
        public void onStop() {
            Shared.note = "Screen capture was stopped by Android. Start it again.";
            Shared.diag.event("Projection stopped by system");
            stopSelfSafely();
        }
    };

    private final Macro.Input input = new Macro.Input() {
        @Override
        public void hold(boolean down) {
            MacroService m = Shared.macro;
            if (m == null) return;
            m.injector().setPoint(Shared.cfg.holdFx, Shared.cfg.holdFy);
            m.injector().setHold(down);
        }

        @Override
        public void tap(float fx, float fy) {
            MacroService m = Shared.macro;
            if (m != null) m.injector().tap(fx, fy);
        }

        @Override
        public void pulse(int ms) {
            MacroService m = Shared.macro;
            if (m == null) return;
            m.injector().setPoint(Shared.cfg.holdFx, Shared.cfg.holdFy);
            m.injector().pulse(ms);
        }

        @Override
        public void pressFor(int ms) {
            MacroService m = Shared.macro;
            if (m == null) return;
            m.injector().setPoint(Shared.cfg.holdFx, Shared.cfg.holdFy);
            m.injector().pressFor(ms);
        }

        @Override
        public int pressState() {
            MacroService m = Shared.macro;
            return m == null ? -1 : m.injector().pressState();
        }

        @Override
        public long pressMeasuredMs() {
            MacroService m = Shared.macro;
            return m == null ? 0 : m.injector().pressMeasuredMs();
        }

        @Override
        public boolean pressAccepted() {
            MacroService m = Shared.macro;
            return m != null && m.injector().holdAcked();
        }

        @Override
        public void resetInput() {
            MacroService m = Shared.macro;
            if (m != null) m.injector().reset();
        }
    };

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelfSafely();
            return START_NOT_STICKY;
        }
        if (projection != null) return START_NOT_STICKY; // already running
        if (intent == null || intent.getParcelableExtra(EXTRA_DATA) == null) {
            stopSelf();
            return START_NOT_STICKY;
        }
        // Android 14: the foreground service of type mediaProjection must be running BEFORE getMediaProjection().
        try {
            startAsForeground();
        } catch (RuntimeException e) {
            fail("Could not start the capture service: " + e);
            return START_NOT_STICKY;
        }
        try {
            MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
            Intent data = intent.getParcelableExtra(EXTRA_DATA);
            projection = mpm.getMediaProjection(intent.getIntExtra(EXTRA_CODE, 0), data);
            if (projection == null) {
                fail("Android refused the screen capture permission.");
                return START_NOT_STICKY;
            }
            thread = new HandlerThread("fisch-vision", Thread.MAX_PRIORITY - 2);
            thread.start();
            h = new Handler(thread.getLooper());
            // The callback must be registered before the first VirtualDisplay (Android 14).
            projection.registerCallback(projCb, h);

            int[] sz = displaySize();
            capW = scaled(sz[0], sz);
            capH = scaled(sz[1], sz);
            dpi = sz[2];
            reader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2);
            reader.setOnImageAvailableListener(r -> onImage(), h);
            vd = projection.createVirtualDisplay("fisch-capture", capW, capH, dpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader.getSurface(), null, h);

            macro = new Macro(Shared.cfg, Shared.diag, input);
            int[] tpl = Prefs.loadShake(this);
            if (tpl != null) {
                int size = (int) Math.round(Math.sqrt(tpl.length));
                if (size * size == tpl.length) macro.shake.load(tpl, size);
            }
            macro.colorReel.profile = ColorProfile.fromArray(Prefs.loadColors(this));
            double[] mdl = Prefs.loadModel(this);
            if (mdl != null) { macro.ctl.A = mdl[0]; macro.ctl.G = mdl[1]; macro.ctl.D = mdl[2]; macro.ctl.lat = mdl[3]; }
            macro.onNote = s -> Shared.note = "Macro stopped itself: " + s;
            final Macro mm = macro;
            macro.onProbeDone = () -> Prefs.saveModel(CaptureService.this, mm.ctl.A, mm.ctl.G, mm.ctl.D, mm.ctl.lat);
            Shared.capture = this;
            Shared.note = "Screen capture running.";
            Shared.diag.event("Capture started " + capW + "x" + capH);
            h.postDelayed(tickLoop, 40);
        } catch (RuntimeException e) {
            fail("Capture failed to start: " + e);
        }
        return START_NOT_STICKY;
    }

    private void startAsForeground() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Fisch Macro capture", NotificationManager.IMPORTANCE_LOW));
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE);
        Intent stop = new Intent(this, CaptureService.class).setAction(ACTION_STOP);
        PendingIntent sp = PendingIntent.getService(this, 1, stop, PendingIntent.FLAG_IMMUTABLE);
        Notification n = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setContentTitle("Fisch Macro is reading the screen")
                .setContentText("Tap to open. Use the floating panel to start fishing.")
                .setContentIntent(pi)
                .addAction(new Notification.Action.Builder(null, "Stop", sp).build())
                .setOngoing(true)
                .build();
        startForeground(NOTE_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);
    }

    private int[] displaySize() {
        DisplayManager dm = (DisplayManager) getSystemService(Context.DISPLAY_SERVICE);
        Display d = dm.getDisplay(Display.DEFAULT_DISPLAY);
        DisplayMetrics m = new DisplayMetrics();
        d.getRealMetrics(m);
        return new int[] {m.widthPixels, m.heightPixels, m.densityDpi};
    }

    /**
     * Capture size: the long side is kept near 1560 px (about 2/3 of an S24's 2340). Half size blurs the thin white
     * outline of the bar too much; full size costs battery and frame rate for no gain.
     */
    private static int scaled(int v, int[] sz) {
        double k = Math.min(1.0, 1560.0 / Math.max(sz[0], sz[1]));
        return Math.max(2, (int) Math.round(v * k) & ~1);
    }

    private void fail(String why) {
        Shared.note = why;
        Shared.diag.event(why);
        stopSelfSafely();
    }

    private final Runnable tickLoop = new Runnable() {
        @Override
        public void run() {
            if (stopping || macro == null) return;
            long now = System.nanoTime();
            try {
                macro.tick(now);
                checkSize(now / 1_000_000L);
            } catch (RuntimeException e) {
                Shared.diag.event("tick error: " + e);
            }
            h.postDelayed(this, 40);
        }
    };

    /** If the phone rotated (Roblox is landscape), resize the capture to match. */
    private void checkSize(long nowMs) {
        if (nowMs - lastSizeCheckMs < 700) return;
        lastSizeCheckMs = nowMs;
        int[] sz = displaySize();
        int w = scaled(sz[0], sz), hh = scaled(sz[1], sz);
        if (w == capW && hh == capH) return;
        try {
            ImageReader old = reader;
            ImageReader nr = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2);
            nr.setOnImageAvailableListener(r -> onImage(), h);
            vd.resize(w, hh, sz[2]);
            vd.setSurface(nr.getSurface());
            reader = nr;
            capW = w;
            capH = hh;
            if (old != null) old.close();
            macro.recalibrate();
            Shared.diag.event("Screen size changed: capture now " + w + "x" + hh);
        } catch (RuntimeException e) {
            Shared.diag.event("Resize failed: " + e);
        }
    }

    private void onImage() {
        ImageReader r = reader;
        if (r == null || macro == null || stopping) return;
        Image img = null;
        try {
            img = r.acquireLatestImage();
            if (img == null) return;
            long nowMs = System.nanoTime() / 1_000_000L;
            long gap = macro.wantsFastFrames() ? 20 : 90;
            if (teachAt == null && calibAt == null && nowMs - lastProcMs < gap) return;
            lastProcMs = nowMs;
            Image.Plane p = img.getPlanes()[0];
            ByteBuffer buf = p.getBuffer();
            BufferFrame f = new BufferFrame(img.getWidth(), img.getHeight(), buf, p.getRowStride(), p.getPixelStride());
            long t0 = System.nanoTime();
            float[] t = teachAt;
            if (t != null) {
                teachAt = null;
                int size = Math.max(24, Math.round(f.w * 0.06f));
                boolean ok = macro.shake.teach(f, Math.round(t[0] * f.w), Math.round(t[1] * f.h), size);
                if (ok) {
                    Prefs.saveShake(this, macro.shake.data());
                    Shared.note = "Shake button learned.";
                } else {
                    Shared.note = "That spot is too plain to learn. Tap the shake button itself.";
                }
                Shared.diag.event(Shared.note);
            }
            float[] ca = calibAt;
            if (ca != null) {
                calibAt = null;
                ColorProfile cp = macro.colorReel.profile.copy();
                int tx = Math.round(ca[0] * f.w), ty = Math.round(ca[1] * f.h);
                String err = ca[2] < 0.5f
                        ? ColorReel.calibrateBar(f, tx, ty, Shared.cfg.colorTolerance, cp)
                        : ColorReel.calibrateFish(f, tx, ty, Shared.cfg.colorTolerance, cp);
                if (err == null) {
                    macro.colorReel.profile = cp;
                    Prefs.saveColors(this, cp);
                    if (ca[2] < 0.5f) {
                        Shared.note = String.format("Bar learned: colour %d,%d,%d, %.0f%% of screen wide.", Math.round(cp.barR), Math.round(cp.barG), Math.round(cp.barB), cp.barWFrac * 100);
                    } else {
                        double d = Math.sqrt(Math.pow(cp.barR - cp.fishR, 2) + Math.pow(cp.barG - cp.fishG, 2) + Math.pow(cp.barB - cp.fishB, 2));
                        Shared.note = d < 40 ? "Fish learned, but its colour is close to the bar's, so fish tracking will be less sure."
                                : "Fish learned.";
                    }
                } else {
                    Shared.note = err;
                }
                Shared.diag.event(Shared.note);
            }
            macro.onFrame(f, System.nanoTime());
            double ms = (System.nanoTime() - t0) / 1e6;
            Shared.diag.procMsAvg = Shared.diag.procMsAvg * 0.9 + ms * 0.1;
        } catch (RuntimeException e) {
            Shared.diag.event("frame error: " + e);
        } finally {
            if (img != null) img.close();
        }
    }

    // ---- called from the UI threads ----------------------------------------------------------

    void post(Runnable r) {
        Handler hh = h;
        if (hh != null && !stopping) hh.post(r);
    }

    Macro macro() {
        return macro;
    }

    void teach(float fx, float fy) {
        teachAt = new float[] {fx, fy};
    }

    /** step 0 = tap on the control bar, 1 = tap on the fish. Handled on the next captured frame. */
    void calibrate(float fx, float fy, int step) {
        calibAt = new float[] {fx, fy, step};
    }

    /** Boxes the user placed on the frozen picture ({l,t,r,b} fractions). Learned from that same picture. */
    void calibrateBoxes(double[] bar, double[] fish, double[] track, double[] meter) {
        post(() -> {
            Macro m = macro;
            ArrayFrame s = m == null ? null : m.snap;
            if (s == null) { Shared.note = "No picture to read the boxes from. Try Boxes again."; return; }
            ColorProfile cp = m.colorReel.profile.copy();
            String err = ColorReel.calibrateBoxes(s, bar, fish, track, meter, cp);
            if (err != null) { Shared.note = err; return; }
            m.colorReel.profile = cp;
            Prefs.saveColors(this, cp);
            Shared.note = String.format("Boxes saved: bar colour %d,%d,%d, %.0f%% of the screen wide%s.", Math.round(cp.barR), Math.round(cp.barG),
                    Math.round(cp.barB), cp.barWFrac * 100,
                    (cp.hasFish ? ", fish colour learned" : "") + (cp.hasTrack ? ", track set" : "") + (cp.hasProg ? ", meter learned" : "")) + (cp.warning.isEmpty() ? "" : " " + cp.warning);
            Shared.diag.event(Shared.note);
        });
    }

    void clearModel() {
        Prefs.clearModel(this);
        Shared.note = "Saved bar measurement cleared (the macro learns it again while reeling).";
    }

    void clearColors() {
        post(() -> {
            if (macro != null) macro.colorReel.profile = new ColorProfile();
        });
        Prefs.clearColors(this);
        Shared.note = "Colour calibration cleared.";
    }

    void clearShake() {
        post(() -> {
            if (macro != null) macro.shake.clear();
        });
        Prefs.clearShake(this);
        Shared.note = "Shake button forgotten.";
    }

    private void stopSelfSafely() {
        if (stopping) return;
        stopping = true;
        Shared.capture = null;
        try {
            if (macro != null) macro.stop();
        } catch (RuntimeException ignored) {}
        try {
            MacroService m = Shared.macro;
            if (m != null) m.injector().reset();
        } catch (RuntimeException ignored) {}
        try { if (reader != null) reader.setOnImageAvailableListener(null, null); } catch (RuntimeException ignored) {}
        try { if (vd != null) vd.release(); } catch (RuntimeException ignored) {}
        try { if (reader != null) reader.close(); } catch (RuntimeException ignored) {}
        try {
            if (projection != null) {
                projection.unregisterCallback(projCb);
                projection.stop();
            }
        } catch (RuntimeException ignored) {}
        projection = null;
        vd = null;
        reader = null;
        if (thread != null) thread.quitSafely();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    @Override
    public void onDestroy() {
        stopSelfSafely();
        super.onDestroy();
    }
}
