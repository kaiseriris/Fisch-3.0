package com.fischmacro;

import java.util.Arrays;

/**
 * Follows the reel interface frame by frame once the finder has locked on. It only looks at a small
 * region around the interface, so it is cheap enough to run on every frame.
 *
 * Each frame it measures:
 *   - the control pill's left and right edges (and re-measures its top and bottom, so it follows size changes)
 *   - the fish marker, a thin dark kunai that crosses the blade track
 *   - the progress meter fill
 * and reports how sure it is of each.
 */
public class ReelTracker {

    public static final class Measure {
        public boolean ok;
        public double conf;
        public double pillL, pillR, pillT, pillB;
        public double pillConf;
        public boolean fishFound;
        public double fishX, fishConf;
        public boolean progressOk;
        public double progress, progressConf;
    }

    private static final int DARK = 50;

    private ReelUi ui;
    private double widthMed, heightMed;
    private int devStreak;
    private double cVel;
    /** Frames in a row that failed to measure the pill. The caller re-runs the finder when this grows. */
    public int failStreak;
    /** True when the interface moved or resized noticeably since the last search. */
    public boolean geometryChanged;

    private int[] cols = new int[0];

    public boolean locked() { return ui != null; }

    // The progress meter does not move on screen, but its dark frame can be hidden while the fill is high. Remember a
    // fully seen meter and reuse it whenever the bar looks the same size.
    private double bgPw, bgPillT;
    private double[] memMeter;
    private double memPw;

    private void rememberOrRestore(ReelUi u) {
        double pw = u.pillW(), full = 1.242 * pw;
        double w = u.progR - u.progL + 1;
        boolean good = u.hasProgress && Math.abs(w - full) <= 0.06 * full;
        if (good) {
            memMeter = new double[] {u.progL, u.progR, u.progT, u.progB};
            memPw = pw;
        } else if (memMeter != null && Math.abs(pw - memPw) <= 0.05 * memPw) {
            u.progL = memMeter[0]; u.progR = memMeter[1]; u.progT = memMeter[2]; u.progB = memMeter[3];
            u.hasProgress = true;
        }
    }

    public void lock(ReelUi u) {
        rememberOrRestore(u);
        ui = u.copy();
        widthMed = u.pillW();
        heightMed = u.pillH();
        devStreak = 0;
        cVel = 0;
        // The interface does not move between reels, so what we learned about static art around the bar is still
        // valid when the bar is the same size and in the same row. Keep it; otherwise start fresh.
        boolean same = bgPw > 0 && Math.abs(u.pillW() - bgPw) <= 0.04 * bgPw && Math.abs(u.pillT - bgPillT) <= 0.5 * u.pillH();
        if (!same) {
            java.util.Arrays.fill(seen, false);
            seeded = false;
        }
        bgPw = u.pillW();
        bgPillT = u.pillT;
        lastFishX = -1;
        fishMissing = 0;
        failStreak = 0;
    }

    public void unlock() {
        ui = null;
        failStreak = 0;
    }

    public ReelUi model() { return ui; }

    public Measure track(Frame f, Measure m) {
        if (m == null) m = new Measure();
        m.ok = false;
        m.fishFound = false;
        m.progressOk = false;
        m.conf = 0;
        if (ui == null) return m;

        double pw = widthMed, ph = ui.pillH();
        int yc = (int) Math.round(ui.pillCy());
        int[] rows = {yc - (int) (ph / 4), yc, yc + (int) (ph / 4)};
        int winL = Math.max(0, (int) (ui.pillL - 0.9 * pw));
        int winR = Math.min(f.w - 1, (int) (ui.pillR + 0.9 * pw));
        int gap = Math.max(3, (int) (0.07 * pw));

        double[] ls = new double[3], rs = new double[3];
        int good = 0;
        for (int row : rows) {
            if (row < 0 || row >= f.h) continue;
            double bestOverlap = 0, bl = -1, br = -1;
            int s = -1, e = -1;
            for (int x = winL; x <= winR + 1; x++) {
                boolean dark = x <= winR && f.luma(x, row) < DARK;
                if (dark) {
                    if (s < 0) { s = x; e = x; }
                    else if (x - e > gap + 1) {
                        double ov = overlap(s, e, ui.pillL, ui.pillR);
                        if (ov > bestOverlap) { bestOverlap = ov; bl = s; br = e; }
                        s = x; e = x;
                    } else e = x;
                }
            }
            if (s >= 0) {
                double ov = overlap(s, e, ui.pillL, ui.pillR);
                if (ov > bestOverlap) { bestOverlap = ov; bl = s; br = e; }
            }
            if (bl >= 0 && bestOverlap >= 0.4 * pw) {
                ls[good] = bl;
                rs[good] = br;
                good++;
            }
        }
        if (good == 0) {
            failStreak++;
            return m;
        }
        double L = median(ls, good), R = median(rs, good);
        double width = R - L + 1;
        double pillConf = 1.0;

        // vertical extent at four columns along the bar (skips columns the tall fish marker crosses)
        double[] vts = new double[4], vbs = new double[4];
        int vn = 0;
        for (double fx : new double[] {0.2, 0.3, 0.7, 0.8}) {
            int x = (int) Math.round(L + fx * (R - L));
            if (x < 0 || x >= f.w || yc < 0 || yc >= f.h || f.luma(x, yc) >= DARK) continue;
            int t = yc, b = yc;
            while (t > 0 && f.luma(x, t - 1) < DARK) t--;
            while (b < f.h - 1 && f.luma(x, b + 1) < DARK) b++;
            if (b - t + 1 >= 4 && b - t + 1 <= 1.5 * ph) { vts[vn] = t; vbs[vn] = b; vn++; }
        }
        double medT = vn > 0 ? median(vts, vn) : ui.pillT, medB = vn > 0 ? median(vbs, vn) : ui.pillB;
        double medH = medB - medT + 1;

        double dev = Math.abs(width - widthMed) / widthMed;
        boolean resized = false;
        if (dev <= 0.04) {
            devStreak = 0;
            double cx = (L + R + 1) * 0.5;
            L = cx - widthMed * 0.5;
            R = cx + widthMed * 0.5 - 1;
        } else {
            // either the fish marker merged with one end, or the whole interface changed size.
            // A real resize changes width and height by the same ratio; a merge changes only the width.
            double rw = width / widthMed, rh = vn > 0 ? medH / heightMed : 1;
            if (vn > 0 && Math.abs(rh - 1) >= 0.04 && Math.abs(rw - rh) < 0.06) {
                if (++devStreak >= 4) {
                    widthMed = width;
                    heightMed = medH;
                    geometryChanged = true;
                    resized = true;
                    devStreak = 0;
                }
            } else devStreak = 0;
            pillConf = 0.55;
            if (!resized) {
                if (Math.abs(L - (ui.pillL + cVel)) <= Math.abs(R - (ui.pillR + cVel))) R = L + widthMed - 1;
                else L = R - widthMed + 1;
            }
        }
        double T = ui.pillT, B = ui.pillB;
        if (vn > 0) {
            if (resized) { T = medT; B = medB; }
            else if (Math.abs(medH - heightMed) <= 0.04 * heightMed) { T = 0.7 * T + 0.3 * medT; B = 0.7 * B + 0.3 * medB; }
        }
        if (Math.abs(L - ui.pillL) > 0.6 * widthMed) pillConf = Math.min(pillConf, 0.6);

        double oldCx = ui.pillCx();
        ui.pillL = L; ui.pillR = R; ui.pillT = T; ui.pillB = B;
        cVel = 0.6 * cVel + 0.4 * (ui.pillCx() - oldCx);
        m.pillL = L; m.pillR = R; m.pillT = T; m.pillB = B;

        // white outline still present?
        double ph2 = B - T + 1;
        double outTop = brightFrac(f, (int) (L + ph2 / 2), (int) (R - ph2 / 2), (int) T - 3, (int) T - 1, 170);
        double outBot = brightFrac(f, (int) (L + ph2 / 2), (int) (R - ph2 / 2), (int) B + 1, (int) B + 3, 170);
        double outline = Math.min(1.0, Math.max(0, (Math.min(outTop, outBot) - 0.2) / 0.4));
        m.pillConf = pillConf * (0.4 + 0.6 * outline);

        measureProgress(f, m);
        measureFish(f, m);

        m.ok = m.pillConf >= 0.35;
        m.conf = 0.6 * m.pillConf + 0.2 * (m.progressOk ? m.progressConf : 0) + 0.2 * (m.fishFound ? m.fishConf : 0.3);
        if (m.ok) failStreak = 0; else failStreak++;
        return m;
    }

    // ---- progress meter ------------------------------------------------------------------------

    private void measureProgress(Frame f, Measure m) {
        if (!ui.hasProgress) {
            ReelFinder.findProgress(f, ui, (int) ui.pillW(), (int) ui.pillH());
            if (!ui.hasProgress) return;
        }
        int pl = (int) ui.progL, pr = (int) ui.progR, pt = (int) ui.progT, pb = (int) ui.progB;
        double width = pr - pl + 1;
        if (width < 20) { ui.hasProgress = false; return; }

        double[] est = new double[Math.max(1, pb - pt + 1)];
        int valid = 0;
        double darkRowsFrac = 0;
        for (int y = pt; y <= pb; y++) {
            if (y < 0 || y >= f.h) continue;
            int lo = 255, hi = 0;
            for (int x = pl + 2; x <= pr - 2; x++) {
                int l = f.luma(x, y);
                if (l < lo) lo = l;
                if (l > hi) hi = l;
            }
            if (hi - lo < 40) {
                if (hi < 90) darkRowsFrac += 1;
                continue;
            }
            int thr = (lo + hi) / 2;
            int start = -1, end = -1, miss = 0;
            for (int x = pl; x <= pr; x++) {
                boolean bright = f.luma(x, y) >= thr;
                if (bright) {
                    if (start < 0) {
                        if (x - pl > 0.1 * width) break; // fill must begin at the left end
                        start = x;
                    }
                    end = x;
                    miss = 0;
                } else if (start >= 0 && ++miss > 3) break;
            }
            if (start >= 0) est[valid++] = (end - pl + 1) / width;
        }
        if (valid == 0) {
            // no row had contrast: either empty (all dark) or something is wrong
            m.progressOk = darkRowsFrac >= 1;
            m.progress = 0;
            m.progressConf = m.progressOk ? 0.5 : 0;
            return;
        }
        double[] e2 = Arrays.copyOf(est, valid);
        double med = median(e2, valid);
        double spread = 0;
        for (int i = 0; i < valid; i++) spread = Math.max(spread, Math.abs(e2[i] - med));
        m.progress = Math.max(0, Math.min(1, med));
        m.progressOk = true;
        m.progressConf = spread < 0.05 ? 1.0 : (spread < 0.15 ? 0.6 : 0.3);
    }

    // ---- fish marker ---------------------------------------------------------------------------

    private double[] bg = new double[0];
    private boolean[] seen = new boolean[0];
    private boolean seeded;
    private double lastFishX = -1;
    private int fishMissing;

    /**
     * The fish is the dark, tall, thin thing that MOVES. Static art behind the bar (the yin-yang, the
     * swords) is dark too, so each column remembers how dark it normally is and only the excess counts.
     * Columns the bar has just uncovered are remembered as static art, except right where the fish was last
     * seen: the bar usually slides off a fish it was covering.
     */
    private void measureFish(Frame f, Measure m) {
        double ph = ui.pillH();
        int ya = (int) (ui.pillT + 0.2 * ph), yb = (int) (ui.pillB - 0.2 * ph);
        if (yb <= ya) { ya = (int) ui.pillT; yb = (int) ui.pillB; }
        double tl = ui.trackL(), tr = ui.trackR(), len = tr - tl;
        int roiL = Math.max(0, (int) (tl + 0.02 * len)), roiR = Math.min(f.w - 1, (int) (tr - 0.02 * len));
        double margin = 0.06 * ph + 1.0 * Math.abs(cVel) + 2;
        if (cols.length < f.w) cols = new int[f.w];
        if (bg.length < f.w) { bg = new double[f.w]; seen = new boolean[f.w]; seeded = false; }

        int rowsN = Math.max(1, yb - ya + 1);
        for (int x = roiL; x <= roiR; x++) {
            cols[x] = 0;
            if (x >= ui.pillL - margin && x <= ui.pillR + margin) continue;
            int cnt = 0;
            for (int y = ya; y <= yb; y++) if (f.luma(x, y) < 60) cnt++;
            cols[x] = cnt;
        }

        double need = 0.45 * rowsN;
        boolean firstLook = !seeded;
        double[] cand = new double[16], candScore = new double[16];
        int nc = 0;
        int x = roiL;
        while (x <= roiR) {
            double ex = excess(x, firstLook);
            if (ex < need) { x++; continue; }
            int s = x, lastOn = x;
            while (x <= roiR + 1 && x <= lastOn + 2) {
                if (x <= roiR && excess(x, firstLook) >= need) lastOn = x;
                x++;
            }
            int e = lastOn, width = e - s + 1;
            if (width > 0.7 * ph || nc >= cand.length) continue;
            double sum = 0, wx = 0, peak = 0;
            for (int i = s; i <= e; i++) {
                double v = excess(i, firstLook);
                sum += v;
                wx += i * v;
                peak = Math.max(peak, v);
            }
            double xc = wx / sum + 0.5;
            double up = vertical(f, xc, (int) (ui.pillT - 0.85 * ph), (int) (ui.pillT - 0.12 * ph), 0.15 * ph);
            double dn = vertical(f, xc, (int) (ui.pillB + 0.12 * ph), (int) (ui.pillB + 0.65 * ph), 0.15 * ph);
            double tallW = (up >= 0.3 && dn >= 0.3) ? 1.0 : ((up >= 0.3 || dn >= 0.3) ? 0.6 : 0.2);
            cand[nc] = xc;
            candScore[nc] = (peak / rowsN) * tallW;
            nc++;
        }
        double bestAdj = -1, bestX = -1, bestRaw = 0;
        for (int i = 0; i < nc; i++) {
            double sc = candScore[i];
            if (sc < 0.3) continue;
            double d = lastFishX >= 0 && fishMissing < 15 ? Math.abs(cand[i] - lastFishX) : 0;
            double adj = sc - Math.min(0.5, d / (6.0 * ph));
            if (adj > bestAdj) { bestAdj = adj; bestX = cand[i]; bestRaw = sc; }
        }
        if (bestX >= 0) {
            m.fishFound = true;
            m.fishX = bestX;
            m.fishConf = Math.min(1.0, bestRaw);
            lastFishX = bestX;
            fishMissing = 0;
        } else {
            fishMissing++;
        }

        boolean keepOpen = lastFishX >= 0 && fishMissing < 25;
        for (int xx = roiL; xx <= roiR; xx++) {
            if (xx >= ui.pillL - margin && xx <= ui.pillR + margin) { seen[xx] = false; continue; }
            boolean isFish = m.fishFound && Math.abs(xx - m.fishX) <= 0.45 * ph;
            boolean nearLast = keepOpen && Math.abs(xx - lastFishX) <= 0.7 * ph;
            double c = cols[xx];
            if (!seen[xx]) {
                bg[xx] = (isFish || nearLast) ? 0 : c;
                seen[xx] = true;
            } else if (c < bg[xx]) bg[xx] += 0.5 * (c - bg[xx]);
            else bg[xx] += 0.004 * (c - bg[xx]);
        }
        seeded = true;
    }

    private double excess(int x, boolean raw) {
        if (raw || !seen[x]) return cols[x];
        return Math.max(0, cols[x] - bg[x]);
    }

    /** Fraction of rows in [ya, yb] that have a dark pixel within +-half of column xc. */
    private double vertical(Frame f, double xc, int ya, int yb, double half) {
        int xa = (int) Math.floor(xc - half), xb = (int) Math.ceil(xc + half);
        int rowsHit = 0, rowsTot = 0;
        for (int y = ya; y <= yb; y++) {
            if (y < 0 || y >= f.h) continue;
            rowsTot++;
            for (int x = xa; x <= xb; x++) {
                if (x >= 0 && x < f.w && f.luma(x, y) < 70) { rowsHit++; break; }
            }
        }
        return rowsTot == 0 ? 0 : (double) rowsHit / rowsTot;
    }

    // ---- helpers -------------------------------------------------------------------------------

    private static double overlap(double a0, double a1, double b0, double b1) {
        double lo = Math.max(a0, b0), hi = Math.min(a1, b1);
        return Math.max(0, hi - lo + 1);
    }

    private static double brightFrac(Frame f, int xa, int xb, int ya, int yb, int thr) {
        int hit = 0, tot = 0;
        for (int y = ya; y <= yb; y++) {
            for (int x = xa; x <= xb; x++) {
                int l = f.lumaSafe(x, y);
                if (l < 0) continue;
                tot++;
                if (l > thr) hit++;
            }
        }
        return tot == 0 ? 0 : (double) hit / tot;
    }

    private static double median(double[] a, int n) {
        double[] c = Arrays.copyOf(a, n);
        Arrays.sort(c);
        return n % 2 == 1 ? c[n / 2] : 0.5 * (c[n / 2 - 1] + c[n / 2]);
    }
}
