package com.fischmacro;

/** Live objects shared between the app screen, the capture service and the accessibility service. */
final class Shared {
    static final Config cfg = new Config();
    static final Diag diag = new Diag();
    static volatile CaptureService capture;
    static volatile MacroService macro;
    /** One-line message for the app screen (why capture stopped, and so on). */
    static volatile String note = "";

    private Shared() {}
}
