package com.fischmacro;

import java.nio.ByteBuffer;

/** A screen-capture buffer (RGBA) viewed as a Frame. Valid only while the Image it came from is open. */
final class BufferFrame extends Frame {
    private final ByteBuffer buf;
    private final int rowStride, pixelStride;

    BufferFrame(int w, int h, ByteBuffer buf, int rowStride, int pixelStride) {
        super(w, h);
        this.buf = buf;
        this.rowStride = rowStride;
        this.pixelStride = pixelStride;
    }

    @Override
    public int rgb(int x, int y) {
        int p = y * rowStride + x * pixelStride;
        return ((buf.get(p) & 255) << 16) | ((buf.get(p + 1) & 255) << 8) | (buf.get(p + 2) & 255);
    }
}
