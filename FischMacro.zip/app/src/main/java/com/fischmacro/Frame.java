package com.fischmacro;

/**
 * A read-only picture. The vision code only ever asks for pixels through this class, so the same code
 * runs on a phone (backed by the screen-capture buffer) and on a desktop (backed by an image file).
 */
public abstract class Frame {
    public final int w, h;

    protected Frame(int w, int h) {
        this.w = w;
        this.h = h;
    }

    /** Pixel at (x, y) as 0xRRGGBB. Callers keep coordinates inside the frame. */
    public abstract int rgb(int x, int y);

    public final int luma(int x, int y) {
        int p = rgb(x, y);
        return (77 * ((p >> 16) & 255) + 150 * ((p >> 8) & 255) + 29 * (p & 255)) >> 8;
    }

    public final boolean inside(int x, int y) {
        return x >= 0 && y >= 0 && x < w && y < h;
    }

    /** Like luma() but returns -1 outside the frame instead of failing. */
    public final int lumaSafe(int x, int y) {
        return inside(x, y) ? luma(x, y) : -1;
    }
}
