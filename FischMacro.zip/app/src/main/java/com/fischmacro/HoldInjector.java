package com.fischmacro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.WindowManager;

/**
 * Presses the screen through the accessibility service.
 *
 * A hold is a chain of touch segments that each continue the last one, so the finger stays down until a
 * final segment lifts it. A tap first lifts any hold, then sends one short touch. Everything runs on the
 * main thread; the public methods can be called from any thread. A generation counter makes callbacks from
 * gestures that were abandoned by reset() harmless.
 */
final class HoldInjector {
    private static final long SEG_MS = 60;
    private static final long TAP_MS = 45;

    private final AccessibilityService svc;
    private final Handler main = new Handler(Looper.getMainLooper());

    private volatile float fx = 0.62f, fy = 0.40f;
    private volatile boolean lastReq;

    // main-thread state
    private boolean wantHold, down, pending, ending, tapInFlight;
    private float[] tapQ;
    private GestureDescription.StrokeDescription cur;
    private float px, py;
    private int gen;
    volatile long lastOkMs;
    volatile int failStreak;
    private volatile boolean holdAcked;
    private volatile int pressState;
    private volatile long pressMeasured;
    private boolean timedPress;
    private long sentAtMs;

    boolean holdAcked() {
        return holdAcked;
    }

    HoldInjector(AccessibilityService svc) {
        this.svc = svc;
    }

    void setPoint(float x, float y) {
        fx = x;
        fy = y;
    }

    void setHold(boolean hold) {
        if (hold == lastReq) return;
        lastReq = hold;
        if (hold) holdAcked = false;
        main.post(() -> {
            wantHold = hold;
            pump();
        });
    }

    void tap(float x, float y) {
        lastReq = false;
        main.post(() -> {
            wantHold = false;
            tapQ = new float[] {x, y, TAP_MS};
            pump();
        });
    }

    /**
     * One continuous touch of exactly this length (a single gesture, so nothing can lift the finger early).
     * Used for charging a cast. Progress is reported through pressState() and pressMeasuredMs().
     */
    void pressFor(final int ms) {
        lastReq = false;
        pressState = 0;
        pressMeasured = 0;
        main.post(() -> {
            wantHold = false;
            timedPress = true;
            tapQ = new float[] {fx, fy, Math.max(100, ms)};
            pump();
        });
    }

    /** 0 = pressing or not started, 1 = finished and confirmed by Android, -1 = Android refused or cancelled it. */
    int pressState() {
        return pressState;
    }

    long pressMeasuredMs() {
        return pressMeasured;
    }

    /** Forget the current touch and start clean. A finger that is still down is lifted by the system's gesture timeout. */
    void reset() {
        main.post(() -> {
            gen++;
            down = false;
            pending = false;
            ending = false;
            tapInFlight = false;
            if (timedPress) { pressState = -1; timedPress = false; }
            cur = null;
            failStreak = 0;
            pump();
        });
    }

    private Rect screen() {
        WindowManager wm = (WindowManager) svc.getSystemService(android.content.Context.WINDOW_SERVICE);
        return wm.getMaximumWindowMetrics().getBounds();
    }

    private void pump() {
        if (pending) return;
        if (tapQ != null) {
            if (down) {
                endStroke();
                return;
            }
            float[] q = tapQ;
            tapQ = null;
            Rect r = screen();
            Path p = new Path();
            p.moveTo(q[0] * r.width(), q[1] * r.height());
            tapInFlight = true;
            send(new GestureDescription.StrokeDescription(p, 0, (long) q[2], false));
            return;
        }
        if (down) {
            if (wantHold) continueStroke();
            else endStroke();
            return;
        }
        if (wantHold) {
            Rect r = screen();
            px = fx * r.width();
            py = fy * r.height();
            Path p = new Path();
            p.moveTo(px, py);
            cur = new GestureDescription.StrokeDescription(p, 0, SEG_MS, true);
            down = true;
            ending = false;
            send(cur);
        }
    }

    private void continueStroke() {
        Path p = new Path();
        p.moveTo(px, py);
        cur = cur.continueStroke(p, 0, SEG_MS, true);
        send(cur);
    }

    private void endStroke() {
        Path p = new Path();
        p.moveTo(px, py);
        cur = cur.continueStroke(p, 0, 1, false);
        ending = true;
        send(cur);
    }

    private void send(GestureDescription.StrokeDescription s) {
        pending = true;
        sentAtMs = System.currentTimeMillis();
        final int g = gen;
        boolean ok;
        try {
            GestureDescription gd = new GestureDescription.Builder().addStroke(s).build();
            ok = svc.dispatchGesture(gd, new AccessibilityService.GestureResultCallback() {
                @Override
                public void onCompleted(GestureDescription gesture) {
                    if (g != gen) return;
                    pending = false;
                    lastOkMs = System.currentTimeMillis();
                    failStreak = 0;
                    if (down && !ending) holdAcked = true;
                    if (timedPress && tapInFlight) {
                        pressMeasured = System.currentTimeMillis() - sentAtMs;
                        pressState = 1;
                        timedPress = false;
                    }
                    if (ending) {
                        down = false;
                        ending = false;
                        cur = null;
                    }
                    tapInFlight = false;
                    pump();
                }

                @Override
                public void onCancelled(GestureDescription gesture) {
                    if (g != gen) return;
                    abandon();
                }
            }, main);
        } catch (RuntimeException e) {
            ok = false;
        }
        if (!ok) abandon();
    }

    private void abandon() {
        if (timedPress) {
            pressState = -1;
            timedPress = false;
        }
        pending = false;
        down = false;
        ending = false;
        tapInFlight = false;
        cur = null;
        failStreak++;
        final int g = gen;
        main.postDelayed(() -> {
            if (g == gen) pump();
        }, 40);
    }
}
