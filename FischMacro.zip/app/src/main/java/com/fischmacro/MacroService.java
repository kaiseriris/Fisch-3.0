package com.fischmacro;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Accessibility service: presses the screen for the macro and shows the floating control panel
 * (Start / Pause / Resume / Stop, toggles, manual override, calibration helpers, live status).
 */
public class MacroService extends AccessibilityService {
    private HoldInjector injector;
    private WindowManager wm;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout panel, body;
    private TextView status, diag;
    private WindowManager.LayoutParams panelLp;
    private View teachOverlay;
    private boolean expanded = true, showDiag;

    HoldInjector injector() {
        return injector;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        injector = new HoldInjector(this);
        Shared.macro = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        try {
            buildPanel();
        } catch (RuntimeException e) {
            Shared.diag.event("Panel failed: " + e);
        }
        ui.post(refresh);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {}

    @Override
    public void onInterrupt() {
        if (injector != null) injector.reset();
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        teardown();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        teardown();
        super.onDestroy();
    }

    private void teardown() {
        ui.removeCallbacksAndMessages(null);
        if (Shared.macro == this) Shared.macro = null;
        try { if (panel != null) wm.removeView(panel); } catch (RuntimeException ignored) {}
        try { if (teachOverlay != null) wm.removeView(teachOverlay); } catch (RuntimeException ignored) {}
        panel = null;
        teachOverlay = null;
    }

    // ---- panel -------------------------------------------------------------------------------

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(8), dp(4), dp(8), dp(4));
        b.setOnClickListener(l);
        return b;
    }

    private CheckBox check(String t, boolean v, java.util.function.Consumer<Boolean> c) {
        CheckBox cb = new CheckBox(this);
        cb.setText(t);
        cb.setTextColor(Color.WHITE);
        cb.setTextSize(12);
        cb.setChecked(v);
        cb.setOnCheckedChangeListener((x, on) -> {
            c.accept(on);
            Prefs.save(this, Shared.cfg);
        });
        return cb;
    }

    private void withMacro(java.util.function.Consumer<Macro> c) {
        final CaptureService cs = Shared.capture;
        if (cs == null || cs.macro() == null) {
            Shared.note = "Start screen capture in the app first.";
            return;
        }
        cs.post(() -> c.accept(cs.macro()));
    }

    private void buildPanel() {
        final Config k = Shared.cfg;
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(215, 20, 20, 24));
        bg.setCornerRadius(dp(10));
        panel.setBackground(bg);
        panel.setPadding(dp(8), dp(6), dp(8), dp(6));

        // header: drag handle + collapse
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(12);
        status.setText("Fisch Macro");
        head.addView(status, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button toggle = btn("_", v -> {
            expanded = !expanded;
            body.setVisibility(expanded ? View.VISIBLE : View.GONE);
        });
        head.addView(toggle);
        panel.addView(head);

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        panel.addView(body);

        LinearLayout row1 = new LinearLayout(this);
        row1.addView(btn("Start", v -> withMacro(m -> m.start(System.nanoTime()))));
        row1.addView(btn("Pause", v -> withMacro(Macro::pause)));
        row1.addView(btn("Resume", v -> withMacro(m -> m.resume(System.nanoTime()))));
        row1.addView(btn("Stop", v -> withMacro(Macro::stop)));
        body.addView(row1);

        body.addView(check("Auto Cast", k.autoCast, b -> k.autoCast = b));
        body.addView(check("Auto Shake", k.autoShake, b -> k.autoShake = b));
        body.addView(check("Auto Reel", k.autoReel, b -> k.autoReel = b));
        body.addView(check("Soul Judgement", k.soulJudgement, b -> k.soulJudgement = b));
        CheckBox man = new CheckBox(this);
        man.setText("Manual override (you play)");
        man.setTextColor(Color.WHITE);
        man.setTextSize(12);
        man.setOnCheckedChangeListener((x, on) -> withMacro(m -> m.setManual(on)));
        body.addView(man);

        LinearLayout row2 = new LinearLayout(this);
        row2.addView(btn("Teach Shake", v -> startTeach()));
        row2.addView(btn("Recalibrate", v -> withMacro(Macro::recalibrate)));
        row2.addView(btn("Log", v -> {
            showDiag = !showDiag;
            diag.setVisibility(showDiag ? View.VISIBLE : View.GONE);
        }));
        body.addView(row2);

        diag = new TextView(this);
        diag.setTextColor(Color.rgb(190, 230, 190));
        diag.setTextSize(10);
        diag.setTypeface(android.graphics.Typeface.MONOSPACE);
        diag.setVisibility(View.GONE);
        body.addView(diag);

        panelLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = dp(6);
        panelLp.y = dp(6);

        // drag by the header text
        head.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int ox, oy;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX();
                        sy = e.getRawY();
                        ox = panelLp.x;
                        oy = panelLp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = ox + (int) (e.getRawX() - sx);
                        panelLp.y = oy + (int) (e.getRawY() - sy);
                        try { wm.updateViewLayout(panel, panelLp); } catch (RuntimeException ignored) {}
                        return true;
                    default:
                        return false;
                }
            }
        });
        wm.addView(panel, panelLp);
    }

    /** Puts an invisible full-screen layer up for one touch; that touch marks the shake button to learn. */
    private void startTeach() {
        if (Shared.capture == null) {
            Shared.note = "Start screen capture in the app first.";
            return;
        }
        if (teachOverlay != null) return;
        View v = new View(this);
        v.setBackgroundColor(Color.argb(60, 255, 255, 0));
        v.setOnTouchListener((view, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                int[] loc = new int[2];
                view.getLocationOnScreen(loc);
                float fx = (e.getRawX()) / view.getWidth();
                float fy = (e.getRawY() - loc[1]) / view.getHeight();
                CaptureService cs = Shared.capture;
                if (cs != null) cs.teach(fx, fy);
                ui.post(() -> {
                    try { wm.removeView(teachOverlay); } catch (RuntimeException ignored) {}
                    teachOverlay = null;
                });
                return true;
            }
            return true;
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        teachOverlay = v;
        wm.addView(v, lp);
        Shared.note = "Tap the SHAKE button now (bring one up in the game first).";
        // safety: remove the layer after 20 s if untouched
        ui.postDelayed(() -> {
            if (teachOverlay == v) {
                try { wm.removeView(v); } catch (RuntimeException ignored) {}
                teachOverlay = null;
            }
        }, 20000);
    }

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            if (panel == null) return;
            Diag d = Shared.diag;
            CaptureService cs = Shared.capture;
            String s;
            if (cs == null) {
                s = "Fisch Macro: no capture";
            } else {
                Macro m = cs.macro();
                s = "Fisch: " + (m != null && m.isRunning() ? (m.isPaused() ? "paused" : d.stage) : "stopped");
                if (d.progress >= 0) s += "  " + Math.round(d.progress * 100) + "%";
            }
            status.setText(s);
            if (showDiag) diag.setText(Shared.note + "\n" + d.summary() + "\n" + d.eventLog(6));
            ui.postDelayed(this, 400);
        }
    };
}
