package com.fischmacro;

import android.app.Application;
import android.content.Context;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.Date;

/** Loads settings and writes any crash to a file the app screen can show, so a crash is never a mystery. */
public class App extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        try { Prefs.load(this, Shared.cfg); } catch (Throwable ignored) {}
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                try (FileWriter w = new FileWriter(new File(getFilesDir(), "crash.txt"))) {
                    w.write(new Date() + "  thread " + t.getName() + "\n" + sw + "\n--- recent events ---\n"
                            + Shared.diag.eventLog(30));
                }
            } catch (Throwable ignored) {}
            if (prev != null) prev.uncaughtException(t, e);
        });
    }

    static String lastCrash(Context c) {
        try {
            File f = new File(c.getFilesDir(), "crash.txt");
            if (!f.exists()) return "";
            java.io.BufferedReader r = new java.io.BufferedReader(new java.io.FileReader(f));
            StringBuilder sb = new StringBuilder();
            String line;
            int n = 0;
            while ((line = r.readLine()) != null && n++ < 40) sb.append(line).append('\n');
            r.close();
            return sb.toString();
        } catch (Throwable t) {
            return "";
        }
    }

    static void clearCrash(Context c) {
        try { new File(c.getFilesDir(), "crash.txt").delete(); } catch (Throwable ignored) {}
    }
}
