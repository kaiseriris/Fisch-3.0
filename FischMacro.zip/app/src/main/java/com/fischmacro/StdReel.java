package com.fischmacro;

/**
 * Detector and tracker for the standard Fisch reel interface, the one every rod without custom art uses: a long dark
 * track, a white control bar sliding along it, a dark slate fish marker, and a thin progress meter under the track
 * (white fill growing from the left). Nothing needs calibrating, and nothing is a fixed coordinate: the UI is found
 * by its structure anywhere on screen at any size.
 *
 * The fish is dark on the white bar and light on the dark track, so unlike the Zanshin Zen skin it can be seen the
 * whole time, which is what makes high accuracy possible here.
 */
public final class StdReel extends ReelTracker {
    private static final int DARK = 70, WHITE = 185;

    private ReelUi ui;
    /** Geometry of the last successful search, taken over by lock(): track L,T,R,B and meter L,T,R,B. */
    private double[] pendTrack, pendMeter;
    /** Current geometry, for the on-screen view. */
    public final double[] trackBox = new double[4], meterBox = new double[4];
    public volatile boolean hasMeter;
    public volatile double lastBest;

    private double barW, lastCx, cVel, lastFishX = -1, fishVel, fishW;
    private int fishMissing;
    private double trackL, trackR, trackT, trackB;

    @Override public boolean locked() { return ui != null; }
    @Override public ReelUi model() { return ui; }

    @Override
    public void unlock() {
        ui = null;
        failStreak = 0;
        lastFishX = -1;
        fishVel = 0;
    }

    // ---- search -------------------------------------------------------------------------------------------

    private boolean isWhite(int p) {
        int r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
        int l = (77 * r + 150 * g + 29 * b) >> 8;
        return l > WHITE && Math.max(r, Math.max(g, b)) - Math.min(r, Math.min(g, b)) < 55;
    }

    private boolean isDark(int p) {
        int l = (77 * ((p >> 16) & 255) + 150 * ((p >> 8) & 255) + 29 * (p & 255)) >> 8;
        return l < DARK;
    }

    /** White blocks in one row (small gaps bridged, so a fish on the bar does not split it): list of {left, right}. */
    private java.util.ArrayList<int[]> whiteBlocks(Frame f, int y, int fgap, int minLen, int maxLen) {
        java.util.ArrayList<int[]> out = new java.util.ArrayList<>();
        int s = -1, last = -1;
        for (int x = 0; x <= f.w; x++) {
            boolean white = x < f.w && isWhite(f.rgb(x, y));
            if (white) {
                if (s < 0) s = x;
                last = x;
            } else if (s >= 0 && (x - last > fgap || x == f.w)) {
                int len = last - s + 1;
                if (len >= minLen && len <= maxLen) out.add(new int[] {s, last});
                s = -1;
            }
        }
        return out;
    }

    public ReelUi search(Frame f) {
        lastBest = 0;
        pendTrack = null;
        pendMeter = null;
        final int w = f.w, h = f.h;
        int stepY = Math.max(2, h / 170);
        int fgap = Math.max(4, (int) (w * 0.012));
        int minLen = Math.max(8, (int) (w * 0.04)), maxLen = (int) (w * 0.6);
        int n = h / stepY + 1;
        java.util.ArrayList<java.util.ArrayList<int[]>> rows = new java.util.ArrayList<>();
        for (int i = 0; i < n; i++) rows.add(whiteBlocks(f, Math.min(h - 1, i * stepY), fgap, minLen, maxLen));
        boolean[][] used = new boolean[n][];
        for (int i = 0; i < n; i++) used[i] = new boolean[rows.get(i).size()];

        ReelUi best = null;
        double bestScore = 0;
        for (int i = 0; i < n; i++) {
            for (int ci = 0; ci < rows.get(i).size(); ci++) {
                if (used[i][ci]) continue;
                int[] c0 = rows.get(i).get(ci);
                int len0 = c0[1] - c0[0] + 1;
                int last = i, miss = 0, cnt = 1;
                used[i][ci] = true;
                for (int k = i + 1; k < n && miss <= 1; k++) {
                    int found = -1;
                    for (int cj = 0; cj < rows.get(k).size(); cj++) {
                        int[] c = rows.get(k).get(cj);
                        if (Math.abs(c[0] - c0[0]) <= 0.04 * len0 && Math.abs(c[1] - c0[1]) <= 0.04 * len0) { found = cj; break; }
                    }
                    if (found >= 0) { used[k][found] = true; last = k; miss = 0; cnt++; } else miss++;
                }
                double hPx = (last - i + 1) * stepY;
                if (cnt < 2 || hPx < 0.012 * h || hPx > 0.16 * h) continue;
                int ym = ((i + last) / 2) * stepY;
                double[] cand = verify(f, c0[0], c0[1], ym, fgap);
                if (cand != null && cand[0] > bestScore) {
                    bestScore = cand[0];
                    ReelUi u = new ReelUi();
                    u.pillL = cand[5]; u.pillR = cand[6]; u.pillT = cand[3] + 1; u.pillB = cand[4] - 1;
                    u.conf = cand[0];
                    best = u;
                    pendTrack = new double[] {cand[1], cand[3], cand[2], cand[4]};
                    pendMeter = cand.length > 7 ? new double[] {cand[7], cand[8], cand[9], cand[10]} : null;
                }
            }
        }
        lastBest = bestScore;
        if (best == null || bestScore < 0.7) { pendTrack = null; return null; }
        return best;
    }

    /**
     * Checks a white block as a possible control bar: {score, trackL, trackR, trackT, trackB, barL, barR [, meterL, meterT,
     * meterR, meterB]} or null.
     */
    private double[] verify(Frame f, int wL, int wR, int ym, int fgap) {
        int wlen = wR - wL + 1;
        // the bar's exact top and bottom, from a column of it (the fish may stand on it, so try a few)
        int T = -1, B = -1;
        for (double fr : new double[] {0.15, 0.85, 0.3, 0.7}) {
            int x = wL + (int) (fr * wlen);
            if (!isWhite(f.rgb(x, ym))) continue;
            int t = ym, b = ym;
            while (t > 0 && f.luma(x, t - 1) > 165) t--;
            while (b < f.h - 1 && f.luma(x, b + 1) > 165) b++;
            if (b - t + 1 >= 0.01 * f.h && b - t + 1 <= 0.15 * f.h) { T = t; B = b; break; }
        }
        if (T < 0) return null;
        int bh = B - T + 1;
        // the track is a little taller than the bar on each side
        T = Math.max(0, T - 1);
        B = Math.min(f.h - 1, B + 1);
        int th = B - T + 1;
        // the track's ends: walk outward while the whole column is dark (a few non-dark columns bridge the fish)
        int ra = T + (int) (0.2 * th), rb = B - (int) (0.2 * th);
        if (rb <= ra) return null;
        int rs = Math.max(1, (rb - ra) / 5);
        int L = wL, R = wR;
        int gapMax = Math.max(3, fgap);
        int gap = 0;
        for (int x = wL - 1; x >= 0; x--) {
            if (darkFrac(f, x, ra, rb, rs) >= 0.75) { L = x; gap = 0; }
            else if (++gap > gapMax) break;
        }
        gap = 0;
        for (int x = wR + 1; x < f.w; x++) {
            if (darkFrac(f, x, ra, rb, rs) >= 0.75) { R = x; gap = 0; }
            else if (++gap > gapMax) break;
        }
        int w = R - L + 1;
        if (w < 0.15 * f.w || w > 0.92 * f.w || w < 1.35 * wlen || w / (double) th < 6) return null;
        // a bar with no track on either side is just a white thing
        if (L == wL && R == wR) return null;

        // how much of the box is track-coloured (dark or white); the fish and soft edges are the rest
        int cnt = 0, pure = 0;
        int stepX = Math.max(1, w / 120), stepY = Math.max(1, th / 8);
        for (int y = T + 1; y < B; y += stepY)
            for (int x = L; x <= R; x += stepX) {
                int p = f.rgb(x, y);
                cnt++;
                if (isDark(p) || isWhite(p)) pure++;
            }
        double purity = cnt == 0 ? 0 : (double) pure / cnt;
        if (purity < 0.86) return null;
        double sPure = Math.min(1.0, (purity - 0.86) / 0.10);
        double share = (double) wlen / w;
        double sShare = share >= 0.1 && share <= 0.75 ? 1.0 : 0.4;

        double[] meter = findMeter(f, L, R, T, B);
        double sMeter = meter == null ? 0 : 1;
        double score = 0.30 * sPure + 0.15 * sShare + 0.55 * sMeter;
        double[] out = new double[meter == null ? 7 : 11];
        out[0] = score; out[1] = L; out[2] = R; out[3] = T; out[4] = B; out[5] = wL; out[6] = wR;
        if (meter != null) { out[7] = meter[0]; out[8] = meter[1]; out[9] = meter[2]; out[10] = meter[3]; }
        return out;
    }

    private double trackFrac(Frame f, int x, int ya, int yb, int step) {
        int d = 0, t = 0;
        for (int y = ya; y <= yb; y += step) { t++; int p = f.rgb(x, y); if (isDark(p) || isWhite(p)) d++; }
        return t == 0 ? 0 : (double) d / t;
    }

    private double darkFrac(Frame f, int x, int ya, int yb, int step) {
        int d = 0, t = 0;
        for (int y = ya; y <= yb; y += step) { t++; if (isDark(f.rgb(x, y))) d++; }
        return t == 0 ? 0 : (double) d / t;
    }

    /** The progress meter: a thin neutral-dark bar below the track, centred on it, about half as long. */
    private double[] findMeter(Frame f, int L, int R, int T, int B) {
        int th = B - T + 1, tw = R - L + 1;
        double cx = (L + R) / 2.0;
        int y0 = B + Math.max(2, (int) (0.12 * th)), y1 = Math.min(f.h - 1, B + (int) (3.5 * th));
        int gTop = -1, gBot = -1, lastY = -10, gl = 0, gr = 0;
        double[] bestBox = null;
        double bestH = 0;
        for (int y = y0; y <= y1 + 1; y++) {
            int rl = -1, rr = -1;
            if (y <= y1) {
                int x = L - tw / 10;
                int bl = -1, br = -1, bestLen = 0;
                int xEnd = Math.min(f.w - 1, R + tw / 10);
                x = Math.max(0, x);
                while (x <= xEnd) {
                    int p = f.rgb(x, y);
                    if (isDark(p) || isWhite(p)) {
                        int s = x;
                        while (x <= xEnd && (isDark(f.rgb(x, y)) || isWhite(f.rgb(x, y)))) x++;
                        if (x - s > bestLen) { bestLen = x - s; bl = s; br = x - 1; }
                    } else x++;
                }
                if (bestLen >= 0.35 * tw && bestLen <= 0.75 * tw && Math.abs((bl + br) / 2.0 - cx) <= 0.08 * tw) { rl = bl; rr = br; }
            }
            if (rl >= 0 && (gTop < 0 || y - lastY <= 2)) {
                if (gTop < 0) { gTop = y; gl = rl; gr = rr; }
                else { gl = Math.min(gl, rl); gr = Math.max(gr, rr); }
                gBot = y;
                lastY = y;
            } else if (gTop >= 0 && (rl < 0 && y - lastY > 2 || y > y1)) {
                int gh = gBot - gTop + 1;
                if (gh >= Math.max(2, 0.08 * th) && gh <= 0.9 * th && gh > bestH) {
                    // the ends are where the whole height of the meter stops being dark or white, not where one row happens to end
                    int mid = (int) cx;
                    int rs = Math.max(1, gh / 4);
                    int el = mid, er = mid, gp = 0;
                    for (int x = mid; x >= Math.max(0, L - tw / 10); x--) {
                        if (trackFrac(f, x, gTop, gBot, rs) >= 0.6) { el = x; gp = 0; } else if (++gp > 2) break;
                    }
                    gp = 0;
                    for (int x = mid; x <= Math.min(f.w - 1, R + tw / 10); x++) {
                        if (trackFrac(f, x, gTop, gBot, rs) >= 0.6) { er = x; gp = 0; } else if (++gp > 2) break;
                    }
                    if (er - el + 1 >= 0.35 * tw && er - el + 1 <= 0.75 * tw && Math.abs((el + er) / 2.0 - cx) <= 0.08 * tw) {
                        bestH = gh;
                        bestBox = new double[] {el, gTop, er, gBot};
                    }
                }
                gTop = -1;
                if (rl >= 0) { gTop = y; gBot = y; gl = rl; gr = rr; lastY = y; }
            }
        }
        return bestBox;
    }

    // ---- tracking ------------------------------------------------------------------------------------------

    @Override
    public void lock(ReelUi u) {
        ui = u.copy();
        barW = u.pillW();
        lastCx = u.pillCx();
        cVel = 0;
        lastFishX = -1;
        fishVel = 0;
        fishMissing = 0;
        failStreak = 0;
        if (pendTrack != null) {
            trackL = pendTrack[0]; trackT = pendTrack[1]; trackR = pendTrack[2]; trackB = pendTrack[3];
        } else {
            trackL = u.pillL - 0.6 * barW; trackR = u.pillR + 0.6 * barW; trackT = u.pillT - 1; trackB = u.pillB + 1;
        }
        if (pendMeter != null) {
            System.arraycopy(pendMeter, 0, meterBox, 0, 4);
            hasMeter = true;
        } else hasMeter = false;
        fishW = Math.max(3, 0.009 * (trackR - trackL));
        setTrack();
        trackBox[0] = trackL; trackBox[1] = trackT; trackBox[2] = trackR; trackBox[3] = trackB;
    }

    /** The base class and the controller read the bar's travel range from a notional meter: describe the real track that way. */
    private void setTrack() {
        double left = trackL, right = trackR + 1;
        double w = (right - left) / 1.98;
        double c = (left + right) * 0.5;
        ui.hasProgress = true;
        ui.progL = c - w / 2;
        ui.progR = c + w / 2 - 1;
        ui.progT = ui.pillB + 4;
        ui.progB = ui.pillB + 8;
    }

    @Override
    public Measure track(Frame f, Measure m) {
        if (m == null) m = new Measure();
        m.ok = false;
        m.fishFound = false;
        m.progressOk = false;
        m.conf = 0;
        if (ui == null) return m;

        int x0 = (int) Math.max(0, trackL + 2), x1 = (int) Math.min(f.w - 1, trackR - 2);
        int n = x1 - x0 + 1;
        if (n < 20) { failStreak++; return m; }
        double th = trackB - trackT + 1;
        int rowsN = 5;
        double[] lum = new double[n];
        for (int k = 0; k < rowsN; k++) {
            int y = (int) Math.round(trackT + th * (0.22 + 0.56 * k / (rowsN - 1)));
            y = Math.max(0, Math.min(f.h - 1, y));
            for (int x = x0; x <= x1; x++) lum[x - x0] += f.luma(x, y);
        }
        for (int i = 0; i < n; i++) lum[i] /= rowsN;

        // ---- the bar: white span (bridging the fish when it sits on the bar) nearest to where it should be
        int bridge = (int) Math.max(4, Math.round(2.2 * fishW));
        double pred = lastCx + cVel;
        double bl = -1, br = -1, bestD = 1e9;
        int i = 0;
        while (i < n) {
            if (lum[i] <= 150) { i++; continue; }
            int s = i, e = i;
            while (i < n) {
                if (lum[i] > 150) { e = i; i++; }
                else if (i - e <= bridge) i++;
                else break;
            }
            double len = e - s + 1;
            if (len < 0.45 * barW) continue;
            double c = x0 + (s + e) / 2.0;
            double d = Math.abs(c - pred) + Math.abs(len - barW) * 0.5;
            if (d < bestD) { bestD = d; bl = x0 + s; br = x0 + e; }
        }
        if (bl < 0) {
            failStreak++;
            return m;
        }
        double len = br - bl + 1;
        double pillConf = 1.0;
        if (Math.abs(len - barW) > 0.06 * barW) {
            // a piece of the bar is covered or merged with something white: keep the known width and trust the edge that moved least
            pillConf = 0.6;
            if (Math.abs(bl - (lastCx - barW / 2)) <= Math.abs(br - (lastCx + barW / 2))) br = bl + barW - 1;
            else bl = br - barW + 1;
        } else {
            double c = (bl + br) / 2;
            bl = c - (barW - 1) / 2;
            br = c + (barW - 1) / 2;
            barW = 0.97 * barW + 0.03 * len;
        }
        failStreak = 0;
        double cx = (bl + br + 1) * 0.5;
        cVel = 0.5 * cVel + 0.5 * (cx - lastCx);
        lastCx = cx;
        ui.pillL = bl; ui.pillR = br;
        m.ok = true;
        m.pillL = bl; m.pillR = br; m.pillT = ui.pillT; m.pillB = ui.pillB;
        m.pillConf = pillConf;
        m.conf = pillConf;

        measureFish(f, m, lum, x0, bl, br);
        readMeter(f, m);
        return m;
    }

    /** The fish: a narrow column that is neither white nor track-dark, on the bar or off it. */
    private void measureFish(Frame f, Measure m, double[] lum, int x0, double bl, double br) {
        int n = lum.length;
        double minW = Math.max(2, 0.5 * fishW), maxW = Math.max(8, 3.2 * fishW);
        double bestScore = -1, bestX = -1, bestW = 0;
        int i = 0;
        while (i < n) {
            double v = lum[i];
            if (v < 42 || v > 158) { i++; continue; }
            int s = i;
            while (i < n && lum[i] >= 42 && lum[i] <= 158) i++;
            int e = i - 1;
            if (s == 0 || e == n - 1) continue; // the track's own ends
            double cw = e - s + 1;
            double xs = x0 + s, xe = x0 + e;
            boolean atEdge = Math.abs(xs - bl) <= 2.5 || Math.abs(xe - bl) <= 2.5 || Math.abs(xs - br) <= 2.5 || Math.abs(xe - br) <= 2.5;
            // soft bar edges are one or two columns wide; the fish is wider
            if (cw < minW || (atEdge && cw <= Math.max(2, 0.45 * fishW))) continue;
            if (cw > maxW) continue;
            double c = x0 + (s + e) / 2.0;
            // contrast with the neighbours: a fish is clearly different from what is on both sides of it
            double left = s > 0 ? lum[s - 1] : lum[e + 1 < n ? e + 1 : e];
            double right = e + 1 < n ? lum[e + 1] : left;
            double mid = 0;
            for (int k = s; k <= e; k++) mid += lum[k];
            mid /= cw;
            double contrast = Math.min(Math.abs(mid - left), Math.abs(mid - right));
            double score = contrast;
            if (lastFishX >= 0) {
                double predF = lastFishX + fishVel;
                score = score / (1.0 + Math.abs(c - predF) / (barW * 0.6));
            }
            if (score > bestScore) { bestScore = score; bestX = c + 0.5; bestW = cw; }
        }
        if (bestX >= 0 && bestScore >= 12) {
            m.fishFound = true;
            m.fishX = bestX;
            m.fishConf = Math.min(1.0, bestScore / 60.0);
            if (lastFishX >= 0) fishVel = 0.5 * fishVel + 0.5 * (bestX - lastFishX);
            lastFishX = bestX;
            fishMissing = 0;
            if (m.fishConf > 0.5) fishW = 0.9 * fishW + 0.1 * Math.max(2, Math.min(bestW, 3 * fishW));
        } else if (++fishMissing > 12) {
            lastFishX = -1;
            fishVel = 0;
        }
    }

    private void readMeter(Frame f, Measure m) {
        if (!hasMeter) return;
        int l = (int) meterBox[0], t = (int) meterBox[1], r = (int) meterBox[2], b = (int) meterBox[3];
        l = Math.max(0, l); r = Math.min(f.w - 1, r); t = Math.max(0, t); b = Math.min(f.h - 1, b);
        if (r - l < 20 || b < t) return;
        int bestReach = 0, rowsOk = 0, rowsTot = 0;
        int ys = Math.max(1, (b - t) / 4);
        int gapMax = Math.max(2, (r - l) / 60);
        for (int y = t; y <= b; y += ys) {
            rowsTot++;
            int reach = 0, gap = 0;
            for (int x = l; x <= r; x++) {
                if (isWhite(f.rgb(x, y))) { reach = x - l + 1; gap = 0; }
                else if (++gap > gapMax) break;
            }
            if (reach > 0) rowsOk++;
            bestReach = Math.max(bestReach, reach);
        }
        m.progressOk = true;
        m.progressConf = 1.0;
        // the frame's first and last pixels belong to the border, not the fill
        double span = r - l + 1;
        m.progress = Math.max(0, Math.min(1, bestReach / span));
    }
}
