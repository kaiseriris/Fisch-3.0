package com.fischmacro;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/** Setup + settings screen: permissions, start/stop capture, sensitivity, diagnostics and crash log. */
public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 41;
    private TextView state, diag;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        final Config k = Shared.cfg;
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);

        TextView title = new TextView(this);
        title.setText("Fisch Macro 2.0");
        title.setTextSize(22);
        root.addView(title);

        TextView how = new TextView(this);
        how.setText("1. Turn on the Accessibility service (Fisch Macro).\n"
                + "2. Tap Start screen capture and choose \"Entire screen\".\n"
                + "3. Open Roblox > FISCH. Use the floating panel: Start, Pause, Resume, Stop.\n"
                + "4. Bring a shake button up once and use Teach Shake on the panel (it learns what your button looks like).");
        root.addView(how);

        state = new TextView(this);
        state.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(state);

        root.addView(button("Open Accessibility settings", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(button("Samsung: allow restricted settings (App info)", v -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }));
        root.addView(button("Start screen capture", v -> requestCapture()));
        root.addView(button("Stop screen capture", v -> startService(new Intent(this, CaptureService.class).setAction(CaptureService.ACTION_STOP))));

        CheckBox pm = new CheckBox(this);
        pm.setText("Use single-touch pulses instead of Follow mode. Follow mode (unticked, recommended) holds the screen down while the bar must move right and lets go to move left, like a player.");
        pm.setChecked(k.pulseMode);
        pm.setOnCheckedChangeListener((x, on) -> {
            k.pulseMode = on;
            Prefs.save(MainActivity.this, k);
        });
        root.addView(pm);
        root.addView(slider("Sensitivity (reel aggressiveness)", 50, 200, (int) (k.sensitivity * 100), p -> k.sensitivity = p / 100.0));
        root.addView(slider("Detection tolerance (higher = accepts weaker matches)", 50, 150, (int) (k.detectionTolerance * 100), p -> k.detectionTolerance = p / 100.0));
        root.addView(slider("Hold point X (% of screen)", 10, 90, Math.round(k.holdFx * 100), p -> k.holdFx = p / 100f));
        root.addView(slider("Hold point Y (% of screen)", 10, 90, Math.round(k.holdFy * 100), p -> k.holdFy = p / 100f));
        root.addView(slider("Cast hold (ms): how long the cast bar charges", 300, 3000, k.castHoldMs, p -> k.castHoldMs = p));
        root.addView(slider("Wait after catch (ms)", 500, 5000, k.cooldownMs, p -> k.cooldownMs = p));

        addSection(root, "Detection");
        final String[] modes = {"Auto: Zanshin Zen shapes, then the standard UI, then taught colours (recommended)", "Zanshin Zen shapes only", "Taught colours only (needs Colors or Boxes)", "Standard UI only (white bar on a dark track: every rod without custom art)"};
        final Button modeBtn = button("Reel detection: " + modes[Math.max(0, Math.min(3, k.detectMode))], null);
        modeBtn.setOnClickListener(v -> {
            k.detectMode = (k.detectMode + 1) % 4;
            modeBtn.setText("Reel detection: " + modes[k.detectMode]);
            Prefs.save(this, k);
        });
        root.addView(modeBtn);
        final int[] capVals = {1170, 1560, 2340};
        final String[] capNames = {"Fast (1170 px long side)", "Balanced (1560 px, default)", "Sharpest (full screen up to 2340 px; slower, uses more battery)"};
        int ci = 1;
        for (int q = 0; q < capVals.length; q++) if (k.captureLong == capVals[q]) ci = q;
        final int[] capIdx = {ci};
        final Button capBtn = button("Capture quality: " + capNames[ci], null);
        capBtn.setOnClickListener(v -> {
            capIdx[0] = (capIdx[0] + 1) % capVals.length;
            k.captureLong = capVals[capIdx[0]];
            capBtn.setText("Capture quality: " + capNames[capIdx[0]]);
            Prefs.save(this, k);
        });
        root.addView(capBtn);
        TextView calHelp = new TextView(this);
        calHelp.setText("Check: draws a green box on the bar and a red line on the fish so you can see what the macro sees. Probe: with a reel minigame on screen, press Probe on the panel; it holds and releases for about 5 seconds and measures how your rod's bar responds, then keeps that measurement.\n\nBoxes: with a reel minigame on screen, press Boxes on the panel. It freezes a picture of the game; drag the green box over the control bar, the red box over the fish, the yellow box over the whole minigame line the bar travels on (TRACK) and the blue box over the progress meter (METER). Drag a corner to stretch. Switch off any box you do not need, then Save. Colours, sizes and the bar's travel range are learned from the boxes; press it when the meter is partly filled.\n\nColors (tap version): open the floating panel, tick Manual override, start a reel minigame, press Colors, then tap the control bar, then the fish. "
                + "The phone reads their colours from the screen and saves them.");
        calHelp.setTextSize(12);
        root.addView(calHelp);
        root.addView(slider("Color tolerance % (higher = looser colour match)", 40, 250, (int) (k.colorTolerance * 100), p -> k.colorTolerance = p / 100.0));
        CheckBox ad = new CheckBox(this);
        ad.setText("Self-adjust colours while reeling (follows glow/shade changes)");
        ad.setChecked(k.adaptiveColors);
        ad.setOnCheckedChangeListener((x, on) -> { k.adaptiveColors = on; Prefs.save(this, k); });
        root.addView(ad);
        root.addView(button("Clear saved bar measurement (Probe)", v -> {
            CaptureService cs = Shared.capture;
            if (cs != null) cs.clearModel(); else Prefs.clearModel(this);
        }));
        root.addView(button("Clear color calibration", v -> {
            CaptureService cs = Shared.capture;
            if (cs != null) cs.clearColors(); else Prefs.clearColors(this);
        }));

        addSection(root, "Reel tuning");
        CheckBox lf = new CheckBox(this);
        lf.setText("Keep measuring the bar's response while reeling (recommended): re-fits how fast the bar speeds up, falls and reacts every second");
        lf.setChecked(k.liveFit);
        lf.setOnCheckedChangeListener((x, on) -> { k.liveFit = on; Prefs.save(this, k); });
        root.addView(lf);
        CheckBox am = new CheckBox(this);
        am.setText("Experimental: measure the bar's response from each reel and keep it fixed. In the simulator this was not better than live learning, so it is off by default.");
        am.setChecked(k.autoModel);
        am.setOnCheckedChangeListener((x, on) -> { k.autoModel = on; Prefs.save(this, k); });
        root.addView(am);
        root.addView(slider("Follow mode: shortest hold/release before switching (ms)", 40, 400, k.holdMinMs, p -> k.holdMinMs = p));
        root.addView(slider("Pulse mode only: shortest press (ms) - raise this if it still clicks too fast", 60, 500, k.pulseMinMs, p -> k.pulseMinMs = p));
        root.addView(slider("Longest single press (ms)", 200, 1200, k.pulseMaxMs, p -> k.pulseMaxMs = p));
        root.addView(slider("Shortest gap between presses (ms)", 40, 600, k.pulseGapMs, p -> k.pulseGapMs = p));
        root.addView(slider("Give up on a reel after (seconds)", 20, 180, k.maxReelSec, p -> k.maxReelSec = p));

        addSection(root, "Safety and session");
        root.addView(check("Only run while Roblox is in front (pauses by itself otherwise, so taps never land in another app)", k.onlyInRoblox, on -> k.onlyInRoblox = on));
        root.addView(check("Keep the screen on while the panel is showing", k.keepAwake, on -> k.keepAwake = on));
        root.addView(check("Volume-down starts / stops the macro (the volume key then no longer changes volume)", k.volumeKey, on -> k.volumeKey = on));
        root.addView(slider("Stop after this many catches (0 = never)", 0, 500, k.stopAfterCatches, p -> k.stopAfterCatches = p));
        root.addView(slider("Stop after this many minutes (0 = never)", 0, 600, k.stopAfterMin, p -> k.stopAfterMin = p));
        root.addView(slider("Stop after this many casts in a row with no bite (0 = never)", 0, 20, k.maxNoBites, p -> k.maxNoBites = p));

        addSection(root, "Shake and cast");
        root.addView(slider("Shake sensitivity % (higher = reacts to smaller changes)", 50, 200, (int) (k.shakeSens * 100), p -> k.shakeSens = p / 100.0));
        root.addView(slider("Shortest time between shake taps (ms)", 80, 800, k.shakeGapMs, p -> k.shakeGapMs = p));
        root.addView(slider("Random extra cast hold (ms, 0 = always the same)", 0, 600, k.castJitterMs, p -> k.castJitterMs = p));
        root.addView(slider("Give up waiting for a bite after (seconds)", 10, 120, k.biteTimeoutMs / 1000, p -> k.biteTimeoutMs = p * 1000));

        root.addView(button("Forget taught shake button", v -> {
            CaptureService cs = Shared.capture;
            if (cs != null) cs.clearShake(); else Prefs.clearShake(this);
        }));
        root.addView(button("Back up all settings (copies text to the clipboard)", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("fisch backup", Prefs.exportAll(this)));
            Shared.note = "Settings copied. Paste them into a note to keep them.";
        }));
        root.addView(button("Restore settings from the clipboard", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            String txt = cm.hasPrimaryClip() && cm.getPrimaryClip().getItemCount() > 0 ? String.valueOf(cm.getPrimaryClip().getItemAt(0).getText()) : "";
            int n = Prefs.importAll(this, txt);
            if (n < 0) { Shared.note = "The clipboard does not hold a settings backup."; return; }
            Prefs.load(this, k);
            Shared.note = "Restored " + n + " settings.";
            recreate();
        }));
        root.addView(button("Copy diagnostics", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("fisch", Shared.diag.summary() + "\n" + Shared.diag.eventLog(60) + "\n" + lastTrace() + "\n" + App.lastCrash(this)));
        }));

        diag = new TextView(this);
        diag.setTypeface(android.graphics.Typeface.MONOSPACE);
        diag.setTextSize(11);
        diag.setPadding(0, pad / 2, 0, 0);
        root.addView(diag);
    }

    private String lifetimeText() {
        long[] l = Prefs.lifetime(this);
        long done = l[0] + l[1];
        return String.format(java.util.Locale.US, "All time: %d caught, %d lost%s, %.1f h running", l[0], l[1],
                done > 0 ? String.format(java.util.Locale.US, " (%.0f%% caught)", 100.0 * l[0] / done) : "", l[2] / 3600.0);
    }

    private String lastTrace() {
        CaptureService cs = Shared.capture;
        Macro m = cs == null ? null : cs.macro();
        return m == null ? "" : "--- last reel trace ---\n" + m.lastReelTrace;
    }

    private CheckBox check(String t, boolean v, java.util.function.Consumer<Boolean> c) {
        CheckBox cb = new CheckBox(this);
        cb.setText(t);
        cb.setChecked(v);
        cb.setOnCheckedChangeListener((x, on) -> { c.accept(on); Prefs.save(MainActivity.this, Shared.cfg); });
        return cb;
    }

    private void addSection(LinearLayout root, String t) {
        TextView h = new TextView(this);
        h.setText(t);
        h.setTextSize(17);
        h.setPadding(0, (int) (14 * getResources().getDisplayMetrics().density), 0, 0);
        root.addView(h);
    }

    private Button button(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private interface IntSet { void set(int v); }

    private View slider(String label, int min, int max, int val, IntSet set) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        final TextView t = new TextView(this);
        t.setText(label + ": " + val);
        l.addView(t);
        SeekBar s = new SeekBar(this);
        s.setMax(max - min);
        s.setProgress(Math.max(0, Math.min(max - min, val - min)));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean user) {
                t.setText(label + ": " + (p + min));
                if (user) set.set(p + min);
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {}

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                Prefs.save(MainActivity.this, Shared.cfg);
            }
        });
        l.addView(s);
        return l;
    }

    private void requestCapture() {
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        Intent i;
        try {
            // Entire screen only (not a single app window), so capture keeps working after switching to Roblox.
            i = mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay());
        } catch (RuntimeException e) {
            i = mpm.createScreenCaptureIntent();
        }
        startActivityForResult(i, REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_CAPTURE) return;
        if (res != Activity.RESULT_OK || data == null) {
            Shared.note = "Screen capture permission was not granted.";
            return;
        }
        Intent i = new Intent(this, CaptureService.class);
        i.putExtra(CaptureService.EXTRA_CODE, res);
        i.putExtra(CaptureService.EXTRA_DATA, data);
        try {
            startForegroundService(i);
        } catch (RuntimeException e) {
            Shared.note = "Could not start capture: " + e;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ui.post(tick);
    }

    @Override
    protected void onPause() {
        ui.removeCallbacks(tick);
        super.onPause();
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            boolean acc = Shared.macro != null;
            boolean cap = Shared.capture != null;
            CaptureService cs0 = Shared.capture;
            Macro m0 = cs0 == null ? null : cs0.macro();
            String col = m0 == null ? "" : "\nColor calibration: bar " + (m0.colorReel.profile.hasBar ? "learned" : "not set")
                    + ", fish " + (m0.colorReel.profile.hasFish ? "learned" : "not set");
            state.setText("Accessibility service: " + (acc ? "ON" : "OFF") + "\nScreen capture: " + (cap ? "ON" : "OFF")
                    + col + (m0 != null && m0.isRunning() ? "\n" + Shared.diag.stats : "") + "\n" + lifetimeText() + "\n" + Shared.note);
            String crash = App.lastCrash(MainActivity.this);
            diag.setText(Shared.diag.summary() + "\n\n" + Shared.diag.eventLog(12)
                    + (crash.isEmpty() ? "" : "\n--- last crash ---\n" + crash));
            ui.postDelayed(this, 700);
        }
    };
}
