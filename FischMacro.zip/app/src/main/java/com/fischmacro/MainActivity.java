package com.fischmacro;

import android.Manifest;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionConfig;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;

/** Setup + settings screen: permissions, start/stop capture, sensitivity, diagnostics and crash log. */
public class MainActivity extends Activity {
    private static final int REQ_CAPTURE = 41;
    private TextView state, diag;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[] {Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
        final Config k = Shared.cfg;
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, pad, pad, pad);
        ScrollView sv = new ScrollView(this);
        sv.addView(root);
        setContentView(sv);

        TextView title = new TextView(this);
        title.setText("Fisch Macro 2.0");
        title.setTextSize(22);
        root.addView(title);

        TextView how = new TextView(this);
        how.setText("1. Turn on the Accessibility service (Fisch Macro).\n"
                + "2. Tap Start screen capture and choose \"Entire screen\".\n"
                + "3. Open Roblox > FISCH. Use the floating panel: Start, Pause, Resume, Stop.\n"
                + "4. Bring a shake button up once and use Teach Shake on the panel (it learns what your button looks like).");
        root.addView(how);

        state = new TextView(this);
        state.setPadding(0, pad / 2, 0, pad / 2);
        root.addView(state);

        root.addView(button("Open Accessibility settings", v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(button("Samsung: allow restricted settings (App info)", v -> {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }));
        root.addView(button("Start screen capture", v -> requestCapture()));
        root.addView(button("Stop screen capture", v -> startService(new Intent(this, CaptureService.class).setAction(CaptureService.ACTION_STOP))));

        root.addView(slider("Sensitivity (reel aggressiveness)", 50, 200, (int) (k.sensitivity * 100), p -> k.sensitivity = p / 100.0));
        root.addView(slider("Detection tolerance (higher = accepts weaker matches)", 50, 150, (int) (k.detectionTolerance * 100), p -> k.detectionTolerance = p / 100.0));
        root.addView(slider("Hold point X (% of screen)", 10, 90, Math.round(k.holdFx * 100), p -> k.holdFx = p / 100f));
        root.addView(slider("Hold point Y (% of screen)", 10, 90, Math.round(k.holdFy * 100), p -> k.holdFy = p / 100f));
        root.addView(slider("Cast hold (ms): how long the cast bar charges", 300, 3000, k.castHoldMs, p -> k.castHoldMs = p));
        root.addView(slider("Wait after catch (ms)", 500, 5000, k.cooldownMs, p -> k.cooldownMs = p));

        root.addView(button("Forget taught shake button", v -> {
            CaptureService cs = Shared.capture;
            if (cs != null) cs.clearShake(); else Prefs.clearShake(this);
        }));
        root.addView(button("Copy diagnostics", v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("fisch", Shared.diag.summary() + "\n" + Shared.diag.eventLog(60) + "\n" + App.lastCrash(this)));
        }));

        diag = new TextView(this);
        diag.setTypeface(android.graphics.Typeface.MONOSPACE);
        diag.setTextSize(11);
        diag.setPadding(0, pad / 2, 0, 0);
        root.addView(diag);
    }

    private Button button(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setOnClickListener(l);
        return b;
    }

    private interface IntSet { void set(int v); }

    private View slider(String label, int min, int max, int val, IntSet set) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        final TextView t = new TextView(this);
        t.setText(label + ": " + val);
        l.addView(t);
        SeekBar s = new SeekBar(this);
        s.setMax(max - min);
        s.setProgress(Math.max(0, Math.min(max - min, val - min)));
        s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int p, boolean user) {
                t.setText(label + ": " + (p + min));
                if (user) set.set(p + min);
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {}

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                Prefs.save(MainActivity.this, Shared.cfg);
            }
        });
        l.addView(s);
        return l;
    }

    private void requestCapture() {
        MediaProjectionManager mpm = (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        Intent i;
        try {
            // Entire screen only (not a single app window), so capture keeps working after switching to Roblox.
            i = mpm.createScreenCaptureIntent(MediaProjectionConfig.createConfigForDefaultDisplay());
        } catch (RuntimeException e) {
            i = mpm.createScreenCaptureIntent();
        }
        startActivityForResult(i, REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req != REQ_CAPTURE) return;
        if (res != Activity.RESULT_OK || data == null) {
            Shared.note = "Screen capture permission was not granted.";
            return;
        }
        Intent i = new Intent(this, CaptureService.class);
        i.putExtra(CaptureService.EXTRA_CODE, res);
        i.putExtra(CaptureService.EXTRA_DATA, data);
        try {
            startForegroundService(i);
        } catch (RuntimeException e) {
            Shared.note = "Could not start capture: " + e;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        ui.post(tick);
    }

    @Override
    protected void onPause() {
        ui.removeCallbacks(tick);
        super.onPause();
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            boolean acc = Shared.macro != null;
            boolean cap = Shared.capture != null;
            state.setText("Accessibility service: " + (acc ? "ON" : "OFF") + "\nScreen capture: " + (cap ? "ON" : "OFF")
                    + "\n" + Shared.note);
            String crash = App.lastCrash(MainActivity.this);
            diag.setText(Shared.diag.summary() + "\n\n" + Shared.diag.eventLog(12)
                    + (crash.isEmpty() ? "" : "\n--- last crash ---\n" + crash));
            ui.postDelayed(this, 700);
        }
    };
}
