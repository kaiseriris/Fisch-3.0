package com.fischmacro;

/**
 * Colour-based reel tracking, for any rod or skin: it follows the control bar and the fish by the colours you taught
 * it (Calibrate colors), instead of the Zanshin Zen shapes. There is no progress meter in this mode, so catch
 * progress is not read; the fish counts as caught when the interface disappears.
 *
 * Optional self-learning: while it is sure of what it sees, the stored colours drift slowly toward what is on screen,
 * so a bar that changes shade (glow, animation, lighting) keeps being recognised. This is a running average, not a
 * neural network, and it works fully on the phone.
 */
public final class ColorReel extends ReelTracker {
    public ColorProfile profile = new ColorProfile();
    public volatile double tolerance = 1.0;
    public volatile boolean adaptive = true;

    private static final double BASE_TOL = 42;

    private ReelUi ui;
    private double widthLock, heightLock, lastCx, cVel, lastFishX = -1;
    private double seenL = 1e9, seenR = -1e9, anchor0;
    private int frames;
    private double[] bgCol;
    /** Diagnostic: score of the best bar candidate on the last search, even if rejected. */
    public volatile double lastBest;

    @Override public boolean locked() { return ui != null; }
    @Override public ReelUi model() { return ui; }

    @Override
    public void unlock() {
        ui = null;
        failStreak = 0;
        lastFishX = -1;
    }

    private double tol() {
        return BASE_TOL * Math.max(0.4, Math.min(2.5, tolerance));
    }

    // ---- search: find the bar anywhere on screen -----------------------------------------------------

    public ReelUi search(Frame f) {
        lastBest = 0;
        frameW = f.w;
        if (!profile.hasBar) return null;
        double expW = profile.barWFrac * f.w, expH = Math.max(4, profile.barHFrac * f.h);
        double tol = tol();
        int stepY = (int) Math.max(2, expH / 4);
        int maxGap = (int) Math.max(3, expW * 0.06);
        int minRun = (int) (expW * 0.6);
        int yLo = 0, yHi = f.h - 1;
        if (profile.barYFrac > 0) { // the minigame sits at the same height every time: only look around there
            yLo = (int) Math.max(0, profile.barYFrac * f.h - 2.5 * expH - 0.03 * f.h);
            yHi = (int) Math.min(f.h - 1, profile.barYFrac * f.h + 2.5 * expH + 0.03 * f.h);
        }
        int n = f.h / stepY + 1;
        int[] rl = new int[n], rr = new int[n];
        for (int i = 0; i < n; i++) {
            int y = Math.min(f.h - 1, i * stepY);
            if (y < yLo || y > yHi) { rl[i] = -1; rr[i] = -1; continue; }
            int[] run = longestRun(f, y, 0, f.w - 1, tol, maxGap, profile.barR, profile.barG, profile.barB);
            rl[i] = run[0];
            rr[i] = run[1];
        }
        ReelUi best = null;
        double bestScore = 0;
        int i = 0;
        while (i < n) {
            int len = rr[i] - rl[i] + 1;
            if (rl[i] < 0 || len < expW * 0.85 || len > expW * 1.2) { i++; continue; }
            int j = i;
            while (j + 1 < n && rl[j + 1] >= 0 && Math.abs(rl[j + 1] - rl[i]) <= expW * 0.06
                    && Math.abs(rr[j + 1] - rr[i]) <= expW * 0.06) j++;
            double hPx = (j - i + 1) * stepY;
            double wMed = rr[(i + j) / 2] - rl[(i + j) / 2] + 1;
            double sw = 1 - Math.min(1, Math.abs(wMed - expW) / expW);
            double sh = 1 - Math.min(1, Math.abs(hPx - expH) / (expH * 1.0));
            double score = 0.65 * sw + 0.35 * Math.max(0, sh);
            if (score > bestScore) {
                bestScore = score;
                ReelUi u = new ReelUi();
                u.pillL = rl[(i + j) / 2];
                u.pillR = rr[(i + j) / 2];
                int cx = (int) ((u.pillL + u.pillR) / 2);
                if (profile.barXFrac > 0 && Math.abs(cx - profile.barXFrac * f.w) > 0.25 * f.w) { i = j + 1; continue; }
                int[] v = vertical(f, cx, Math.min(f.h - 1, ((i + j) / 2) * stepY), tol, profile.barR, profile.barG, profile.barB);
                u.pillT = v[0];
                u.pillB = v[1];
                u.conf = score;
                // a real bar stands out from what is directly above and below it; a big dark area or UI panel does not
                if (sameColourAround(f, u, tol)) { i = j + 1; continue; }
                best = u;
            }
            i = j + 1;
        }
        lastBest = bestScore;
        if (best == null || bestScore < 0.75 || best.pillH() < expH * 0.6 || best.pillH() > expH * 1.6) return null;
        return best;
    }

    private boolean sameColourAround(Frame f, ReelUi u, double tol) {
        double ph = Math.max(3, u.pillH());
        int gap = 2, band = (int) Math.max(3, ph * 0.5);
        int x0 = (int) (u.pillL + u.pillW() * 0.1), x1 = (int) (u.pillR - u.pillW() * 0.1), step = Math.max(1, (x1 - x0) / 40);
        int hitU = 0, totU = 0, hitD = 0, totD = 0;
        for (int x = x0; x <= x1; x += step)
            for (int k = 0; k < band; k += 2) {
                int yu = (int) u.pillT - gap - k, yd = (int) u.pillB + gap + k;
                if (yu >= 0) { totU++; if (ColorProfile.dist(f.rgb(x, yu), profile.barR, profile.barG, profile.barB) <= tol) hitU++; }
                if (yd < f.h) { totD++; if (ColorProfile.dist(f.rgb(x, yd), profile.barR, profile.barG, profile.barB) <= tol) hitD++; }
            }
        return totU > 0 && totD > 0 && hitU > 0.9 * totU && hitD > 0.9 * totD;
    }

    // ---- tracking ---------------------------------------------------------------------------------------

    @Override
    public void lock(ReelUi u) {
        ui = u.copy();
        widthLock = u.pillW();
        heightLock = Math.max(3, u.pillH());
        lastCx = u.pillCx();
        cVel = 0;
        lastFishX = -1;
        bgCol = null;
        failStreak = 0;
        seenL = u.pillL;
        seenR = u.pillR;
        anchor0 = u.pillCx();
        frames = 0;
        synth();
    }

    /**
     * Without a progress meter, the track's ends are unknown. Start from a window around where the bar was first
     * seen and widen it to every place the bar has actually been.
     */
    private int frameW = 1;

    private void synth() {
        if (profile.hasTrack) {
            double left = profile.trackLFrac * frameW, right = profile.trackRFrac * frameW;
            if (right - left > widthLock * 1.05) { setTrack(left, right); return; }
        }
        double observed = seenR - seenL;
        if (observed >= 0.45 * widthLock) { // the bar has moved enough to show where its ends are: trust that range
            setTrack(seenL - 0.04 * widthLock, seenR + 0.04 * widthLock);
            return;
        }
        double half = Math.max(1.25 * widthLock, Math.max(anchor0 - seenL, seenR - anchor0) + 0.1 * widthLock);
        double left = Math.min(anchor0 - half, seenL - 0.15 * widthLock);
        double right = Math.max(anchor0 + half, seenR + 0.15 * widthLock);
        setTrack(left, right);
    }

    /** The bar's travel range, as the track (the base class reads the track from a notional progress meter). */
    private void setTrack(double left, double right) {
        double w = (right - left) / 1.98;
        double c = (left + right) * 0.5;
        ui.hasProgress = true;
        ui.progL = c - w / 2;
        ui.progR = c + w / 2 - 1;
        ui.progT = ui.pillB + 4;
        ui.progB = ui.pillB + 8;
    }

    @Override
    public Measure track(Frame f, Measure m) {
        if (m == null) m = new Measure();
        m.ok = false;
        m.fishFound = false;
        m.progressOk = false;
        if (ui == null || !profile.hasBar) return m;
        frameW = f.w;
        double tol = tol();
        int maxGap = (int) Math.max(3, widthLock * 0.06);
        double pred = lastCx + cVel;
        int yMid = (int) ((ui.pillT + ui.pillB) / 2);
        // look on a few rows through the bar and take the run that is nearest to where it should be
        int[] offs = {0, -(int) (heightLock * 0.25), (int) (heightLock * 0.25)};
        double bl = 0, br = 0;
        int ok = 0;
        double[] ls = new double[3], rs = new double[3];
        for (int o : offs) {
            int y = Math.max(0, Math.min(f.h - 1, yMid + o));
            int x0 = (int) Math.max(0, pred - widthLock * 1.6), x1 = (int) Math.min(f.w - 1, pred + widthLock * 1.6);
            int[] run = nearestRun(f, y, x0, x1, tol, maxGap, pred, profile.barR, profile.barG, profile.barB);
            if (run[0] < 0) continue;
            int len = run[1] - run[0] + 1;
            if (len < widthLock * 0.55) continue;
            double l = run[0], r = run[1];
            if (len > widthLock * 1.2 || len < widthLock * 0.85) {
                // merged with something of the same colour or partly hidden: keep the known width, trust the edge that moved least
                if (Math.abs(l - (lastCx - widthLock / 2)) <= Math.abs(r - (lastCx + widthLock / 2))) r = l + widthLock - 1;
                else l = r - widthLock + 1;
            }
            ls[ok] = l;
            rs[ok] = r;
            ok++;
        }
        if (ok == 0) {
            failStreak++;
            m.conf = 0;
            return m;
        }
        failStreak = 0;
        for (int i = 0; i < ok; i++) { bl += ls[i]; br += rs[i]; }
        bl /= ok;
        br /= ok;
        int cx = (int) ((bl + br) / 2);
        int[] v = vertical(f, Math.max(0, Math.min(f.w - 1, cx)), Math.max(0, Math.min(f.h - 1, yMid)), tol,
                profile.barR, profile.barG, profile.barB);
        double top = v[0], bottom = v[1];
        if (bottom - top + 1 < heightLock * 0.6 || bottom - top + 1 > heightLock * 1.6) {
            top = yMid - heightLock / 2;
            bottom = top + heightLock - 1;
        }
        double cx2 = (bl + br + 1) * 0.5;
        cVel = 0.5 * cVel + 0.5 * (cx2 - lastCx);
        lastCx = cx2;
        ui.pillL = bl; ui.pillR = br; ui.pillT = top; ui.pillB = bottom;
        seenL = Math.min(seenL, bl);
        seenR = Math.max(seenR, br);
        synth();

        m.ok = true;
        m.pillL = bl; m.pillR = br; m.pillT = top; m.pillB = bottom;
        m.pillConf = Math.min(1.0, ok / 2.0);
        m.conf = m.pillConf;

        measureFish(f, m, tol);
        if (profile.hasProg) readMeter(f, m);
        frames++;
        if (adaptive && m.conf >= 0.99 && frames % 8 == 0) learn(f, m);
        return m;
    }

    /** Progress from the meter box the user placed: how far the filled colour reaches from the left end. */
    private void readMeter(Frame f, Measure m) {
        int l = (int) Math.round(profile.progLFrac * f.w), r = (int) Math.round(profile.progRFrac * f.w);
        int t = (int) Math.round(profile.progTFrac * f.h), b = (int) Math.round(profile.progBFrac * f.h);
        l = Math.max(0, l); r = Math.min(f.w - 1, r); t = Math.max(0, t); b = Math.min(f.h - 1, b);
        if (r - l < 20 || b < t) return;
        double tol = tol() * 0.9;
        int bestReach = 0, rowsOk = 0;
        for (int y = t; y <= b; y += Math.max(1, (b - t) / 4)) {
            int reach = 0, gap = 0, maxGap = Math.max(3, (r - l) / 40);
            for (int x = l; x <= r; x++) {
                if (ColorProfile.dist(f.rgb(x, y), profile.progFillR, profile.progFillG, profile.progFillB) <= tol) { reach = x - l + 1; gap = 0; }
                else if (++gap > maxGap) break;
            }
            if (reach > 0) { rowsOk++; bestReach = Math.max(bestReach, reach); }
        }
        m.progressOk = true;
        m.progressConf = rowsOk > 0 ? 1.0 : 0.6;
        m.progress = Math.max(0, Math.min(1, (double) bestReach / (r - l + 1)));
    }

    private void measureFish(Frame f, Measure m, double tol) {
        if (!profile.hasFish) return;
        double ph = ui.pillH();
        int y0 = (int) Math.max(0, ui.pillT - 2.2 * ph), y1 = (int) Math.min(f.h - 1, ui.pillB + 1.0 * ph);
        // the fish travels along the same track as the bar, so only look there (the bar's widest travel so far, plus a margin)
        int x0 = (int) Math.max(0, Math.min(seenL, anchor0 - widthLock * 1.3) - 0.35 * widthLock);
        int x1 = (int) Math.min(f.w - 1, Math.max(seenR, anchor0 + widthLock * 1.3) + 0.35 * widthLock);
        boolean similar = ColorProfile.dist(((int) profile.barR << 16) | ((int) profile.barG << 8) | (int) profile.barB,
                profile.fishR, profile.fishG, profile.fishB) < tol * 1.6;
        double ftol = similar ? tol * 0.6 : tol;
        // first look beside the bar (above and below it); only if nothing is there, inside the bar's own rows
        double[] r = scanFish(f, x0, x1, y0, y1, true, similar, ftol);
        if (r == null) r = scanFish(f, x0, x1, y0, y1, false, similar, ftol);
        if (r != null) {
            m.fishFound = true;
            m.fishX = r[0];
            m.fishConf = Math.min(1.0, r[1] * 2);
            lastFishX = r[0];
        }
    }

    private double[] scanFish(Frame f, int x0, int x1, int y0, int y1, boolean skipBar, boolean similar, double ftol) {
        int rows = Math.max(1, (y1 - y0) / 2 + 1);
        int w = x1 - x0 + 1;
        double[] col = new double[w];
        for (int y = y0; y <= y1; y += 2) {
            if (skipBar && y >= ui.pillT - 1 && y <= ui.pillB + 1) continue;
            for (int x = x0; x <= x1; x++) {
                if (ColorProfile.dist(f.rgb(x, y), profile.fishR, profile.fishG, profile.fishB) <= ftol) col[x - x0]++;
            }
        }
        if (skipBar) {
            // Things in the scene that happen to have the fish's colour do not move; the fish does. Keep a slow memory of
            // which columns are always fish-coloured and discount them.
            if (bgCol == null || bgCol.length != f.w) {
                bgCol = new double[f.w];
                for (int i = 0; i < w; i++) bgCol[x0 + i] = col[i];
            }
            for (int i = 0; i < w; i++) {
                double mem = bgCol[x0 + i];
                double raw = col[i];
                col[i] = Math.max(0, raw - 0.85 * mem);
                bgCol[x0 + i] = 0.96 * mem + 0.04 * raw;
            }
        }
        double need = 3;
        // clusters of columns with enough fish-coloured pixels; when fish and bar look alike, ignore the bar's own columns
        double bestScore = 0, bestX = -1;
        int minW = (int) Math.max(2, profile.fishWFrac * f.w * 0.5);
        int maxW = (int) Math.max(8, profile.fishWFrac * f.w * 3.0);
        int x = 0;
        while (x < w) {
            if (col[x] < need || (similar && !skipBar && x0 + x >= ui.pillL - 2 && x0 + x <= ui.pillR + 2)) { x++; continue; }
            int s = x;
            double sum = 0, wsum = 0;
            while (x < w && col[x] >= need && !(similar && !skipBar && x0 + x >= ui.pillL - 2 && x0 + x <= ui.pillR + 2)) {
                sum += col[x];
                wsum += col[x] * (x0 + x);
                x++;
            }
            if (x - s < minW || x - s > maxW) continue;
            double cx = wsum / sum;
            double score = sum / (double) rows;
            if (lastFishX >= 0) score *= 1.0 / (1.0 + Math.abs(cx - lastFishX) / (widthLock * 0.8));
            if (score > bestScore) { bestScore = score; bestX = cx; }
        }
        return bestX < 0 ? null : new double[] {bestX, bestScore};
    }

    private void learn(Frame f, Measure m) {
        double a = 0.03;
        int cy = (int) ((ui.pillT + ui.pillB) / 2), cx = (int) ((m.pillL + m.pillR) / 2);
        int[] c = sample(f, cx, cy, 3);
        if (ColorProfile.dist(c[0] << 16 | c[1] << 8 | c[2], profile.barR, profile.barG, profile.barB) < tol() * 0.8) {
            profile.barR += a * (c[0] - profile.barR);
            profile.barG += a * (c[1] - profile.barG);
            profile.barB += a * (c[2] - profile.barB);
        }
        if (m.fishFound && m.fishConf > 0.8) {
            int[] fc = sample(f, (int) m.fishX, cy, 2);
            if (ColorProfile.dist(fc[0] << 16 | fc[1] << 8 | fc[2], profile.fishR, profile.fishG, profile.fishB) < tol() * 0.8) {
                profile.fishR += a * (fc[0] - profile.fishR);
                profile.fishG += a * (fc[1] - profile.fishG);
                profile.fishB += a * (fc[2] - profile.fishB);
            }
        }
    }

    // ---- calibration (tapping the bar / the fish) -------------------------------------------------------

    /**
     * Learns the bar (and optionally the fish) from boxes the user placed over them on a frozen picture.
     * Boxes are {left, top, right, bottom} as fractions of the picture. The colour is the one that is most typical of the
     * inside of the box compared with a ring just outside it, so a loose box still picks the object, not the background.
     * Returns null if it worked, else a short reason.
     */
    public static String calibrateBoxes(Frame f, double[] bar, double[] fish, ColorProfile p) {
        return calibrateBoxes(f, bar, fish, null, null, p);
    }

    /** As above, plus the whole-minigame track and the progress meter (each may be null). */
    public static String calibrateBoxes(Frame f, double[] bar, double[] fish, double[] track, double[] meter, ColorProfile p) {
        p.warning = "";
        if (bar == null) return "No bar box.";
        int[] b = px(f, bar);
        int bw = b[2] - b[0] + 1, bh = b[3] - b[1] + 1;
        if (bw < f.w * 0.05) return "The bar box is too small. Stretch it over the whole control bar.";
        if (bh < 3) return "The bar box is too thin.";
        int[] c = typical(f, b);
        p.barR = c[0]; p.barG = c[1]; p.barB = c[2];
        p.barWFrac = (double) bw / f.w;
        p.barHFrac = (double) bh / f.h;
        p.barYFrac = (b[1] + b[3]) * 0.5 / f.h;
        p.barXFrac = (b[0] + b[2]) * 0.5 / f.w;
        p.hasBar = true;
        p.boxed = true;
        if (fish != null) {
            int[] fb = px(f, fish);
            int fw = fb[2] - fb[0] + 1;
            if (fw >= 2 && fb[3] - fb[1] >= 1) {
                int[] fc = typical(f, fb);
                p.fishR = fc[0]; p.fishG = fc[1]; p.fishB = fc[2];
                p.fishWFrac = Math.max(0.004, (double) fw / f.w);
                p.hasFish = true;
            }
        }
        if (track != null) {
            int[] tb = px(f, track);
            if (tb[2] - tb[0] > bw * 1.05) {
                p.hasTrack = true;
                p.trackLFrac = (double) tb[0] / f.w;
                p.trackRFrac = (double) tb[2] / f.w;
            } else p.warning += "The track box is not wider than the bar, so it was ignored. ";
        }
        if (meter != null) {
            int[] mb = px(f, meter);
            int mw = mb[2] - mb[0] + 1;
            if (mw >= f.w * 0.05 && mb[3] >= mb[1]) {
                int edge = Math.max(2, mw / 12);
                int midY = (mb[1] + mb[3]) / 2;
                int ry = Math.max(0, (mb[3] - mb[1]) / 10); // the meter has an outline and shading: stay near its middle row
                int[] fill = sample(f, mb[0] + edge, midY, Math.max(1, edge / 2), ry);
                int[] empty = sample(f, mb[2] - edge, midY, Math.max(1, edge / 2), ry);
                double d = Math.sqrt(Math.pow(fill[0] - empty[0], 2) + Math.pow(fill[1] - empty[1], 2) + Math.pow(fill[2] - empty[2], 2));
                if (d < 45) p.warning += "The meter looks all one colour (empty or full), so progress was not learned. Press Boxes again when the meter is partly filled. ";
                else {
                    p.hasProg = true;
                    p.progLFrac = (double) mb[0] / f.w; p.progRFrac = (double) mb[2] / f.w;
                    p.progTFrac = (double) mb[1] / f.h; p.progBFrac = (double) mb[3] / f.h;
                    p.progFillR = fill[0]; p.progFillG = fill[1]; p.progFillB = fill[2];
                }
            }
        }
        return null;
    }

    private static int[] px(Frame f, double[] r) {
        int l = (int) Math.max(0, Math.min(f.w - 1, Math.round(Math.min(r[0], r[2]) * f.w)));
        int rr = (int) Math.max(0, Math.min(f.w - 1, Math.round(Math.max(r[0], r[2]) * f.w)));
        int t = (int) Math.max(0, Math.min(f.h - 1, Math.round(Math.min(r[1], r[3]) * f.h)));
        int bb = (int) Math.max(0, Math.min(f.h - 1, Math.round(Math.max(r[1], r[3]) * f.h)));
        return new int[] {l, t, rr, bb};
    }

    /** Colour most over-represented inside the box compared with the ring around it (falls back to the most common). */
    private static int[] typical(Frame f, int[] b) {
        int bw = b[2] - b[0] + 1, bh = b[3] - b[1] + 1;
        int sx = Math.max(1, bw / 60), sy = Math.max(1, bh / 30);
        java.util.HashMap<Integer, double[]> in = new java.util.HashMap<>(), out = new java.util.HashMap<>();
        double nIn = 0, nOut = 0;
        int mx = Math.max(3, bw / 2), my = Math.max(3, bh / 2);
        int x0 = Math.max(0, b[0] - mx), x1 = Math.min(f.w - 1, b[2] + mx), y0 = Math.max(0, b[1] - my), y1 = Math.min(f.h - 1, b[3] + my);
        for (int y = y0; y <= y1; y += sy)
            for (int x = x0; x <= x1; x += sx) {
                boolean inside = x >= b[0] && x <= b[2] && y >= b[1] && y <= b[3];
                int px = f.rgb(x, y);
                int r = (px >> 16) & 255, g = (px >> 8) & 255, bl = px & 255;
                int key = ((r >> 5) << 6) | ((g >> 5) << 3) | (bl >> 5);
                java.util.HashMap<Integer, double[]> m = inside ? in : out;
                double[] a = m.get(key);
                if (a == null) { a = new double[4]; m.put(key, a); }
                a[0]++; a[1] += r; a[2] += g; a[3] += bl;
                if (inside) nIn++; else nOut++;
            }
        double bestScore = -1e9, bestCommon = -1;
        double[] best = null, common = null;
        for (java.util.Map.Entry<Integer, double[]> e : in.entrySet()) {
            double[] o = out.get(e.getKey());
            double s = e.getValue()[0] / Math.max(1, nIn) - (o == null ? 0 : o[0] / Math.max(1, nOut));
            if (s > bestScore) { bestScore = s; best = e.getValue(); }
            if (e.getValue()[0] > bestCommon) { bestCommon = e.getValue()[0]; common = e.getValue(); }
        }
        double[] pick = bestScore > 0.04 ? best : common;
        return new int[] {(int) (pick[1] / pick[0]), (int) (pick[2] / pick[0]), (int) (pick[3] / pick[0])};
    }

    /** Learns the bar from a tap (frame pixels). Returns null if it worked, else a short reason. */
    public static String calibrateBar(Frame f, int tx, int ty, double tolMul, ColorProfile p) {
        // a wide patch, so a thin divider or highlight in the middle of the bar does not become "the colour"
        int[] c = sample(f, tx, ty, Math.max(3, f.w / 150));
        double tol = BASE_TOL * Math.max(0.4, Math.min(2.5, tolMul));
        int maxGap = Math.max(3, f.w * 3 / 100);
        int[] run = nearestRun(f, ty, 0, f.w - 1, tol, maxGap, tx, c[0], c[1], c[2]);
        if (run[0] < 0 || run[1] < tx - 1 || run[0] > tx + 1) return "Could not read the bar there. Tap the middle of the bar.";
        int len = run[1] - run[0] + 1;
        if (len < f.w * 0.06) return "That is too small to be the bar. Tap the middle of the bar.";
        if (len > f.w * 0.9) return "That colour fills the whole screen. Tap the bar itself.";
        int[] v = vertical(f, tx, ty, tol, c[0], c[1], c[2]);
        p.barR = c[0]; p.barG = c[1]; p.barB = c[2];
        p.barWFrac = (double) len / f.w;
        p.barHFrac = (double) (v[1] - v[0] + 1) / f.h;
        p.barYFrac = (v[0] + v[1]) * 0.5 / f.h;
        p.barXFrac = (run[0] + run[1]) * 0.5 / f.w;
        p.hasBar = true;
        return null;
    }

    /** Learns the fish from a tap. Returns null if it worked, else a short reason. */
    public static String calibrateFish(Frame f, int tx, int ty, double tolMul, ColorProfile p) {
        int[] c = sample(f, tx, ty, Math.max(1, f.w / 400));
        double tol = BASE_TOL * Math.max(0.4, Math.min(2.5, tolMul)) * 0.8;
        // icons have shading and an outline, so measure its width with a looser match on a few rows through it and take the widest
        int len = 0;
        for (int dy = -f.h / 80; dy <= f.h / 80; dy += Math.max(1, f.h / 160)) {
            int yy = Math.max(0, Math.min(f.h - 1, ty + dy));
            int[] run = nearestRun(f, yy, Math.max(0, tx - f.w / 8), Math.min(f.w - 1, tx + f.w / 8), tol * 1.8, Math.max(2, f.w / 200), tx, c[0], c[1], c[2]);
            if (run[0] >= 0 && run[0] <= tx && run[1] >= tx) len = Math.max(len, run[1] - run[0] + 1);
        }
        if (len < 2) return "Could not read the fish there. Tap the middle of the fish.";
        p.fishR = c[0]; p.fishG = c[1]; p.fishB = c[2];
        p.fishWFrac = Math.max(0.004, (double) len / f.w);
        p.hasFish = true;
        return null;
    }

    // ---- pixel helpers ------------------------------------------------------------------------------

    /**
     * The dominant colour of a (2r+1)^2 patch: the most common shade (pixels grouped into coarse colour buckets),
     * averaged. A thin divider, highlight or icon in the middle of the patch does not change the answer.
     */
    public static int[] sample(Frame f, int cx, int cy, int r) {
        return sample(f, cx, cy, r, r);
    }

    /** Same, over a patch that is 2*rx+1 wide and 2*ry+1 tall (for thin things such as the progress meter). */
    public static int[] sample(Frame f, int cx, int cy, int rx, int ry) {
        java.util.HashMap<Integer, int[]> bins = new java.util.HashMap<>();
        for (int y = cy - ry; y <= cy + ry; y++)
            for (int x = cx - rx; x <= cx + rx; x++) {
                int px = f.rgb(Math.max(0, Math.min(f.w - 1, x)), Math.max(0, Math.min(f.h - 1, y)));
                int rr = (px >> 16) & 255, gg = (px >> 8) & 255, bb = px & 255;
                int key = ((rr >> 5) << 6) | ((gg >> 5) << 3) | (bb >> 5);
                int[] a = bins.get(key);
                if (a == null) { a = new int[4]; bins.put(key, a); }
                a[0]++; a[1] += rr; a[2] += gg; a[3] += bb;
            }
        int[] best = null;
        for (int[] a : bins.values()) if (best == null || a[0] > best[0]) best = a;
        return new int[] {best[1] / best[0], best[2] / best[0], best[3] / best[0]};
    }

    private static boolean match(Frame f, int x, int y, double tol, double r, double g, double b) {
        return ColorProfile.dist(f.rgb(x, y), r, g, b) <= tol;
    }

    /** Longest run of matching pixels on row y within [x0,x1], bridging gaps up to maxGap. Returns {left,right} or {-1,-1}. */
    public static int[] longestRun(Frame f, int y, int x0, int x1, double tol, int maxGap, double r, double g, double b) {
        int bestL = -1, bestR = -1, curL = -1, last = -1;
        for (int x = x0; x <= x1; x++) {
            if (match(f, x, y, tol, r, g, b)) {
                if (curL < 0) curL = x;
                last = x;
            } else if (curL >= 0 && x - last > maxGap) {
                if (last - curL > bestR - bestL) { bestL = curL; bestR = last; }
                curL = -1;
            }
        }
        if (curL >= 0 && last - curL > bestR - bestL) { bestL = curL; bestR = last; }
        return new int[] {bestL, bestR};
    }

    /** The run (gaps bridged) that contains, or is nearest to, x = near. */
    public static int[] nearestRun(Frame f, int y, int x0, int x1, double tol, int maxGap, double near, double r, double g, double b) {
        int bestL = -1, bestR = -1;
        double bestD = 1e18;
        int curL = -1, last = -1;
        for (int x = x0; x <= x1 + 1; x++) {
            boolean m = x <= x1 && match(f, x, y, tol, r, g, b);
            if (m) {
                if (curL < 0) curL = x;
                last = x;
            } else if (curL >= 0 && (x > x1 || x - last > maxGap)) {
                double d = near < curL ? curL - near : (near > last ? near - last : 0);
                // prefer long runs among equally near ones
                d -= (last - curL) * 0.05;
                if (d < bestD) { bestD = d; bestL = curL; bestR = last; }
                curL = -1;
            }
        }
        return new int[] {bestL, bestR};
    }

    /**
     * Vertical extent of matching pixels through (x, y). Several nearby columns are tried and the tallest taken,
     * because a divider or icon on the exact column would cut it short.
     */
    static int[] vertical(Frame f, int x, int y, double tol, double r, double g, double b) {
        int stepX = Math.max(3, f.w / 120);
        int bestTop = y, bestBottom = y;
        for (int k = -3; k <= 3; k++) {
            int xx = Math.max(0, Math.min(f.w - 1, x + k * stepX));
            if (!match(f, xx, y, tol, r, g, b)) continue;
            int top = y, bottom = y, miss = 0;
            for (int yy = y; yy >= 0; yy--) {
                if (match(f, xx, yy, tol, r, g, b)) { top = yy; miss = 0; } else if (++miss > 2) break;
            }
            miss = 0;
            for (int yy = y; yy < f.h; yy++) {
                if (match(f, xx, yy, tol, r, g, b)) { bottom = yy; miss = 0; } else if (++miss > 2) break;
            }
            if (bottom - top > bestBottom - bestTop) { bestTop = top; bestBottom = bottom; }
        }
        return new int[] {bestTop, bestBottom};
    }
}
