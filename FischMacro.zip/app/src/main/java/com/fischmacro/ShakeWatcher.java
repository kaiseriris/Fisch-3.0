package com.fischmacro;

/**
 * Finds a shake prompt without needing to be taught it: while waiting for a bite the screen is mostly steady,
 * so a new compact, high-contrast object that appears and holds still for a moment is the prompt.
 *
 * How: the frame is reduced to a coarse brightness grid and compared with a quickly adapting background.
 * Cells that differ are grouped into blobs. A blob counts as a prompt when it is button sized, not touching
 * the screen edge, has real detail inside (text or an icon, so the "hole" left by a vanished prompt is not
 * mistaken for one), and appears in the same place on two frames in a row.
 */
public final class ShakeWatcher {

    public static final class Hit {
        public float fx, fy;
        public double score;
    }

    private static final int DIFF = 34;
    private double[] bg = new double[0];
    private int gw, gh, cell, lastW, lastH;
    private boolean seeded;
    private float prevCx = -1, prevCy = -1;
    private int stable;
    private long lastHitMs, lastFrameMs;
    /** Diagnostic: size of the best blob on the last frame as a fraction of screen width (0 if none). */
    public volatile double lastBlob;

    public void reset() {
        seeded = false;
        stable = 0;
        prevCx = -1;
    }

    /** Call with every frame while waiting for a bite. Returns a tap target when a prompt is found, else null. */
    public Hit update(Frame f, long nowMs) {
        cell = Math.max(4, f.w / 170);
        int w = f.w / cell, h = f.h / cell;
        if (w != gw || h != gh || f.w != lastW || f.h != lastH) {
            gw = w; gh = h; lastW = f.w; lastH = f.h;
            bg = new double[gw * gh];
            seeded = false;
        }
        double[] cur = new double[gw * gh];
        int step = Math.max(1, cell / 3);
        for (int y = 0; y < gh; y++) {
            for (int x = 0; x < gw; x++) {
                double s = 0;
                int n = 0;
                for (int j = 0; j < cell; j += step)
                    for (int i = 0; i < cell; i += step) {
                        s += f.luma(x * cell + i, y * cell + j);
                        n++;
                    }
                cur[y * gw + x] = s / n;
            }
        }
        if (!seeded) {
            System.arraycopy(cur, 0, bg, 0, cur.length);
            seeded = true;
            return null;
        }
        boolean[] mask = new boolean[gw * gh];
        for (int i = 0; i < mask.length; i++) mask[i] = Math.abs(cur[i] - bg[i]) > DIFF;

        // blobs by flood fill
        Hit best = null;
        double bestScore = 0, bestFrac = 0;
        float bcx = 0, bcy = 0;
        boolean[] seen = new boolean[mask.length];
        int[] stack = new int[mask.length];
        for (int s0 = 0; s0 < mask.length; s0++) {
            if (!mask[s0] || seen[s0]) continue;
            int sp = 0, minX = gw, maxX = -1, minY = gh, maxY = -1, area = 0;
            stack[sp++] = s0;
            seen[s0] = true;
            while (sp > 0) {
                int p = stack[--sp];
                int px = p % gw, py = p / gw;
                area++;
                if (px < minX) minX = px;
                if (px > maxX) maxX = px;
                if (py < minY) minY = py;
                if (py > maxY) maxY = py;
                if (px > 0 && mask[p - 1] && !seen[p - 1]) { seen[p - 1] = true; stack[sp++] = p - 1; }
                if (px < gw - 1 && mask[p + 1] && !seen[p + 1]) { seen[p + 1] = true; stack[sp++] = p + 1; }
                if (py > 0 && mask[p - gw] && !seen[p - gw]) { seen[p - gw] = true; stack[sp++] = p - gw; }
                if (py < gh - 1 && mask[p + gw] && !seen[p + gw]) { seen[p + gw] = true; stack[sp++] = p + gw; }
            }
            int bw = maxX - minX + 1, bh = maxY - minY + 1;
            double wf = (double) bw / gw, hf = (double) bh / gw;
            if (wf < 0.02 || wf > 0.24 || hf < 0.02 || hf > 0.24) continue;
            double aspect = (double) bw / bh;
            if (aspect < 0.35 || aspect > 3.2) continue;
            if (minX <= 1 || minY <= 1 || maxX >= gw - 2 || maxY >= gh - 2) continue;
            double fill = (double) area / (bw * bh);
            if (fill < 0.30) continue;
            // detail inside the blob in the current frame (rejects plain "holes")
            double sum = 0, sum2 = 0;
            int n = 0;
            for (int y = minY; y <= maxY; y++)
                for (int x = minX; x <= maxX; x++) {
                    double v = cur[y * gw + x];
                    sum += v;
                    sum2 += v * v;
                    n++;
                }
            double mean = sum / n, std = Math.sqrt(Math.max(0, sum2 / n - mean * mean));
            if (std < 22) continue;
            double score = fill * Math.min(1.0, std / 60.0) * Math.min(1.0, wf / 0.05);
            if (score > bestScore) {
                bestScore = score;
                bestFrac = wf;
                bcx = (minX + maxX + 1) * 0.5f * cell / f.w;
                bcy = (minY + maxY + 1) * 0.5f * cell / f.h;
            }
        }
        lastBlob = bestFrac;

        double dt = Math.max(0, Math.min(250, nowMs - lastFrameMs)) / 1000.0;
        lastFrameMs = nowMs;
        double alpha = 1 - Math.exp(-dt / 0.9);
        // the background follows the screen quickly, so a prompt that stays becomes background after a moment
        for (int i = 0; i < bg.length; i++) bg[i] += alpha * (cur[i] - bg[i]);

        if (bestScore < 0.12) {
            stable = 0;
            prevCx = -1;
            return null;
        }
        if (prevCx >= 0 && Math.abs(bcx - prevCx) < 0.02 && Math.abs(bcy - prevCy) < 0.03) stable++;
        else stable = 1;
        prevCx = bcx;
        prevCy = bcy;
        if (stable >= 2 && nowMs - lastHitMs >= 250) {
            lastHitMs = nowMs;
            stable = 0;
            Hit hit = new Hit();
            hit.fx = bcx;
            hit.fy = bcy;
            hit.score = bestScore;
            return hit;
        }
        return null;
    }
}
