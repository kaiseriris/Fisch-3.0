package com.fischmacro;

import java.util.ArrayDeque;
import java.util.Iterator;
import java.util.Locale;

/**
 * Diagnostics: a short event log plus the latest numbers from every part of the pipeline. The dashboard
 * shows this, and it can be copied out when something misbehaves.
 */
public final class Diag {
    private static final int MAX_EVENTS = 120;

    private final ArrayDeque<String> events = new ArrayDeque<>();
    private long t0 = System.nanoTime();
    /** If set (>=0) event times use this clock in ms (tests run faster than real time). */
    public volatile long clockMs = -1;

    // latest measurements (written by the pipeline thread, read by the UI)
    public volatile double reelConf, fishConf, progressConf, sjConf, shakeConf;
    public volatile String detail = "";
    /** Session line for the panel: catches, lost, per hour, running time. */
    public volatile String stats = "";
    /** What the vision sees right now, for the Check overlay: barL, barT, barR, barB, fishX (-1 = hidden), frameW, frameH, barConf, fishConf, method (1 shape, 2 colour). null = nothing found. */
    public volatile double[] vis;
    /** Downscaled copy of the captured screen for the live view (ARGB), and its size. */
    public volatile int[] thumb;
    public volatile int thumbW, thumbH;
    /** Last things found besides the bar: {x, y, time_ms} as screen fractions for the shake button and the Soul Judgement target. */
    public volatile double[] shakeMark, soulMark;
    /** Short text for the Check overlay and the panel. */
    public volatile String visNote = "";
    public volatile String stage = "Idle";
    public volatile double progress = -1;
    public volatile double pillWidthPx, pillHeightPx;
    public volatile double modelA, modelG, modelD, latencyMs;
    public volatile boolean inputInverted;
    public volatile int inputHealth = 100;
    public volatile int frames, searches, researches, catches, escapes, soulCount, shakeTaps, casts, recoveries;
    public volatile double procMsAvg;
    /** Capture size, frames per second seen by the macro, and the latest live fit of the bar's response. */
    public volatile int capW, capH;
    public volatile double fps;
    public volatile String fit = "";
    public volatile String lastEvent = "";

    public synchronized void event(String msg) {
        long ms = clockMs >= 0 ? clockMs : (System.nanoTime() - t0) / 1_000_000L;
        String line = String.format(Locale.US, "%d.%03d  %s", ms / 1000, ms % 1000, msg);
        events.addLast(line);
        while (events.size() > MAX_EVENTS) events.removeFirst();
        lastEvent = msg;
    }

    public synchronized String eventLog(int last) {
        StringBuilder sb = new StringBuilder();
        int skip = Math.max(0, events.size() - last);
        Iterator<String> it = events.iterator();
        int i = 0;
        while (it.hasNext()) {
            String s = it.next();
            if (i++ >= skip) sb.append(s).append('\n');
        }
        return sb.toString();
    }

    public String summary() {
        return String.format(Locale.US,
                "stage=%s frames=%d searches=%d recal=%d%n"
                        + "reel=%.2f fish=%.2f prog=%.2f (%.2f) sj=%.2f shake=%.2f%n"
                        + "capture=%dx%d  fps=%.0f  pill=%.0fx%.0f px  proc=%.1f ms%n"
                        + "model A=%.1f G=%.1f D=%.1f lat=%.0f ms inv=%b health=%d fit=[%s]%n"
                        + "catches=%d escapes=%d soul=%d shakes=%d casts=%d recoveries=%d",
                stage, frames, searches, researches,
                reelConf, fishConf, progress, progressConf, sjConf, shakeConf,
                capW, capH, fps, pillWidthPx, pillHeightPx, procMsAvg,
                modelA, modelG, modelD, latencyMs, inputInverted, inputHealth, fit,
                catches, escapes, soulCount, shakeTaps, casts, recoveries);
    }
}
