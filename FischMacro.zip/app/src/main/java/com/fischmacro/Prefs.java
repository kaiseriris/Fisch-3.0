package com.fischmacro;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

/** Saved settings and the taught shake button. */
final class Prefs {
    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("fisch2", Context.MODE_PRIVATE);
    }

    static void load(Context c, Config k) {
        SharedPreferences p = sp(c);
        k.autoCast = p.getBoolean("autoCast", true);
        k.autoShake = p.getBoolean("autoShake", true);
        k.autoReel = p.getBoolean("autoReel", true);
        k.soulJudgement = p.getBoolean("soul", true);
        k.pulseMode = p.getBoolean("pulse2", false);
        k.steady = p.getBoolean("steady", true);
        k.steadyMinMs = p.getInt("steadymin2", 100);
        k.steadyBandPct = p.getInt("hoverzone", 30);
        k.steadyPeriodMs = p.getInt("hoverper", 200);
        k.holdMinMs = p.getInt("hmin", 120);
        k.autoModel = p.getBoolean("automodel2", false);
        k.liveFit = p.getBoolean("livefit", true);
        k.captureLong = p.getInt("caplong", 1560);
        k.onlyInRoblox = p.getBoolean("onlyrb", true);
        k.stopAfterCatches = p.getInt("stopc", 0);
        k.stopAfterMin = p.getInt("stopm", 0);
        k.maxNoBites = p.getInt("nobite", 6);
        k.keepAwake = p.getBoolean("awake", true);
        k.volumeKey = p.getBoolean("volkey", false);
        k.sensitivity = p.getFloat("sens", 1.0f);
        k.detectionTolerance = p.getFloat("tol", 1.0f);
        k.holdFx = p.getFloat("hx", 0.62f);
        k.holdFy = p.getFloat("hy", 0.40f);
        k.castHoldMs = p.getInt("castMs2", 1000);
        k.cooldownMs = p.getInt("coolMs", 1800);
        k.biteTimeoutMs = p.getInt("biteMs", 30000);
        k.detectMode = p.getInt("dmode", 0);
        k.colorTolerance = p.getFloat("ctol", 1.0f);
        k.adaptiveColors = p.getBoolean("adapt", true);
        k.pulseMaxMs = p.getInt("pmax2", 600);
        k.pulseMinMs = p.getInt("pmin", 180);
        k.pulseGapMs = p.getInt("pgap2", 150);
        k.shakeSens = p.getFloat("ssens", 1.0f);
        k.shakeGapMs = p.getInt("sgap", 200);
        k.castJitterMs = p.getInt("cjit", 0);
        k.maxReelSec = p.getInt("maxreel", 90);
    }

    static void save(Context c, Config k) {
        sp(c).edit()
                .putBoolean("autoCast", k.autoCast)
                .putBoolean("autoShake", k.autoShake)
                .putBoolean("autoReel", k.autoReel)
                .putBoolean("soul", k.soulJudgement)
                .putBoolean("pulse2", k.pulseMode)
                .putBoolean("steady", k.steady)
                .putInt("steadymin2", k.steadyMinMs)
                .putInt("hoverzone", k.steadyBandPct)
                .putInt("hoverper", k.steadyPeriodMs)
                .putInt("hmin", k.holdMinMs)
                .putBoolean("automodel2", k.autoModel)
                .putBoolean("livefit", k.liveFit)
                .putInt("caplong", k.captureLong)
                .putBoolean("onlyrb", k.onlyInRoblox)
                .putInt("stopc", k.stopAfterCatches)
                .putInt("stopm", k.stopAfterMin)
                .putInt("nobite", k.maxNoBites)
                .putBoolean("awake", k.keepAwake)
                .putBoolean("volkey", k.volumeKey)
                .putFloat("sens", (float) k.sensitivity)
                .putFloat("tol", (float) k.detectionTolerance)
                .putFloat("hx", k.holdFx)
                .putFloat("hy", k.holdFy)
                .putInt("castMs2", k.castHoldMs)
                .putInt("coolMs", k.cooldownMs)
                .putInt("biteMs", k.biteTimeoutMs)
                .putInt("dmode", k.detectMode)
                .putFloat("ctol", (float) k.colorTolerance)
                .putBoolean("adapt", k.adaptiveColors)
                .putInt("pmax2", k.pulseMaxMs)
                .putInt("pmin", k.pulseMinMs)
                .putInt("pgap2", k.pulseGapMs)
                .putFloat("ssens", (float) k.shakeSens)
                .putInt("sgap", k.shakeGapMs)
                .putInt("cjit", k.castJitterMs)
                .putInt("maxreel", k.maxReelSec)
                .apply();
    }

    /** Returns the taught shake button as brightness values, or null. Size is the square side. */
    static int[] loadShake(Context c) {
        String s = sp(c).getString("shake", null);
        if (s == null) return null;
        try {
            byte[] b = Base64.decode(s, Base64.NO_WRAP);
            int[] d = new int[b.length];
            for (int i = 0; i < b.length; i++) d[i] = b[i] & 255;
            return d;
        } catch (RuntimeException e) {
            return null;
        }
    }

    static void saveShake(Context c, int[] luma) {
        byte[] b = new byte[luma.length];
        for (int i = 0; i < b.length; i++) b[i] = (byte) luma[i];
        sp(c).edit().putString("shake", Base64.encodeToString(b, Base64.NO_WRAP)).apply();
    }

    static double[] loadColors(Context c) {
        String s = sp(c).getString("colors", null);
        if (s == null) return null;
        try {
            String[] p = s.split(",");
            double[] d = new double[p.length];
            for (int i = 0; i < p.length; i++) d[i] = Double.parseDouble(p[i]);
            return d;
        } catch (RuntimeException e) {
            return null;
        }
    }

    static void saveColors(Context c, ColorProfile cp) {
        double[] a = cp.toArray();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < a.length; i++) sb.append(i == 0 ? "" : ",").append(a[i]);
        sp(c).edit().putString("colors", sb.toString()).apply();
    }

    /** The measured bar response {A, G, D, lat}, or null. */
    static double[] loadModel(Context c) {
        String s = sp(c).getString("model", null);
        if (s == null) return null;
        try {
            String[] p = s.split(",");
            if (p.length < 4) return null;
            double[] d = new double[4];
            for (int i = 0; i < 4; i++) d[i] = Double.parseDouble(p[i]);
            return d;
        } catch (RuntimeException e) {
            return null;
        }
    }

    static void saveModel(Context c, double a, double g, double d, double lat) {
        sp(c).edit().putString("model", a + "," + g + "," + d + "," + lat).apply();
    }

    static void clearModel(Context c) {
        sp(c).edit().remove("model").apply();
    }

    static void clearColors(Context c) {
        sp(c).edit().remove("colors").apply();
    }

    /** All-time totals: {catches, lost, seconds the macro ran}. */
    static long[] lifetime(Context c) {
        SharedPreferences p = sp(c);
        return new long[] {p.getLong("lt_catch", 0), p.getLong("lt_lost", 0), p.getLong("lt_secs", 0)};
    }

    static void addLifetime(Context c, int catches, int lost, long secs) {
        if (catches <= 0 && lost <= 0 && secs < 5) return;
        long[] l = lifetime(c);
        sp(c).edit().putLong("lt_catch", l[0] + catches).putLong("lt_lost", l[1] + lost).putLong("lt_secs", l[2] + Math.max(0, secs)).apply();
    }

    /** Every saved setting, taught colours, shake button and measured model as one line of text for a backup. */
    static String exportAll(Context c) {
        org.json.JSONObject o = new org.json.JSONObject();
        try {
            for (java.util.Map.Entry<String, ?> e : sp(c).getAll().entrySet()) {
                if (e.getKey().startsWith("lt_")) continue; // totals are not settings
                Object v = e.getValue();
                String t = v instanceof Boolean ? "b" : v instanceof Integer ? "i" : v instanceof Long ? "l" : v instanceof Float ? "f" : "s";
                o.put(e.getKey(), new org.json.JSONArray().put(t).put(v));
            }
        } catch (org.json.JSONException ignored) {}
        return "FISCHMACRO1" + Base64.encodeToString(o.toString().getBytes(java.nio.charset.StandardCharsets.UTF_8), Base64.NO_WRAP);
    }

    /** @return number of settings restored, or -1 if the text is not a backup. */
    static int importAll(Context c, String text) {
        if (text == null) return -1;
        text = text.trim();
        if (!text.startsWith("FISCHMACRO1")) return -1;
        try {
            String json = new String(Base64.decode(text.substring(11), Base64.NO_WRAP), java.nio.charset.StandardCharsets.UTF_8);
            org.json.JSONObject o = new org.json.JSONObject(json);
            SharedPreferences.Editor ed = sp(c).edit();
            int n = 0;
            java.util.Iterator<String> it = o.keys();
            while (it.hasNext()) {
                String key = it.next();
                org.json.JSONArray a = o.getJSONArray(key);
                String t = a.getString(0);
                switch (t) {
                    case "b": ed.putBoolean(key, a.getBoolean(1)); break;
                    case "i": ed.putInt(key, a.getInt(1)); break;
                    case "l": ed.putLong(key, a.getLong(1)); break;
                    case "f": ed.putFloat(key, (float) a.getDouble(1)); break;
                    default: ed.putString(key, a.getString(1));
                }
                n++;
            }
            ed.apply();
            return n;
        } catch (Exception e) {
            return -1;
        }
    }

    static void clearShake(Context c) {
        sp(c).edit().remove("shake").apply();
    }
}
