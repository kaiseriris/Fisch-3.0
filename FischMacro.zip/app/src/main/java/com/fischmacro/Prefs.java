package com.fischmacro;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

/** Saved settings and the taught shake button. */
final class Prefs {
    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("fisch2", Context.MODE_PRIVATE);
    }

    static void load(Context c, Config k) {
        SharedPreferences p = sp(c);
        k.autoCast = p.getBoolean("autoCast", true);
        k.autoShake = p.getBoolean("autoShake", true);
        k.autoReel = p.getBoolean("autoReel", true);
        k.soulJudgement = p.getBoolean("soul", true);
        k.sensitivity = p.getFloat("sens", 1.0f);
        k.detectionTolerance = p.getFloat("tol", 1.0f);
        k.holdFx = p.getFloat("hx", 0.62f);
        k.holdFy = p.getFloat("hy", 0.40f);
        k.castHoldMs = p.getInt("castMs2", 1000);
        k.cooldownMs = p.getInt("coolMs", 1800);
        k.biteTimeoutMs = p.getInt("biteMs", 30000);
    }

    static void save(Context c, Config k) {
        sp(c).edit()
                .putBoolean("autoCast", k.autoCast)
                .putBoolean("autoShake", k.autoShake)
                .putBoolean("autoReel", k.autoReel)
                .putBoolean("soul", k.soulJudgement)
                .putFloat("sens", (float) k.sensitivity)
                .putFloat("tol", (float) k.detectionTolerance)
                .putFloat("hx", k.holdFx)
                .putFloat("hy", k.holdFy)
                .putInt("castMs2", k.castHoldMs)
                .putInt("coolMs", k.cooldownMs)
                .putInt("biteMs", k.biteTimeoutMs)
                .apply();
    }

    /** Returns the taught shake button as brightness values, or null. Size is the square side. */
    static int[] loadShake(Context c) {
        String s = sp(c).getString("shake", null);
        if (s == null) return null;
        try {
            byte[] b = Base64.decode(s, Base64.NO_WRAP);
            int[] d = new int[b.length];
            for (int i = 0; i < b.length; i++) d[i] = b[i] & 255;
            return d;
        } catch (RuntimeException e) {
            return null;
        }
    }

    static void saveShake(Context c, int[] luma) {
        byte[] b = new byte[luma.length];
        for (int i = 0; i < b.length; i++) b[i] = (byte) luma[i];
        sp(c).edit().putString("shake", Base64.encodeToString(b, Base64.NO_WRAP)).apply();
    }

    static void clearShake(Context c) {
        sp(c).edit().remove("shake").apply();
    }
}
