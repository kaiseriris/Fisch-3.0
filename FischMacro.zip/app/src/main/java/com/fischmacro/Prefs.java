package com.fischmacro;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

/** Saved settings and the taught shake button. */
final class Prefs {
    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("fisch2", Context.MODE_PRIVATE);
    }

    static void load(Context c, Config k) {
        SharedPreferences p = sp(c);
        k.autoCast = p.getBoolean("autoCast", true);
        k.autoShake = p.getBoolean("autoShake", true);
        k.autoReel = p.getBoolean("autoReel", true);
        k.soulJudgement = p.getBoolean("soul", true);
        k.pulseMode = p.getBoolean("pulse2", false);
        k.holdMinMs = p.getInt("hmin", 120);
        k.autoModel = p.getBoolean("automodel2", false);
        k.onlyInRoblox = p.getBoolean("onlyrb", true);
        k.stopAfterCatches = p.getInt("stopc", 0);
        k.stopAfterMin = p.getInt("stopm", 0);
        k.maxNoBites = p.getInt("nobite", 6);
        k.keepAwake = p.getBoolean("awake", true);
        k.volumeKey = p.getBoolean("volkey", false);
        k.sensitivity = p.getFloat("sens", 1.0f);
        k.detectionTolerance = p.getFloat("tol", 1.0f);
        k.holdFx = p.getFloat("hx", 0.62f);
        k.holdFy = p.getFloat("hy", 0.40f);
        k.castHoldMs = p.getInt("castMs2", 1000);
        k.cooldownMs = p.getInt("coolMs", 1800);
        k.biteTimeoutMs = p.getInt("biteMs", 30000);
        k.detectMode = p.getInt("dmode", 0);
        k.colorTolerance = p.getFloat("ctol", 1.0f);
        k.adaptiveColors = p.getBoolean("adapt", true);
        k.pulseMaxMs = p.getInt("pmax2", 600);
        k.pulseMinMs = p.getInt("pmin", 180);
        k.pulseGapMs = p.getInt("pgap2", 150);
        k.shakeSens = p.getFloat("ssens", 1.0f);
        k.shakeGapMs = p.getInt("sgap", 200);
        k.castJitterMs = p.getInt("cjit", 0);
        k.maxReelSec = p.getInt("maxreel", 90);
    }

    static void save(Context c, Config k) {
        sp(c).edit()
                .putBoolean("autoCast", k.autoCast)
                .putBoolean("autoShake", k.autoShake)
                .putBoolean("autoReel", k.autoReel)
                .putBoolean("soul", k.soulJudgement)
                .putBoolean("pulse2", k.pulseMode)
                .putInt("hmin", k.holdMinMs)
                .putBoolean("automodel2", k.autoModel)
                .putBoolean("onlyrb", k.onlyInRoblox)
                .putInt("stopc", k.stopAfterCatches)
                .putInt("stopm", k.stopAfterMin)
                .putInt("nobite", k.maxNoBites)
                .putBoolean("awake", k.keepAwake)
                .putBoolean("volkey", k.volumeKey)
                .putFloat("sens", (float) k.sensitivity)
                .putFloat("tol", (float) k.detectionTolerance)
                .putFloat("hx", k.holdFx)
                .putFloat("hy", k.holdFy)
                .putInt("castMs2", k.castHoldMs)
                .putInt("coolMs", k.cooldownMs)
                .putInt("biteMs", k.biteTimeoutMs)
                .putInt("dmode", k.detectMode)
                .putFloat("ctol", (float) k.colorTolerance)
                .putBoolean("adapt", k.adaptiveColors)
                .putInt("pmax2", k.pulseMaxMs)
                .putInt("pmin", k.pulseMinMs)
                .putInt("pgap2", k.pulseGapMs)
                .putFloat("ssens", (float) k.shakeSens)
                .putInt("sgap", k.shakeGapMs)
                .putInt("cjit", k.castJitterMs)
                .putInt("maxreel", k.maxReelSec)
                .apply();
    }

    /** Returns the taught shake button as brightness values, or null. Size is the square side. */
    static int[] loadShake(Context c) {
        String s = sp(c).getString("shake", null);
        if (s == null) return null;
        try {
            byte[] b = Base64.decode(s, Base64.NO_WRAP);
            int[] d = new int[b.length];
            for (int i = 0; i < b.length; i++) d[i] = b[i] & 255;
            return d;
        } catch (RuntimeException e) {
            return null;
        }
    }

    static void saveShake(Context c, int[] luma) {
        byte[] b = new byte[luma.length];
        for (int i = 0; i < b.length; i++) b[i] = (byte) luma[i];
        sp(c).edit().putString("shake", Base64.encodeToString(b, Base64.NO_WRAP)).apply();
    }

    static double[] loadColors(Context c) {
        String s = sp(c).getString("colors", null);
        if (s == null) return null;
        try {
            String[] p = s.split(",");
            double[] d = new double[p.length];
            for (int i = 0; i < p.length; i++) d[i] = Double.parseDouble(p[i]);
            return d;
        } catch (RuntimeException e) {
            return null;
        }
    }

    static void saveColors(Context c, ColorProfile cp) {
        double[] a = cp.toArray();
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < a.length; i++) sb.append(i == 0 ? "" : ",").append(a[i]);
        sp(c).edit().putString("colors", sb.toString()).apply();
    }

    /** The measured bar response {A, G, D, lat}, or null. */
    static double[] loadModel(Context c) {
        String s = sp(c).getString("model", null);
        if (s == null) return null;
        try {
            String[] p = s.split(",");
            if (p.length < 4) return null;
            double[] d = new double[4];
            for (int i = 0; i < 4; i++) d[i] = Double.parseDouble(p[i]);
            return d;
        } catch (RuntimeException e) {
            return null;
        }
    }

    static void saveModel(Context c, double a, double g, double d, double lat) {
        sp(c).edit().putString("model", a + "," + g + "," + d + "," + lat).apply();
    }

    static void clearModel(Context c) {
        sp(c).edit().remove("model").apply();
    }

    static void clearColors(Context c) {
        sp(c).edit().remove("colors").apply();
    }

    static void clearShake(Context c) {
        sp(c).edit().remove("shake").apply();
    }
}
