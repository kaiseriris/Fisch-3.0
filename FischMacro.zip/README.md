# Fisch Macro 2.0

Reads the screen (Android screen capture) and plays the FISCH reel minigame by pressing the screen through an accessibility service. It only reads pixels and sends touches.

## What it does
- Loop: Auto Cast -> wait for bite / Auto Shake -> Auto Reel -> catch/escape detection -> cooldown -> cast again, with watchdogs (stale frames, bite timeout, 90 s reel cap).
- Vision (pure Java, `Macro` / `ReelFinder` / `ReelTracker`): finds the control bar (size, position, resize), the fish marker, and the progress meter from the pixels; no fixed coordinates; confidence scores, automatic re-lock/recalibration.
- Black Fairy Rod (Zanshin Zen skin) is assumed. Soul Judgement: finds the big knife graphic, taps the centre target, accounts for the +55% progress and 4 s fish stun, never double-taps, verifies the jump.
- Predictive reel controller: learns bar acceleration/gravity/drag and input latency online, simulates hold vs release ahead, detects inputs that are not reaching the game and resets the touch.
- Floating panel (Start / Pause / Resume / Stop, Cast/Shake/Reel/Soul toggles, Manual override, Teach Shake, Recalibrate, Log) + settings and diagnostics in the app.
- Android 14 / Galaxy S24: mediaProjection foreground service started before `getMediaProjection`, callback registered before the VirtualDisplay, full-screen capture config, projection-stop handling, rotation resize, throttled frames.

## Casting
The cast is one continuous press of the length set by "Cast hold (ms)" (default 1000 ms, adjustable 300-3000 in the app). The app logs how long Android really held it (Log button). If the cast bar needs longer or shorter, change that slider.

## First run
1. Install, open the app. Samsung: App info > (three dots) > Allow restricted settings, and turn off Auto Blocker if it blocks the install.
2. Turn on Accessibility > Fisch Macro.
3. Tap Start screen capture, choose Entire screen.
4. Open Roblox > FISCH, press Start on the floating panel.
5. Shake: with nothing taught, the macro spots a new button-sized prompt that appears while waiting and taps it (no setup). For exact matching, bring a shake button up and press Teach Shake on the panel, then tap the button once.
6. The panel's status line shows what it is waiting for (seconds, shake taps, reel match %). If it sits at "reel match" 0% while the minigame is on screen, tap Log and send me the numbers.

Installing a new build over an old one: this version uses a fixed signing key, so future builds update in place. If Android says "App not installed" on the first update, uninstall the old Fisch Macro once (it was signed with a different key), then install.

If anything misbehaves: app screen > Copy diagnostics (includes the last crash).

## Build
GitHub Actions workflow `.github/workflows/build.yml`: upload this project (or `FischMacro.zip`) to the repo, run Actions > Build Fisch Macro APK. Local: `gradle :app:assembleDebug` (Gradle 8.9, JDK 17).

## Tests (desktop, no Android needed)
`tools/` holds a game simulator using the real Zanshin Zen art. See `tools/FullLoopTest.java`.
