# Fisch Macro 2.0

Reads the screen (Android screen capture) and plays the FISCH reel minigame by pressing the screen through an accessibility service. It only reads pixels and sends touches.

## What it does
- Loop: Auto Cast -> wait for bite / Auto Shake -> Auto Reel -> catch/escape detection -> cooldown -> cast again, with watchdogs (stale frames, bite timeout, 90 s reel cap).
- Vision (pure Java, `Macro` / `ReelFinder` / `ReelTracker`): finds the control bar (size, position, resize), the fish marker, and the progress meter from the pixels; no fixed coordinates; confidence scores, automatic re-lock/recalibration.
- Black Fairy Rod (Zanshin Zen skin) is assumed. Soul Judgement: finds the big knife graphic, taps the centre target, accounts for the +55% progress and 4 s fish stun, never double-taps, verifies the jump.
- Predictive reel controller: learns bar acceleration/gravity/drag and input latency online, simulates hold vs release ahead, detects inputs that are not reaching the game and resets the touch.
- Floating panel (Start / Pause / Resume / Stop, Cast/Shake/Reel/Soul toggles, Manual override, Teach Shake, Recalibrate, Log) + settings and diagnostics in the app.
- Android 14 / Galaxy S24: mediaProjection foreground service started before `getMediaProjection`, callback registered before the VirtualDisplay, full-screen capture config, projection-stop handling, rotation resize, throttled frames.

## Reeling input
Each push on the reel is ONE committed touch (about 0.09-0.45 s) chosen by the look-ahead, with at least 0.08 s between touches, so it taps like a person (a few times a second) instead of flicking the screen on and off. The old continuous-hold mode is still there: untick "Reel with single-touch pulses" in the app.

## Casting
The cast is one continuous press of the length set by "Cast hold (ms)" (default 1000 ms, adjustable 300-3000 in the app). The app logs how long Android really held it (Log button). If the cast bar needs longer or shorter, change that slider.

## First run
1. Install, open the app. Samsung: App info > (three dots) > Allow restricted settings, and turn off Auto Blocker if it blocks the install.
2. Turn on Accessibility > Fisch Macro.
3. Tap Start screen capture, choose Entire screen.
4. Open Roblox > FISCH, press Start on the floating panel.
5. Shake: with nothing taught, the macro spots a new button-sized prompt that appears while waiting and taps it (no setup). For exact matching, bring a shake button up and press Teach Shake on the panel, then tap the button once.
6. The panel's status line shows what it is waiting for (seconds, shake taps, reel match %). If it sits at "reel match" 0% while the minigame is on screen, tap Log and send me the numbers.

Installing a new build over an old one: this version uses a fixed signing key, so future builds update in place. If Android says "App not installed" on the first update, uninstall the old Fisch Macro once (it was signed with a different key), then install.

If anything misbehaves: app screen > Copy diagnostics (includes the last crash).

## Build
GitHub Actions workflow `.github/workflows/build.yml`: upload this project (or `FischMacro.zip`) to the repo, run Actions > Build Fisch Macro APK. Local: `gradle :app:assembleDebug` (Gradle 8.9, JDK 17).

## Tests (desktop, no Android needed)
`tools/` holds a game simulator using the real Zanshin Zen art. See `tools/FullLoopTest.java`.

## 2.1: more settings, colour calibration, colour/adaptive detection

**Reel detection** (app screen > Detection): *Auto* looks for the Zanshin Zen shapes first and falls back to colours;
*Shapes only*; *Colours only*.

**Calibrate colors** (works for any rod): bring up a reel minigame, tick *Manual override* on the floating panel so the
macro does not press, press **Colors**, tap the middle of the control bar, then tap the fish. The phone reads both
colours and sizes from the captured screen and saves them. In colour mode there is no progress meter, so a reel that ran a
while and then disappeared is counted as caught.

**Adaptive colours** ("AI"): while sure of the bar, the stored colours drift slowly toward what is on screen, and the
fish search ignores things in the scene that have the fish's colour but never move. This is a running average and a
motion check running on the phone, not a neural network. If the fish is almost the same colour as the bar or the
background, fish tracking is weaker; the bar is still followed.

**Clicking too fast?** Raise *Shortest press* and *Shortest gap between presses* (defaults 180 ms / 150 ms, about 2 presses
per second in the simulator). Other new settings: longest press, give-up time for a reel and for a bite, shake
sensitivity and tap spacing, random extra cast hold, colour tolerance.

## Reeling: Follow mode (default)

Researched mechanics (Fisch wiki/guides): holding the screen moves the white control bar to the RIGHT, letting go lets it
fall to the LEFT; keeping the fish line inside the bar fills the progress meter, otherwise it drains. Rod stats change the
bar size (Control) and how twitchy the fish and the bar are (Resilience), so the macro learns the bar's response live.

Follow mode holds the screen down while the bar has to move right, and lets go while it has to move left, planning ahead
from the fish's speed and the bar's measured momentum and input delay. Unlike pulse mode it can hold continuously, so it
can climb against the bar's fall. *Follow mode: shortest hold/release* limits how fast it may switch (default 120 ms).
The floating panel status shows HOLD/release, where the fish is relative to the bar centre, and the share of time the
fish has been inside the bar. Pulse mode (single presses) is still available as a checkbox.

## Reel records
Each reel writes a summary line to the log (time, share of time the fish was in the bar, hold/release switches per second,
learned bar model, caught or lost). *Copy diagnostics* in the app also includes the samples of the last reel (time, bar
centre, fish position, hold, in-bar), so real-phone behaviour can be checked and tuned from real data.

## Check and Probe (calibration)
- **Check** (floating panel): draws a green box on the control bar and a red line on the fish as the vision sees them, with
  a readout (bar size, confidence). Works while the macro is stopped, so you can play a reel yourself and see whether
  detection is right. If it is wrong, use Recalibrate, change Reel detection, or Calibrate colors.
- **Probe** (floating panel): with a reel minigame on screen, the macro holds and releases the screen on a fixed schedule
  for about 5 seconds, watches how the bar moves, and fits the bar's response (speed up, fall back, drag, input delay). The
  result is saved and used from the start of every reel, so the first seconds of each reel are no longer a guess. In the
  simulator the fit lands within about 10% of the true values. *Clear saved bar measurement* in the app removes it.

## View (live picture of what the macro sees)
**View** on the floating panel opens a small live copy of the captured screen in the top-right corner, with the control bar
(green box), fish (red line), progress meter (blue box), shake button (yellow circle) and Soul Judgement target (pink circle)
drawn on it, plus the confidence of each detection, the stage, and which method (shape or colour) found the reel. It works
while the macro runs or is stopped. Press View again to close it.

## Boxes (stretch-to-fit calibration)
**Boxes** on the floating panel freezes one picture of the game (have the reel minigame on screen) and shows it full screen
with a green box for the control bar and a red box for the fish. Drag a box to move it, drag a corner to stretch it, and press
Save. The bar's colour, width and height, its height on screen, and the fish's colour and size are learned from the boxes
(colours are taken from what is typical inside the box compared with just outside it, so a loose box still works). "No fish
box" skips the fish. It feeds the colour detector, so set *Reel detection* to Auto or Colours only. The older **Colors**
(two taps) button is still there.

Boxes now has four boxes: BAR (green), FISH (red), TRACK (yellow: the whole line the bar can travel on, so the macro knows
how far left and right the bar can go) and METER (blue: the progress bar; its filled colour is learned and progress is then
read from it, so colour mode knows when a fish is nearly caught). FISH, TRACK and METER each have an on/off switch. Take the
picture while the meter is partly filled.

## Standard UI (every rod without custom art)
Detected automatically, nothing to calibrate (Reel detection: Auto, or "Standard UI only"). The macro finds a white control bar
sitting in a long dark track with a thin progress meter under it, wherever it is on screen and at any size, then follows the
bar, the dark fish marker (visible both on the white bar and on the dark track) and the meter's white fill. Zanshin Zen keeps its
own shape detector; Auto tries Zanshin shapes, then the standard UI, then taught colours.

## Controller
- Plans a few hundred milliseconds ahead with a model of the bar (speeds up while held, falls while released, drag, and the
  delay between the decision and what shows on screen), and re-plans every frame. It holds to move right, releases to move left,
  and alternates short holds and releases to stay on the fish.
- The bar's response is **re-measured while reeling**: about once a second the macro fits speed-up, fall, drag and input delay to
  the last 4.5 s of what the bar really did (setting "Keep measuring the bar's response", on by default). The earlier quick
  per-frame estimate was biased and cost accuracy. Probe still gives a starting measurement.
- Fixed in this version: the "hold" and "release" choices both contained "release throughout", so they could tie and the bar could
  sit holding at a wall while the fish was far away. Dead-input detection now looks at one unbroken hold or release rather than
  decayed totals (short alternating holds that keep the bar still used to trigger false "presses not reaching the game"
  resets). A model learned while input was dead is thrown away and the last good model restored. Inverted-hold detection needs
  both halves of the evidence (held = falls, released = rises).
- A weak "fish" that has not moved for a second is learned as background and the fish is searched for again.

## Test results (simulator; full loop: capture, detection, tracking, controller, touch, bar movement)
The simulator is a desktop program that draws the game UI, moves a bar with a delay and noise, and feeds the macro pictures. It is
not the game. Numbers are time the fish was inside the bar.

| Scenario | In bar | Fish left the bar | Mean time to get back |
|---|---|---|---|
| Standard UI, 150 s | 96% | 2/min | 0.2 s |
| Standard UI, small and moved | 97% | 3/min | 0.3 s |
| Standard UI, faster fish | 93% | 6/min | 0.1 s |
| Sudden end-to-end reversals | 89% | 21/min | 0.2 s |
| Fish marker lost 0.4 s every 3 s | 96% | 4/min | 0.2 s |
| Input stops reaching the game 3 times | 96% | 2/min | 1.0 s |
| Long run 600 s | 97% | 2/min | 0.2 s |
| Hold direction swapped | 81% (first reel learns it) | | |
| Scylla-style (assumed, see below) | 84% | 40/min | 0.2 s |
| Zanshin Zen, full loop (3 scenarios) | 55-75% | 16-27/min | 0.5-0.8 s |

Zanshin Zen is lower because that skin's fish is as dark as the bar and cannot be seen while it is inside it. Known failing
checks in the suite: Zanshin in-bar targets (80% / 75%), the macro's catch count disagreeing with the simulated game on Zanshin
runs (for example 9 vs 14), and Zanshin fish tracking error with a small, moved UI.

**Scylla:** the text guides I could read say Scylla is a Secret-rarity fish with a very large progress-speed penalty; none of them
describe how it moves in the reeling minigame, and I could not watch video. The Scylla scenario is therefore an assumption
(fast, erratic, frequent reversals, slow progress), not a measurement of the real fish.

None of this has been run on a phone, and the Android code has never been compiled against the Android SDK by me.

## Robustness sweep (standard UI, 75 s each, in bar)
Slow bar (A5 G6) 94%, fast bar (A16 G18) 97%, input delay 150 ms 97%, 220 ms 91%, 10% of presses dropped 98%, fish 1.6x faster
92%, 2.2x faster 95%, slow bar and fish 1.5x 94%. Run these yourself with `-Dsa= -Dsg= -Dsd= -Dslat= -Ddrop= -Dfmul=`.

## Also new
- All-time totals (caught, lost, hours running) shown in the app.
- Back up all settings to the clipboard as one line of text and restore them later (includes taught colours, shake button and
  the measured bar response).
- Capture quality setting (1170 / 1560 / full-screen up to 2340 px), and capture size and frames per second in the diagnostics.
- The calibration overlay has a Cancel button.
- A reel that ends within 4 s of a landed Soul Judgement is counted as caught.

## Safety and session settings
- **Only run while Roblox is in front** (on by default): the accessibility service watches which app is in front. If Roblox
  is left (home, recents, another app) the macro pauses itself and resumes when Roblox is back, so taps never land in another
  app. Start refuses to run while another app is known to be in front.
- **Stop after N catches / N minutes**: the macro finishes the current fish and stops, and says why.
- **No-bite alert**: after N casts in a row with no bite (default 6) it stops and says so, since that usually means no rod is
  equipped or you are not at water.
- **Keep screen on** while the panel is showing.
- **Volume-down toggle** (off by default): start / stop without touching the panel. The volume key then no longer changes volume.
- **Session line** on the panel and in the app: caught, lost, per hour, running time ("lost" is the macro's own guess from
  the progress meter, so it can differ a little from the game).

## v2.5 — merge of the two forks
Merged "FischMacro" (standard-UI detector, live model fit, inversion probe, calibration) with "FischMacro2-full-loop-tuning" (controller seeding/hybrid fish filter, track guide lines, predicted-fish/telemetry overlay, box editor Close/Tools/back key, screen-off overlay dismissal, 5-minute auto-close). Features both had (anti-stuck recovery, probe, calibration exit) are kept once. Not run on a phone; Android classes were only syntax-checked.

### Stuck-at-wall rescue (2.5)
Model-free override in ReelController: if the bar has not moved for 0.5 s while a clearly visible fish is more than 0.8 bar widths on the other side, the controller forces a push toward it and holds that for 0.6 s; if the bar still does not move, the hold direction is flipped. Simulator results are unchanged by it (the simulator never produces this failure), so it is a safety net for a failure seen only on the phone.

### Steady follow (2.5, now the default)
The planner-based controller clicked too fast, let go early and did not follow the fish on the phone, because it relies on bar physics that the simulator only guesses. Steady follow works like this every frame:
1. It works out where the bar will be a moment from now (position + speed x look-ahead) and where the fish will be.
2. It calculates what would happen if the screen were held completely, and if it were let go completely, over the next ~0.4 s, and whether the fish would still be inside the bar.
3. Only a release keeps the fish in the bar -> let go. Only a hold does -> hold. Neither does -> hold if the fish is right of the bar, let go if it is left. Both do (the fish is in the middle) -> click quickly: each short cycle (default 200 ms) is split into hold and release time according to the error, the bar speed and a slowly learned balance point, so the bar hovers on the fish.
Sliders: shortest hold/release while far from the fish, middle zone size, length of one click cycle. Untick "Steady follow" for the old planner.
Simulator with 100 ms capture delay, 100 ms touch delay and position jitter (`-Dreal=true`), four different bar physics: standard UI 86–95%, Zanshin Zen 71–77% (the fish is hidden inside the dark bar), about 2.2–3.4 presses per second. Clean simulator: standard UI 72–97%, Zanshin 62–79%. Not measured on a phone.

### Zanshin Zen fish inside the bar (2.5)
The fish's pale blade is now also looked for inside the black bar (the kanji is learned as background, relative to the bar). Hidden-fish samples in the Zanshin test dropped from about 76% to about 39%. A far-away fish reading right after a good one must repeat three frames before it is believed. A Soul Judgement tap that has just been sent now counts the reel as caught if it ends before the tap is confirmed. In-bar % in the tests no longer counts the 2.5 s windows where inputs are cut on purpose.
Latest simulator run: 13 of 14 scenarios pass; standard UI 92–97%, Zanshin Zen 74–88%, Scylla-style (assumed) 82%. The one failing check is Zanshin full loop, fish kept in bar 79% against a target of 80%. Not run on a phone.
