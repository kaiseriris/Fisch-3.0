# Fisch Macro 2.0

Reads the screen (Android screen capture) and plays the FISCH reel minigame by pressing the screen through an accessibility service. It only reads pixels and sends touches.

## What it does
- Loop: Auto Cast -> wait for bite / Auto Shake -> Auto Reel -> catch/escape detection -> cooldown -> cast again, with watchdogs (stale frames, bite timeout, 90 s reel cap).
- Vision (pure Java, `Macro` / `ReelFinder` / `ReelTracker`): finds the control bar (size, position, resize), the fish marker, and the progress meter from the pixels; no fixed coordinates; confidence scores, automatic re-lock/recalibration.
- Black Fairy Rod (Zanshin Zen skin) is assumed. Soul Judgement: finds the big knife graphic, taps the centre target, accounts for the +55% progress and 4 s fish stun, never double-taps, verifies the jump.
- Predictive reel controller: learns bar acceleration/gravity/drag and input latency online, simulates hold vs release ahead, detects inputs that are not reaching the game and resets the touch.
- Floating panel (Start / Pause / Resume / Stop, Cast/Shake/Reel/Soul toggles, Manual override, Teach Shake, Recalibrate, Log) + settings and diagnostics in the app.
- Android 14 / Galaxy S24: mediaProjection foreground service started before `getMediaProjection`, callback registered before the VirtualDisplay, full-screen capture config, projection-stop handling, rotation resize, throttled frames.

## Reeling input
Each push on the reel is ONE committed touch (about 0.09-0.45 s) chosen by the look-ahead, with at least 0.08 s between touches, so it taps like a person (a few times a second) instead of flicking the screen on and off. The old continuous-hold mode is still there: untick "Reel with single-touch pulses" in the app.

## Casting
The cast is one continuous press of the length set by "Cast hold (ms)" (default 1000 ms, adjustable 300-3000 in the app). The app logs how long Android really held it (Log button). If the cast bar needs longer or shorter, change that slider.

## First run
1. Install, open the app. Samsung: App info > (three dots) > Allow restricted settings, and turn off Auto Blocker if it blocks the install.
2. Turn on Accessibility > Fisch Macro.
3. Tap Start screen capture, choose Entire screen.
4. Open Roblox > FISCH, press Start on the floating panel.
5. Shake: with nothing taught, the macro spots a new button-sized prompt that appears while waiting and taps it (no setup). For exact matching, bring a shake button up and press Teach Shake on the panel, then tap the button once.
6. The panel's status line shows what it is waiting for (seconds, shake taps, reel match %). If it sits at "reel match" 0% while the minigame is on screen, tap Log and send me the numbers.

Installing a new build over an old one: this version uses a fixed signing key, so future builds update in place. If Android says "App not installed" on the first update, uninstall the old Fisch Macro once (it was signed with a different key), then install.

If anything misbehaves: app screen > Copy diagnostics (includes the last crash).

## Build
GitHub Actions workflow `.github/workflows/build.yml`: upload this project (or `FischMacro.zip`) to the repo, run Actions > Build Fisch Macro APK. Local: `gradle :app:assembleDebug` (Gradle 8.9, JDK 17).

## Tests (desktop, no Android needed)
`tools/` holds a game simulator using the real Zanshin Zen art. See `tools/FullLoopTest.java`.

## 2.1: more settings, colour calibration, colour/adaptive detection

**Reel detection** (app screen > Detection): *Auto* looks for the Zanshin Zen shapes first and falls back to colours;
*Shapes only*; *Colours only*.

**Calibrate colors** (works for any rod): bring up a reel minigame, tick *Manual override* on the floating panel so the
macro does not press, press **Colors**, tap the middle of the control bar, then tap the fish. The phone reads both
colours and sizes from the captured screen and saves them. In colour mode there is no progress meter, so a reel that ran a
while and then disappeared is counted as caught.

**Adaptive colours** ("AI"): while sure of the bar, the stored colours drift slowly toward what is on screen, and the
fish search ignores things in the scene that have the fish's colour but never move. This is a running average and a
motion check running on the phone, not a neural network. If the fish is almost the same colour as the bar or the
background, fish tracking is weaker; the bar is still followed.

**Clicking too fast?** Raise *Shortest press* and *Shortest gap between presses* (defaults 180 ms / 150 ms, about 2 presses
per second in the simulator). Other new settings: longest press, give-up time for a reel and for a bite, shake
sensitivity and tap spacing, random extra cast hold, colour tolerance.

## Reeling: Follow mode (default)

Researched mechanics (Fisch wiki/guides): holding the screen moves the white control bar to the RIGHT, letting go lets it
fall to the LEFT; keeping the fish line inside the bar fills the progress meter, otherwise it drains. Rod stats change the
bar size (Control) and how twitchy the fish and the bar are (Resilience), so the macro learns the bar's response live.

Follow mode holds the screen down while the bar has to move right, and lets go while it has to move left, planning ahead
from the fish's speed and the bar's measured momentum and input delay. Unlike pulse mode it can hold continuously, so it
can climb against the bar's fall. *Follow mode: shortest hold/release* limits how fast it may switch (default 120 ms).
The floating panel status shows HOLD/release, where the fish is relative to the bar centre, and the share of time the
fish has been inside the bar. Pulse mode (single presses) is still available as a checkbox.

## Reel records
Each reel writes a summary line to the log (time, share of time the fish was in the bar, hold/release switches per second,
learned bar model, caught or lost). *Copy diagnostics* in the app also includes the samples of the last reel (time, bar
centre, fish position, hold, in-bar), so real-phone behaviour can be checked and tuned from real data.

## Check and Probe (calibration)
- **Check** (floating panel): draws a green box on the control bar and a red line on the fish as the vision sees them, with
  a readout (bar size, confidence). Works while the macro is stopped, so you can play a reel yourself and see whether
  detection is right. If it is wrong, use Recalibrate, change Reel detection, or Calibrate colors.
- **Probe** (floating panel): with a reel minigame on screen, the macro holds and releases the screen on a fixed schedule
  for about 5 seconds, watches how the bar moves, and fits the bar's response (speed up, fall back, drag, input delay). The
  result is saved and used from the start of every reel, so the first seconds of each reel are no longer a guess. In the
  simulator the fit lands within about 10% of the true values. *Clear saved bar measurement* in the app removes it.

## View (live picture of what the macro sees)
**View** on the floating panel opens a small live copy of the captured screen in the top-right corner, with the control bar
(green box), fish (red line), progress meter (blue box), shake button (yellow circle) and Soul Judgement target (pink circle)
drawn on it, plus the confidence of each detection, the stage, and which method (shape or colour) found the reel. It works
while the macro runs or is stopped. Press View again to close it.

## Boxes (stretch-to-fit calibration)
**Boxes** on the floating panel freezes one picture of the game (have the reel minigame on screen) and shows it full screen
with a green box for the control bar and a red box for the fish. Drag a box to move it, drag a corner to stretch it, and press
Save. The bar's colour, width and height, its height on screen, and the fish's colour and size are learned from the boxes
(colours are taken from what is typical inside the box compared with just outside it, so a loose box still works). "No fish
box" skips the fish. It feeds the colour detector, so set *Reel detection* to Auto or Colours only. The older **Colors**
(two taps) button is still there.

Boxes now has four boxes: BAR (green), FISH (red), TRACK (yellow: the whole line the bar can travel on, so the macro knows
how far left and right the bar can go) and METER (blue: the progress bar; its filled colour is learned and progress is then
read from it, so colour mode knows when a fish is nearly caught). FISH, TRACK and METER each have an on/off switch. Take the
picture while the meter is partly filled.

## Measured bar response
*Probe* measures how the bar answers holds and releases and stores the result as the starting point for live learning (the
macro still keeps adapting while reeling). There is also an experimental option that refits the response after each reel and
keeps it fixed. I tested it: with a perfectly known fixed model the controller alone reached about 96%, but in the full
simulated loop (screen capture delay, hidden fish, noise) a fixed model was not better than live learning (66-72% against
77%), and the automatic refit was worse (40%). So it is off by default. The fish is dark like the bar in the Zanshin Zen
skin, so it cannot be seen while inside the bar; that is what limits accuracy there (about 75-80% in the simulator). A fish
icon that is visible inside the bar (colour mode with a fish colour that differs from the bar) would remove that limit,
but this has not been tested on a real phone.

## Safety and session settings
- **Only run while Roblox is in front** (on by default): the accessibility service watches which app is in front. If Roblox
  is left (home, recents, another app) the macro pauses itself and resumes when Roblox is back, so taps never land in another
  app. Start refuses to run while another app is known to be in front.
- **Stop after N catches / N minutes**: the macro finishes the current fish and stops, and says why.
- **No-bite alert**: after N casts in a row with no bite (default 6) it stops and says so, since that usually means no rod is
  equipped or you are not at water.
- **Keep screen on** while the panel is showing.
- **Volume-down toggle** (off by default): start / stop without touching the panel. The volume key then no longer changes volume.
- **Session line** on the panel and in the app: caught, lost, per hour, running time ("lost" is the macro's own guess from
  the progress meter, so it can differ a little from the game).
