package com.fischmacro;

import android.accessibilityservice.AccessibilityService;
import android.graphics.Color;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Accessibility service: presses the screen for the macro and shows the floating control panel
 * (Start / Pause / Resume / Stop, toggles, manual override, calibration helpers, live status).
 */
public class MacroService extends AccessibilityService {
    private HoldInjector injector;
    private WindowManager wm;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private LinearLayout panel, body;
    private TextView status, diag;
    private WindowManager.LayoutParams panelLp;
    private View teachOverlay, calibOverlay, checkOverlay, previewOverlay, boxOverlay;
    private boolean expanded = true, showDiag;
    private final BroadcastReceiver screenSafety = new BroadcastReceiver() {
        @Override public void onReceive(android.content.Context context, Intent intent) {
            if (Intent.ACTION_SCREEN_OFF.equals(intent.getAction())) dismissTransientOverlays();
        }
    };
    private boolean screenReceiverRegistered;

    HoldInjector injector() {
        return injector;
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        injector = new HoldInjector(this);
        Shared.macro = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        try {
            registerReceiver(screenSafety, new IntentFilter(Intent.ACTION_SCREEN_OFF));
            screenReceiverRegistered = true;
        } catch (RuntimeException ignored) {}
        try {
            buildPanel();
        } catch (RuntimeException e) {
            Shared.diag.event("Panel failed: " + e);
        }
        ui.post(refresh);
    }

    private volatile boolean robloxFront = true;

    /** Tracks which app is in front. With "only run while Roblox is in front" the macro pauses itself when it is not. */
    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;
        CharSequence p = event.getPackageName();
        if (p == null) return;
        String pkg = p.toString();
        // our own panels, the status bar / shade and the keyboard do not count as leaving the game
        if (pkg.equals(getPackageName()) || pkg.equals("com.android.systemui") || pkg.contains("inputmethod") || pkg.contains("keyboard")) return;
        robloxFront = pkg.startsWith("com.roblox");
        gateByForeground();
    }

    private void gateByForeground() {
        final CaptureService cs = Shared.capture;
        if (cs == null) return;
        final boolean front = robloxFront || !Shared.cfg.onlyInRoblox;
        cs.post(() -> {
            Macro m = cs.macro();
            if (m == null) return;
            if (!front && m.isRunning() && !m.isPaused()) m.autoPause(System.nanoTime());
            else if (front && m.autoPaused) m.autoResume(System.nanoTime());
        });
    }

    /** Optional: volume-down starts or stops the macro. */
    @Override
    protected boolean onKeyEvent(android.view.KeyEvent ev) {
        if (!Shared.cfg.volumeKey || ev.getKeyCode() != android.view.KeyEvent.KEYCODE_VOLUME_DOWN) return false;
        if (ev.getAction() == android.view.KeyEvent.ACTION_DOWN && ev.getRepeatCount() == 0) {
            withMacro(m -> { if (m.isRunning()) m.stop(); else m.start(System.nanoTime()); });
        }
        return true;
    }

    @Override
    public void onInterrupt() {
        if (injector != null) injector.reset();
    }

    @Override
    public boolean onUnbind(android.content.Intent intent) {
        teardown();
        return super.onUnbind(intent);
    }

    @Override
    public void onDestroy() {
        teardown();
        super.onDestroy();
    }

    private void teardown() {
        ui.removeCallbacksAndMessages(null);
        if (screenReceiverRegistered) {
            try { unregisterReceiver(screenSafety); } catch (RuntimeException ignored) {}
            screenReceiverRegistered = false;
        }
        if (Shared.macro == this) Shared.macro = null;
        try { if (panel != null) wm.removeView(panel); } catch (RuntimeException ignored) {}
        try { if (teachOverlay != null) wm.removeView(teachOverlay); } catch (RuntimeException ignored) {}
        try { if (calibOverlay != null) wm.removeView(calibOverlay); } catch (RuntimeException ignored) {}
        calibOverlay = null;
        try { if (checkOverlay != null) wm.removeView(checkOverlay); } catch (RuntimeException ignored) {}
        checkOverlay = null;
        try { if (previewOverlay != null) wm.removeView(previewOverlay); } catch (RuntimeException ignored) {}
        previewOverlay = null;
        try { if (boxOverlay != null) wm.removeView(boxOverlay); } catch (RuntimeException ignored) {}
        boxOverlay = null;
        panel = null;
        teachOverlay = null;
    }

    /** Remove full-screen touch layers immediately when the device locks. */
    private void dismissTransientOverlays() {
        if (wm == null) return;
        try { if (boxOverlay != null) wm.removeView(boxOverlay); } catch (RuntimeException ignored) {}
        boxOverlay = null;
        try { if (calibOverlay != null) wm.removeView(calibOverlay); } catch (RuntimeException ignored) {}
        calibOverlay = null;
        try { if (teachOverlay != null) wm.removeView(teachOverlay); } catch (RuntimeException ignored) {}
        teachOverlay = null;
        Shared.note = "Calibration dismissed because the screen was locked.";
    }

    // ---- panel -------------------------------------------------------------------------------

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t);
        b.setAllCaps(false);
        b.setTextSize(12);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(8), dp(4), dp(8), dp(4));
        b.setOnClickListener(l);
        return b;
    }

    private CheckBox check(String t, boolean v, java.util.function.Consumer<Boolean> c) {
        CheckBox cb = new CheckBox(this);
        cb.setText(t);
        cb.setTextColor(Color.WHITE);
        cb.setTextSize(12);
        cb.setChecked(v);
        cb.setOnCheckedChangeListener((x, on) -> {
            c.accept(on);
            Prefs.save(this, Shared.cfg);
        });
        return cb;
    }

    private void withMacro(java.util.function.Consumer<Macro> c) {
        final CaptureService cs = Shared.capture;
        if (cs == null || cs.macro() == null) {
            Shared.note = "Start screen capture in the app first.";
            return;
        }
        cs.post(() -> c.accept(cs.macro()));
    }

    private void buildPanel() {
        final Config k = Shared.cfg;
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(Color.argb(215, 20, 20, 24));
        bg.setCornerRadius(dp(10));
        panel.setBackground(bg);
        panel.setPadding(dp(8), dp(6), dp(8), dp(6));

        // header: drag handle + collapse
        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        status = new TextView(this);
        status.setTextColor(Color.WHITE);
        status.setTextSize(12);
        status.setText("Fisch Macro");
        head.addView(status, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        Button toggle = btn("_", v -> {
            expanded = !expanded;
            body.setVisibility(expanded ? View.VISIBLE : View.GONE);
        });
        head.addView(toggle);
        panel.addView(head);

        body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        panel.addView(body);

        LinearLayout row1 = new LinearLayout(this);
        row1.addView(btn("Start", v -> {
            if (k.onlyInRoblox && !robloxFront) {
                Shared.note = "Open Roblox first (the macro only runs while Roblox is in front; change this in the app).";
                return;
            }
            withMacro(m -> m.start(System.nanoTime()));
        }));
        row1.addView(btn("Pause", v -> withMacro(Macro::pause)));
        row1.addView(btn("Resume", v -> withMacro(m -> m.resume(System.nanoTime()))));
        row1.addView(btn("Stop", v -> withMacro(Macro::stop)));
        body.addView(row1);

        body.addView(check("Auto Cast", k.autoCast, b -> k.autoCast = b));
        body.addView(check("Auto Shake", k.autoShake, b -> k.autoShake = b));
        body.addView(check("Auto Reel", k.autoReel, b -> k.autoReel = b));
        body.addView(check("Soul Judgement", k.soulJudgement, b -> k.soulJudgement = b));
        CheckBox man = new CheckBox(this);
        man.setText("Manual override (you play)");
        man.setTextColor(Color.WHITE);
        man.setTextSize(12);
        man.setOnCheckedChangeListener((x, on) -> withMacro(m -> m.setManual(on)));
        body.addView(man);

        LinearLayout row2 = new LinearLayout(this);
        row2.addView(btn("Teach Shake", v -> startTeach()));
        row2.addView(btn("Recalibrate", v -> withMacro(Macro::recalibrate)));
        row2.addView(btn("Colors", v -> startCalibrate(0)));
        row2.addView(btn("Boxes", v -> startBoxes()));
        row2.addView(btn("Log", v -> {
            showDiag = !showDiag;
            diag.setVisibility(showDiag ? View.VISIBLE : View.GONE);
        }));
        body.addView(row2);
        LinearLayout row3 = new LinearLayout(this);
        row3.addView(btn("Check", v -> toggleCheck()));
        row3.addView(btn("View", v -> togglePreview()));
        row3.addView(btn("Probe", v -> {
            if (Shared.capture == null) { Shared.note = "Start screen capture in the app first."; return; }
            Shared.note = "Probe: keep the reel minigame on screen; the macro will hold and release for about 5 seconds.";
            withMacro(Macro::startProbe);
        }));
        body.addView(row3);

        diag = new TextView(this);
        diag.setTextColor(Color.rgb(190, 230, 190));
        diag.setTextSize(10);
        diag.setTypeface(android.graphics.Typeface.MONOSPACE);
        diag.setVisibility(View.GONE);
        body.addView(diag);

        panelLp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = dp(6);
        panelLp.y = dp(6);

        // drag by the header text
        head.setOnTouchListener(new View.OnTouchListener() {
            float sx, sy;
            int ox, oy;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        sx = e.getRawX();
                        sy = e.getRawY();
                        ox = panelLp.x;
                        oy = panelLp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = ox + (int) (e.getRawX() - sx);
                        panelLp.y = oy + (int) (e.getRawY() - sy);
                        try { wm.updateViewLayout(panel, panelLp); } catch (RuntimeException ignored) {}
                        return true;
                    default:
                        return false;
                }
            }
        });
        wm.addView(panel, panelLp);
    }

    /** Puts an invisible full-screen layer up for one touch; that touch marks the shake button to learn. */
    private void startTeach() {
        if (Shared.capture == null) {
            Shared.note = "Start screen capture in the app first.";
            return;
        }
        if (teachOverlay != null) return;
        View v = new View(this);
        v.setBackgroundColor(Color.argb(60, 255, 255, 0));
        v.setOnTouchListener((view, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                int[] loc = new int[2];
                view.getLocationOnScreen(loc);
                float fx = (e.getRawX()) / view.getWidth();
                float fy = (e.getRawY() - loc[1]) / view.getHeight();
                CaptureService cs = Shared.capture;
                if (cs != null) cs.teach(fx, fy);
                ui.post(() -> {
                    try { wm.removeView(teachOverlay); } catch (RuntimeException ignored) {}
                    teachOverlay = null;
                });
                return true;
            }
            return true;
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        teachOverlay = v;
        wm.addView(v, lp);
        Shared.note = "Tap the SHAKE button now (bring one up in the game first).";
        // safety: remove the layer after 20 s if untouched
        ui.postDelayed(() -> {
            if (teachOverlay == v) {
                try { wm.removeView(v); } catch (RuntimeException ignored) {}
                teachOverlay = null;
            }
        }, 20000);
    }

    /**
     * Colour calibration: a transparent layer over the screen takes two taps while the reel minigame is up,
     * first on the control bar, then on the fish. Each tap is read from the captured picture, not from guesses.
     */
    private void startCalibrate(int step) {
        if (Shared.capture == null) {
            Shared.note = "Start screen capture in the app first.";
            return;
        }
        if (calibOverlay != null) {
            try { wm.removeView(calibOverlay); } catch (RuntimeException ignored) {}
            calibOverlay = null;
        }
        View v = new View(this);
        v.setBackgroundColor(step == 0 ? Color.argb(50, 0, 160, 255) : Color.argb(50, 255, 120, 0));
        v.setOnTouchListener((view, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                int[] loc = new int[2];
                view.getLocationOnScreen(loc);
                float fx = e.getRawX() / view.getWidth();
                float fy = (e.getRawY() - loc[1]) / view.getHeight();
                CaptureService cs = Shared.capture;
                if (cs != null) cs.calibrate(fx, fy, step);
                ui.post(() -> {
                    try { wm.removeView(calibOverlay); } catch (RuntimeException ignored) {}
                    calibOverlay = null;
                    if (step == 0) {
                        // let the captured frame be read, then ask for the fish (the reel keeps playing underneath)
                        ui.postDelayed(() -> startCalibrate(1), 400);
                    }
                });
            }
            return true;
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        calibOverlay = v;
        wm.addView(v, lp);
        Shared.note = step == 0
                ? "Colors 1/2: with the reel minigame on screen, tap the middle of the CONTROL BAR (the part you move). Tip: tick Manual override first so the macro does not press."
                : "Colors 2/2: tap the middle of the FISH icon. (If the minigame ended, run Colors again during the next one.)";
        ui.postDelayed(() -> {
            if (calibOverlay == v) {
                try { wm.removeView(v); } catch (RuntimeException ignored) {}
                calibOverlay = null;
            }
        }, 25000);
    }

    /**
     * Boxes calibration: freezes one picture of the game (have the reel minigame on screen), shows it full screen with a bar
     * box and a fish box to stretch into place, and learns the colours and sizes from them.
     */
    private void startBoxes() {
        final CaptureService cs = Shared.capture;
        if (cs == null || cs.macro() == null) {
            Shared.note = "Start screen capture in the app first.";
            return;
        }
        if (boxOverlay != null) return;
        final Macro m = cs.macro();
        m.snap = null;
        cs.post(() -> m.snapRequest = true);
        Shared.note = "Boxes: taking a picture of the game...";
        final long t0 = System.currentTimeMillis();
        ui.post(new Runnable() {
            @Override
            public void run() {
                ArrayFrame snap = m.snap;
                if (snap == null) {
                    if (System.currentTimeMillis() - t0 > 4000) { Shared.note = "Boxes: no picture arrived. Is screen capture running?"; return; }
                    ui.postDelayed(this, 100);
                    return;
                }
                showBoxes(snap);
            }
        });
    }

    private void showBoxes(ArrayFrame snap) {
        double[] bar = {0.30, 0.62, 0.70, 0.67}, fish = {0.47, 0.50, 0.53, 0.58};
        double[] track = {0.20, 0.625, 0.80, 0.665}, meter = {0.32, 0.69, 0.68, 0.70};
        double[] v = Shared.diag.vis; // start from what the macro currently sees, if anything
        if (v != null && v[5] > 0) {
            bar = new double[] {v[0] / v[5], v[1] / v[6], (v[2] + 1) / v[5], (v[3] + 1) / v[6]};
            double bh = bar[3] - bar[1];
            double fx = v[4] >= 0 ? v[4] / v[5] : (bar[0] + bar[2]) / 2;
            fish = new double[] {fx - 0.02, bar[1] - bh * 1.6, fx + 0.02, bar[1] - bh * 0.3};
            double bw = bar[2] - bar[0], cx = (bar[0] + bar[2]) / 2;
            track = new double[] {cx - bw * 1.25, bar[1], cx + bw * 1.25, bar[3]};
            meter = v.length >= 14 && v[10] >= 0
                    ? new double[] {v[10] / v[5], v[11] / v[6], (v[12] + 1) / v[5], (v[13] + 1) / v[6]}
                    : new double[] {cx - bw * 0.6, bar[3] + bh * 0.3, cx + bw * 0.6, bar[3] + bh * 0.5};
        }
        BoxEditor ed = new BoxEditor(this, snap, new double[][] {bar, fish, track, meter}, (b, f, t, m) -> {
            ui.post(() -> {
                try { if (boxOverlay != null) wm.removeView(boxOverlay); } catch (RuntimeException ignored) {}
                boxOverlay = null;
            });
            CaptureService cs = Shared.capture;
            if (b != null && cs != null) cs.calibrateBoxes(b, f, t, m);
            else Shared.note = "Boxes cancelled.";
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        boxOverlay = ed;
        wm.addView(ed, lp);
        ed.requestFocus();
        // Safety timeout: if the editor is accidentally left open, remove it automatically.
        ui.postDelayed(() -> {
            if (boxOverlay == ed) {
                try { wm.removeView(ed); } catch (RuntimeException ignored) {}
                boxOverlay = null;
                Shared.note = "Calibration closed automatically for safety.";
            }
        }, 5 * 60 * 1000L);
        Shared.note = "Boxes: stretch the green box over the bar and the red box over the fish, then Save.";
    }

    /** Toggles the small live picture of what the macro sees, with the detections drawn on it. */
    private void togglePreview() {
        if (previewOverlay != null) {
            try { wm.removeView(previewOverlay); } catch (RuntimeException ignored) {}
            previewOverlay = null;
            withMacro(m -> m.liveView = false);
            return;
        }
        if (Shared.capture == null) {
            Shared.note = "Start screen capture in the app first.";
            return;
        }
        PreviewView v = new PreviewView(this);
        int w = Math.min(dp(300), getResources().getDisplayMetrics().widthPixels * 3 / 5);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                w, WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.END;
        // height follows the screen's shape: the picture plus five text lines
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        lp.height = (int) (w * (double) dm.heightPixels / dm.widthPixels) + dp(160);
        previewOverlay = v;
        wm.addView(v, lp);
        withMacro(m -> m.liveView = true);
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (previewOverlay != v) return;
                v.invalidate();
                ui.postDelayed(this, 200);
            }
        });
    }

    /** Toggles the overlay that outlines the bar and fish as the vision sees them. */
    private void toggleCheck() {
        if (checkOverlay != null) {
            try { wm.removeView(checkOverlay); } catch (RuntimeException ignored) {}
            checkOverlay = null;
            withMacro(m -> m.checkMode = false);
            return;
        }
        if (Shared.capture == null) {
            Shared.note = "Start screen capture in the app first.";
            return;
        }
        VisView v = new VisView(this);
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        checkOverlay = v;
        wm.addView(v, lp);
        withMacro(m -> m.checkMode = true);
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (checkOverlay != v) return;
                v.invalidate();
                ui.postDelayed(this, 100);
            }
        });
    }

    private final Runnable refresh = new Runnable() {
        @Override
        public void run() {
            if (panel == null) return;
            Diag d = Shared.diag;
            CaptureService cs = Shared.capture;
            String s;
            if (cs == null) {
                s = "Fisch Macro: no capture";
            } else {
                Macro m = cs.macro();
                s = "Fisch: " + (m != null && m.isRunning() ? (m.isPaused() ? "paused" : d.stage) : "stopped");
                if (d.progress >= 0) s += "  " + Math.round(d.progress * 100) + "%";
                if (m != null && m.isRunning() && !d.stats.isEmpty()) s += "\n" + d.stats;
                if (!d.detail.isEmpty()) s += "\n" + d.detail;
            }
            status.setText(s);
            // keep-awake follows the setting
            if (panelLp != null) {
                boolean want = Shared.cfg.keepAwake;
                boolean has = (panelLp.flags & WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) != 0;
                if (want != has) {
                    if (want) panelLp.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                    else panelLp.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
                    try { wm.updateViewLayout(panel, panelLp); } catch (RuntimeException ignored) {}
                }
            }
            if (showDiag) diag.setText(Shared.note + "\n" + d.summary() + "\n" + d.eventLog(6));
            ui.postDelayed(this, 400);
        }
    };
}
