package com.fischmacro;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.KeyEvent;
import android.view.View;

/**
 * Calibration on a frozen picture of the game: a green box for the control bar and a red box for the fish. Drag a box to
 * move it, drag one of its corners to stretch it, then press Save. The macro learns the colours and sizes from the boxes.
 */
final class BoxEditor extends View {
    interface Done { void done(double[] bar, double[] fish, double[] track, double[] meter); }

    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG), fill = new Paint(), txt = new Paint(Paint.ANTI_ALIAS_FLAG), dim = new Paint();
    private final Bitmap bmp;
    private static final String[] NAME = {"BAR", "FISH", "TRACK", "METER"};
    private static final int[] COL = {Color.rgb(60, 255, 90), Color.rgb(255, 70, 70), Color.rgb(255, 210, 40), Color.rgb(80, 160, 255)};
    private final RectF[] box = new RectF[4]; // bar, fish, track (whole minigame), progress meter (pixels of this view)
    private final boolean[] on = {true, true, true, true};
    private final RectF[] toggle = new RectF[4];
    private final Done done;
    private final float handle;
    private RectF save, cancel, toolsButton, closeButton;
    private boolean toolsOpen = false;
    private int drag = -1, corner = -1; // which box, and which corner (0..3) or -1 for moving
    private float lx, ly;

    BoxEditor(Context c, ArrayFrame snap, double[][] fr, Done done) {
        super(c);
        this.done = done;
        handle = 28 * c.getResources().getDisplayMetrics().density;
        bmp = Bitmap.createBitmap(snap.w, snap.h, Bitmap.Config.ARGB_8888);
        int[] px = new int[snap.px.length];
        for (int i = 0; i < px.length; i++) px[i] = 0xFF000000 | snap.px[i];
        bmp.setPixels(px, 0, snap.w, 0, 0, snap.w, snap.h);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(4);
        fill.setStyle(Paint.Style.FILL);
        txt.setColor(Color.WHITE);
        txt.setTextSize(15 * c.getResources().getDisplayMetrics().scaledDensity);
        txt.setTextAlign(Paint.Align.CENTER);
        dim.setColor(Color.argb(60, 0, 0, 0));
        for (int i = 0; i < 4; i++) box[i] = new RectF((float) fr[i][0], (float) fr[i][1], (float) fr[i][2], (float) fr[i][3]);
        fracs = true;
        setFocusable(true);
        setFocusableInTouchMode(true);
    }

    private boolean fracs;

    private void toPixels() {
        if (!fracs || getWidth() == 0) return;
        for (RectF r : box) { r.left *= getWidth(); r.right *= getWidth(); r.top *= getHeight(); r.bottom *= getHeight(); }
        fracs = false;
    }

    @Override
    protected void onDraw(Canvas cv) {
        toPixels();
        int w = getWidth(), h = getHeight();
        cv.drawBitmap(bmp, null, new RectF(0, 0, w, h), null);
        cv.drawRect(0, 0, w, h, dim);
        for (int i = 0; i < 4; i++) {
            if (!on[i]) continue;
            int col = COL[i];
            line.setColor(col);
            fill.setColor(Color.argb(40, Color.red(col), Color.green(col), Color.blue(col)));
            RectF r = box[i];
            cv.drawRect(r, fill);
            cv.drawRect(r, line);
            fill.setColor(col);
            float s = handle / 3;
            cv.drawCircle(r.left, r.top, s, fill);
            cv.drawCircle(r.right, r.top, s, fill);
            cv.drawCircle(r.left, r.bottom, s, fill);
            cv.drawCircle(r.right, r.bottom, s, fill);
            txt.setColor(col);
            cv.drawText(NAME[i], r.centerX(), Math.max(handle * 3, r.top - 10), txt);
        }
        // Keep the emergency exit permanently visible; calibration must never trap the user.
        float bh = handle * 1.35f, margin = handle * .35f;
        float cw = handle * 2.2f, tw = handle * 3.1f;
        closeButton = button(cv, w - margin - cw, margin, cw, bh, "Close ✕", Color.rgb(155, 42, 48));
        toolsButton = button(cv, w - margin - cw - tw - margin, margin, tw, bh,
                toolsOpen ? "Hide tools" : "Tools ⚙", Color.rgb(35, 75, 105));
        if (toolsOpen) {
            float panelW = Math.min(w - margin * 2, handle * 11.5f);
            float panelH = handle * 4.4f;
            float left = Math.max(margin, w - margin - panelW);
            float top = margin + bh + margin * .5f;
            fill.setColor(Color.argb(235, 22, 29, 38));
            cv.drawRoundRect(new RectF(left, top, left + panelW, top + panelH), 18, 18, fill);
            float gap = handle * .18f, itemW = (panelW - gap * 5) / 4f;
            float itemH = handle * 1.15f;
            for (int i = 0; i < 4; i++) {
                toggle[i] = button(cv, left + gap + i * (itemW + gap), top + gap,
                        itemW, itemH, NAME[i] + (on[i] ? " ✓" : " —"),
                        on[i] ? Color.rgb(37, 105, 76) : Color.rgb(65, 69, 78));
            }
            float actionY = top + gap * 2 + itemH;
            float actionW = (panelW - gap * 3) / 2f;
            save = button(cv, left + gap, actionY, actionW, itemH, "Save", Color.rgb(35, 145, 75));
            cancel = button(cv, left + gap * 2 + actionW, actionY, actionW, itemH, "Cancel", Color.rgb(155, 50, 55));
        } else {
            save = cancel = null;
            for (int i = 0; i < 4; i++) toggle[i] = null;
        }
        txt.setColor(Color.WHITE);
        txt.setTextAlign(Paint.Align.LEFT);
        cv.drawText("Drag a box to move it • Drag a corner to resize", margin, h - margin, txt);
        txt.setTextAlign(Paint.Align.CENTER);
    }

    private RectF button(Canvas cv, float x, float y, float w, float h, String t, int col) {
        RectF r = new RectF(x, y, x + w, y + h);
        fill.setColor(col);
        cv.drawRoundRect(r, 14, 14, fill);
        txt.setColor(Color.WHITE);
        cv.drawText(t, r.centerX(), r.centerY() + txt.getTextSize() / 3, txt);
        return r;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX(), y = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (closeButton != null && closeButton.contains(x, y)) { finish(false); return true; }
                if (toolsButton != null && toolsButton.contains(x, y)) { toolsOpen = !toolsOpen; invalidate(); return true; }
                if (toolsOpen && save != null && save.contains(x, y)) { finish(true); return true; }
                if (toolsOpen && cancel != null && cancel.contains(x, y)) { finish(false); return true; }
                if (toolsOpen) for (int i = 0; i < 4; i++) if (toggle[i] != null && toggle[i].contains(x, y)) { on[i] = !on[i]; invalidate(); return true; }
                drag = -1;
                corner = -1;
                double bestD = handle * 1.6;
                for (int i = 0; i < 4; i++) {
                    if (!on[i]) continue;
                    float[][] cs = corners(box[i]);
                    for (int k = 0; k < 4; k++) {
                        double d = Math.hypot(x - cs[k][0], y - cs[k][1]);
                        if (d < bestD) { bestD = d; drag = i; corner = k; }
                    }
                }
                if (drag < 0) {
                    for (int i = 3; i >= 0; i--) if (on[i] && box[i].contains(x, y)) { drag = i; break; }
                }
                lx = x;
                ly = y;
                return true;
            case MotionEvent.ACTION_MOVE:
                if (drag >= 0) {
                    RectF r = box[drag];
                    float dx = x - lx, dy = y - ly;
                    if (corner < 0) r.offset(dx, dy);
                    else {
                        if (corner == 0 || corner == 2) r.left += dx; else r.right += dx;
                        if (corner == 0 || corner == 1) r.top += dy; else r.bottom += dy;
                    }
                    lx = x;
                    ly = y;
                    invalidate();
                }
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                drag = -1;
                return true;
            default:
                return true;
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_BACK && event.getAction() == KeyEvent.ACTION_UP) {
            finish(false);
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    private static float[][] corners(RectF r) {
        return new float[][] {{r.left, r.top}, {r.right, r.top}, {r.left, r.bottom}, {r.right, r.bottom}};
    }

    private double[] frac(RectF r) {
        float w = getWidth(), h = getHeight();
        return new double[] {Math.min(r.left, r.right) / w, Math.min(r.top, r.bottom) / h, Math.max(r.left, r.right) / w, Math.max(r.top, r.bottom) / h};
    }

    private void finish(boolean ok) {
        if (ok) done.done(frac(box[0]), on[1] ? frac(box[1]) : null, on[2] ? frac(box[2]) : null, on[3] ? frac(box[3]) : null);
        else done.done(null, null, null, null);
    }
}
