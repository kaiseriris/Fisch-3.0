package com.fischmacro;

/**
 * The whole fishing loop: cast -> wait for bite (shake) -> reel -> catch/escape -> cooldown -> cast.
 * Pure Java. The Android layer feeds it frames and a ticking clock, and gives it an Input to press with.
 * All calls must come from one thread.
 */
public final class Macro {

    public interface Input {
        /** Press (true) or lift (false) the finger at the configured hold point. */
        void hold(boolean down);
        /** One quick tap at a screen fraction. Any hold is released first by the caller. */
        void tap(float fx, float fy);
        /** Drop and re-establish the touch (used when presses are not reaching the game). */
        void resetInput();
        /** True once Android has confirmed that the latest press reached the screen. */
        default boolean pressAccepted() { return true; }
        /** One committed touch of this length (used for reel pushes in pulse mode). */
        void pulse(int ms);
        /** Press and hold for exactly this many ms as ONE continuous touch (used to charge a cast). */
        void pressFor(int ms);
        /** 0 = pressing or not started, 1 = finished and confirmed, -1 = refused or cancelled. */
        int pressState();
        /** How long the last timed press really lasted. */
        long pressMeasuredMs();
    }

    public enum Stage { IDLE, CAST, WAIT_BITE, REEL, COOLDOWN }

    public final Config cfg;
    public final Diag diag;
    public final ReelFinder finder = new ReelFinder();
    public final ReelTracker tracker = new ReelTracker();
    /** Colour-based reel tracker, used when the shape finder is off, fails, or the rod looks different. */
    public final ColorReel colorReel = new ColorReel();
    private boolean useColor;
    /** Which method found the current reel ("shape" / "color"), for the status line. */
    private String viaWhat = "";
    public final ReelController ctl = new ReelController();
    public final SoulJudgement sj = new SoulJudgement();
    public final ShakeFinder shake = new ShakeFinder();
    public final ShakeWatcher watcher = new ShakeWatcher();
    private int castFails, autoTaps;

    private final Input in;
    private final ReelTracker.Measure meas = new ReelTracker.Measure();

    private volatile boolean running, paused, manual;
    private volatile Stage stage = Stage.IDLE;
    private long lastSoulMs = -100000, lastHighMs = -100000, stageStartMs, lastFrameMs, lastSearchMs, lastShakeMs, lastSjMs, lastGoodMs, lastStaleMs, castAtMs;
    private boolean castHeld;
    private double inBarEma = 0.5;
    // bar-response measurement from the reel itself (positions and the hold/release commands that were sent)
    private final java.util.ArrayList<double[]> mdS = new java.util.ArrayList<>(), mdC = new java.util.ArrayList<>();
    private final java.util.ArrayList<double[]> fits = new java.util.ArrayList<>();
    private boolean mdHold;
    /** True once the bar's response has been measured (by Probe or from reels) and is being kept fixed. */
    public volatile boolean modelFrozen;
    private int badReels;
    // per-reel record so real-phone behaviour can be inspected and tuned: time, bar centre, fish x, hold, in-bar (px)
    private final StringBuilder trace = new StringBuilder();
    private int trN, trIn, trFish, trFlips;
    private boolean trLastHold;
    /** Summary and samples of the most recent reel, for "Copy diagnostics". */
    public volatile String lastReelTrace = "";
    private int castAskMs;
    private long reelStartMs;
    private final java.util.Random rnd = new java.util.Random();
    private double progress = -1, maxProgress;
    private int doneStreak, lowConf;

    // Soul Judgement activation: 0 idle, 1 released and waiting to tap, 2 tapped and verifying
    private int sjPhase, sjTries, sjMissing;
    private long sjAtMs, stunUntilMs;
    private float sjFx, sjFy;
    private double sjPre;

    public Macro(Config cfg, Diag diag, Input in) {
        this.cfg = cfg;
        this.diag = diag;
        this.in = in;
    }

    private ReelTracker trk() {
        return useColor ? colorReel : tracker;
    }

    /** Find the reel UI by the method(s) the user chose. Sets useColor for the tracker to use. */
    private ReelUi findReel(Frame f, double tol) {
        colorReel.tolerance = cfg.colorTolerance;
        colorReel.adaptive = cfg.adaptiveColors;
        int mode = cfg.detectMode;
        ReelUi ui = null;
        if (mode != 2) {
            ui = finder.search(f, tol);
            if (ui != null) { pendingColor = false; return ui; }
            diag.reelConf = finder.lastBest;
        }
        if (mode != 1 && colorReel.profile.ready()) {
            ui = colorReel.search(f);
            if (ui != null) { pendingColor = true; return ui; }
            diag.reelConf = Math.max(diag.reelConf, colorReel.lastBest * 0.6);
        }
        return null;
    }
    private boolean pendingColor;

    // ---- controls ------------------------------------------------------------------------------

    // ---- session stats, auto-stop, no-bite alert, external pause (Roblox not in front) ----
    private long sessionStartMs, pausedSinceMs, pausedTotalMs;
    private int baseCatches, baseEscapes, noBites;
    /** Set when the macro paused itself because Roblox left the front; cleared when it resumes itself. */
    public volatile boolean autoPaused;
    /** Why the macro stopped itself, if it did. */
    public volatile String stopReason = "";

    private void updateStats(long now) {
        long run = Math.max(1, now - sessionStartMs - pausedTotalMs - (paused ? now - pausedSinceMs : 0));
        int c = diag.catches - baseCatches, l = diag.escapes - baseEscapes;
        double perHour = c * 3_600_000.0 / run;
        long s = run / 1000;
        diag.stats = String.format("Caught %d, lost %d, %.0f/h, %d:%02d:%02d", c, l, perHour, s / 3600, (s / 60) % 60, s % 60);
    }

    /** Pause because Roblox is not in front; resumes by itself when it is back. */
    public void autoPause(long nowNs) {
        if (!running || paused) return;
        autoPaused = true;
        pause();
        diag.event("Paused: Roblox is not in front");
        diag.stage = "Roblox not in front";
    }

    public void autoResume(long nowNs) {
        if (!autoPaused) return;
        autoPaused = false;
        resume(nowNs);
    }

    public void start(long nowNs) {
        long now = nowNs / 1_000_000L;
        sessionStartMs = now;
        pausedTotalMs = 0;
        baseCatches = diag.catches;
        baseEscapes = diag.escapes;
        noBites = 0;
        autoPaused = false;
        stopReason = "";
        running = true;
        paused = false;
        lastFrameMs = now;
        tracker.unlock();
        colorReel.unlock();
        probeActive = false;
        diag.event("Start");
        enter(cfg.autoCast ? Stage.CAST : Stage.WAIT_BITE, now);
    }

    private void stopSelf(String why) {
        stopReason = why;
        diag.event("Stopped by itself: " + why);
        Shared_note(why);
        stop();
    }

    /** Hook so the Android layer can show the reason (kept out of the pure-Java core). */
    public volatile java.util.function.Consumer<String> onNote;
    private void Shared_note(String s) {
        java.util.function.Consumer<String> c = onNote;
        if (c != null) c.accept(s);
    }

    public void pause() {
        if (!running) return;
        paused = true;
        pausedSinceMs = System.nanoTime() / 1_000_000L;
        in.hold(false);
        castHeld = false;
        diag.event("Paused");
        diag.stage = "Paused";
    }

    public void resume(long nowNs) {
        if (!running) return;
        long now = nowNs / 1_000_000L;
        if (paused) pausedTotalMs += now - pausedSinceMs;
        paused = false;
        autoPaused = false;
        lastFrameMs = now;
        diag.event("Resumed");
        sjPhase = 0;
        tracker.unlock();
        colorReel.unlock();
        enter(cfg.autoCast ? Stage.CAST : Stage.WAIT_BITE, now);
    }

    public void stop() {
        running = false;
        paused = false;
        castHeld = false;
        sjPhase = 0;
        in.hold(false);
        tracker.unlock();
        colorReel.unlock();
        stage = Stage.IDLE;
        diag.stage = "Idle";
        diag.event("Stopped");
    }

    /** Manual override: keep watching but send no inputs, so you can play yourself. */
    public void setManual(boolean m) {
        manual = m;
        if (m) in.hold(false);
        diag.event(m ? "Manual override ON" : "Manual override OFF");
    }

    /** Throw away the current lock and search the whole screen again. */
    public void recalibrate() {
        tracker.unlock();
        colorReel.unlock();
        lastSearchMs = 0;
        diag.researches++;
        diag.event("Recalibrating");
    }

    // ---- calibration: live check overlay and bar-response probe -------------------------------------

    /** Show what the vision sees (works while stopped, so you can check it on a reel you play yourself). */
    public volatile boolean checkMode;
    /** Keep a small live copy of the screen (with what was found drawn on it by the app's live view). */
    public volatile boolean liveView;
    private long lastThumbMs;
    /** Set to ask for one frozen, larger copy of the screen (for the Boxes editor); it appears in snap. */
    public volatile boolean snapRequest;
    public volatile ArrayFrame snap;

    private void makeSnap(Frame f) {
        int tw = Math.min(f.w, 720), th = Math.max(8, f.h * tw / Math.max(1, f.w));
        int[] px = new int[tw * th];
        for (int y = 0; y < th; y++) {
            int sy = Math.min(f.h - 1, y * f.h / th);
            for (int x = 0; x < tw; x++) px[y * tw + x] = f.rgb(Math.min(f.w - 1, x * f.w / tw), sy) & 0xFFFFFF;
        }
        snap = new ArrayFrame(tw, th, px);
    }

    private void makeThumb(Frame f, long now) {
        if (now - lastThumbMs < 200) return;
        lastThumbMs = now;
        int tw = 360, th = Math.max(8, f.h * tw / Math.max(1, f.w));
        int[] px = new int[tw * th];
        for (int y = 0; y < th; y++) {
            int sy = Math.min(f.h - 1, y * f.h / th);
            for (int x = 0; x < tw; x++) px[y * tw + x] = 0xFF000000 | f.rgb(Math.min(f.w - 1, x * f.w / tw), sy);
        }
        diag.thumbW = tw;
        diag.thumbH = th;
        diag.thumb = px;
    }
    /** Called when a probe has produced a model (so it can be saved). */
    public volatile Runnable onProbeDone;
    private volatile boolean probeActive;
    private long probeT0 = -1, probeLostMs;
    private int probeSeg = -1;
    private final java.util.ArrayList<double[]> probeS = new java.util.ArrayList<>();
    private final java.util.ArrayList<double[]> probeC = new java.util.ArrayList<>();
    /** Hold / release lengths in ms, alternating, starting with a hold. */
    private static final int[] PROBE_MS = {500, 500, 800, 600, 350, 500, 1000, 700};

    /**
     * Measure how this rod's bar answers the screen: scripted holds and releases while the bar is on screen, then fit the
     * response model to what was seen. Start it while a reel minigame is up.
     */
    public void startProbe() {
        probeActive = true;
        probeT0 = -1;
        probeSeg = -1;
        probeS.clear();
        probeC.clear();
        probeLostMs = 0;
        diag.event("Probe: hold and release the screen on a schedule to measure the bar (needs the reel minigame on screen)");
    }

    public boolean probing() { return probeActive; }

    private void publish(Frame f, ReelUi ui) {
        boolean pg = ui.hasProgress && !useColor;
        diag.vis = new double[] {ui.pillL, ui.pillT, ui.pillR, ui.pillB, meas.fishFound ? meas.fishX : -1, f.w, f.h,
                meas.conf, meas.fishFound ? meas.fishConf : 0, useColor ? 2 : 1,
                pg ? ui.progL : -1, pg ? ui.progT : -1, pg ? ui.progR : -1, pg ? ui.progB : -1,
                ui.trackL(), ui.trackR()};
    }

    private void publishController(Frame f, ReelUi ui, boolean hold) {
        boolean pg = ui.hasProgress && !useColor;
        double pw = Math.max(8, ui.pillW());
        diag.vis = new double[] {ui.pillL, ui.pillT, ui.pillR, ui.pillB, meas.fishFound ? meas.fishX : -1, f.w, f.h,
                meas.conf, meas.fishFound ? meas.fishConf : 0, useColor ? 2 : 1,
                pg ? ui.progL : -1, pg ? ui.progT : -1, pg ? ui.progR : -1, pg ? ui.progB : -1,
                ui.trackL(), ui.trackR(), ctl.fEst() * pw, meas.fishFound ? meas.fishConf : 0,
                ctl.barVel(), ctl.fishVel(), hold ? 1 : 0, ctl.lat * 1000.0, ctl.health};
    }

    /** Frame handling while the macro is stopped or paused: only the check overlay and the probe use it. */
    private void offFrame(Frame f, long nowNs, long now) {
        if (!checkMode && !probeActive) { diag.vis = null; return; }
        ReelTracker tk = trk();
        if (!tk.locked()) {
            diag.vis = null;
            if (now - lastSearchMs >= 120) {
                lastSearchMs = now;
                ReelUi ui = findReel(f, cfg.detectionTolerance);
                if (ui != null) {
                    useColor = pendingColor;
                    viaWhat = useColor ? "color" : "shape";
                    if (useColor) colorReel.lock(ui); else tracker.lock(ui);
                    diag.visNote = "";
                } else {
                    diag.visNote = String.format("No reel minigame found (best match %.0f%%)", diag.reelConf * 100);
                    if (probeActive && probeT0 < 0 && ++probeWait > 80) { probeActive = false; diag.event("Probe cancelled: no reel minigame was on screen"); }
                }
            }
            return;
        }
        trk().track(f, meas);
        if (!meas.ok) {
            if (probeActive && probeT0 >= 0) {
                if (probeLostMs == 0) probeLostMs = now;
                if (now - probeLostMs > 1200) { probeActive = false; in.hold(false); diag.event("Probe aborted: lost the bar"); }
            }
            if (trk().failStreak >= 6) { trk().unlock(); diag.vis = null; }
            return;
        }
        probeLostMs = 0;
        ReelUi ui = trk().model();
        diag.pillWidthPx = ui.pillW();
        publish(f, ui);
        diag.visNote = String.format("bar %.0f px (%s %.0f%%), fish %s", ui.pillW(), viaWhat, meas.conf * 100,
                meas.fishFound ? String.format("%.0f%%", meas.fishConf * 100) : "inside bar / hidden");
        if (probeActive) probeStep(now);
    }
    private int probeWait;

    private void probeStep(long now) {
        if (probeT0 < 0) { probeT0 = now; probeWait = 0; }
        double t = (now - probeT0) / 1000.0;
        double acc = 0;
        int seg = -1;
        for (int i = 0; i < PROBE_MS.length; i++) {
            acc += PROBE_MS[i] / 1000.0;
            if (t < acc) { seg = i; break; }
        }
        if (seg < 0) { finishProbe(); return; }
        if (seg != probeSeg) {
            probeSeg = seg;
            boolean h = seg % 2 == 0;
            in.hold(h);
            probeC.add(new double[] {t, h ? 1 : 0});
        }
        double pw = Math.max(8, meas.pillR - meas.pillL + 1);
        probeS.add(new double[] {t, (meas.pillL + meas.pillR + 1) * 0.5 / pw});
    }

    private void finishProbe() {
        probeActive = false;
        in.hold(false);
        double[] r = ProbeFit.fit(probeS, probeC, ctl.A, ctl.G, ctl.D, ctl.lat);
        if (r == null) {
            diag.event("Probe failed: the bar barely moved or the fit was poor. Keep the reel minigame on screen and try again");
            return;
        }
        ctl.A = r[0]; ctl.G = r[1]; ctl.D = r[2]; ctl.lat = r[3] + 0.02;
        fits.clear();
        diag.event(String.format("Probe done: bar speeds up %.1f, falls back %.1f, drag %.1f, delay %.0f ms (fit error %.2f bar widths)",
                r[0], r[1], r[2], r[3] * 1000, r[4]));
        Runnable cb = onProbeDone;
        if (cb != null) cb.run();
    }

    public boolean isRunning() { return running; }
    public boolean isPaused() { return paused; }
    public boolean isManual() { return manual; }
    public Stage stage() { return stage; }
    public double progress() { return progress; }
    public ReelTracker.Measure lastMeasure() { return meas; }
    public boolean wantsFastFrames() { return (running && !paused && stage == Stage.REEL) || probeActive; }

    private boolean canAct() { return running && !paused && !manual; }

    private void hold(boolean h) {
        in.hold(canAct() && h);
    }

    private void enter(Stage s, long now) {
        stage = s;
        stageStartMs = now;
        castHeld = false;
        diag.stage = s.name();
        if (s == Stage.WAIT_BITE) { watcher.reset(); autoTaps = 0; }
        if (s != Stage.REEL) diag.vis = null;
        if (s != Stage.WAIT_BITE) diag.detail = "";
        if (s == Stage.CAST || s == Stage.COOLDOWN || s == Stage.WAIT_BITE) hold(false);
    }

    // ---- frames --------------------------------------------------------------------------------

    public void onFrame(Frame f, long nowNs) {
        long now = nowNs / 1_000_000L;
        diag.clockMs = now;
        lastFrameMs = now;
        diag.frames++;
        if (liveView) makeThumb(f, now);
        if (snapRequest) { snapRequest = false; makeSnap(f); }
        if (!running || paused) { offFrame(f, nowNs, now); return; }
        long t0 = System.nanoTime();
        try {
            if (stage == Stage.WAIT_BITE) waitBite(f, now);
            else if (stage == Stage.REEL) reel(f, nowNs, now);
        } catch (RuntimeException e) {
            diag.event("vision error: " + e);
        }
        diag.procMsAvg = 0.9 * diag.procMsAvg + 0.1 * (System.nanoTime() - t0) / 1e6;
    }

    private void waitBite(Frame f, long now) {
        // 1. Is the reel minigame on screen? Look often, and get a little more forgiving the longer we wait.
        if (now - lastSearchMs >= 100) {
            lastSearchMs = now;
            diag.searches++;
            double tol = cfg.detectionTolerance * (1.0 + Math.min(0.3, (now - stageStartMs) / 40000.0));
            ReelUi ui = findReel(f, tol);
            if (ui != null) {
                diag.reelConf = ui.conf;
                startReel(ui, now);
                return;
            }
        }
        // 2. Shake prompt: a taught button if there is one, otherwise a new button-sized object that appears.
        if (cfg.autoShake && now - stageStartMs > 500) {
            float tx = -1, ty = -1;
            if (shake.has()) {
                if (now - lastShakeMs >= cfg.shakeGapMs) {
                    lastShakeMs = now;
                    ShakeFinder.Match mt = shake.find(f, (14.0 * cfg.detectionTolerance + 4) * Math.max(0.5, Math.min(2.0, cfg.shakeSens)));
                    diag.shakeConf = mt == null ? 0 : Math.max(0, 1.0 - mt.mad / 30.0);
                    if (mt != null) {
                        tx = (float) mt.cx / f.w;
                        ty = (float) mt.cy / f.h;
                        diag.shakeMark = new double[] {tx, ty, now};
                    }
                }
            } else {
                watcher.diff = (int) Math.round(34 / Math.max(0.5, Math.min(2.0, cfg.shakeSens)));
                ShakeWatcher.Hit h = watcher.update(f, now);
                diag.shakeConf = watcher.lastBlob > 0 ? Math.min(1.0, watcher.lastBlob / 0.06) : 0;
                if (h != null) {
                    tx = h.fx;
                    ty = h.fy;
                    diag.shakeMark = new double[] {tx, ty, now};
                }
            }
            if (tx >= 0 && canAct()) {
                in.tap(tx, ty);
                diag.shakeTaps++;
                autoTaps++;
                lastShakeMs = now + 60;
                diag.event(String.format("Shake tap at %.0f%%, %.0f%%", tx * 100, ty * 100));
            }
        }
        diag.detail = String.format("waiting %ds, shake taps %d, reel match %.0f%%",
                (now - stageStartMs) / 1000, autoTaps, diag.reelConf * 100);
    }

    /** After a reel: fit the bar's response to what happened and keep it. Falls back to live learning if it goes badly. */
    private void learnModel() {
        try {
            if (trFish > 10) {
                double r = (double) trIn / trFish;
                if (modelFrozen && r < 0.45) badReels++; else if (r >= 0.45) badReels = 0;
                if (badReels >= 2) {
                    modelFrozen = false;
                    ctl.learn = true;
                    fits.clear();
                    badReels = 0;
                    diag.event("Measured bar response did not work well: learning it live again");
                }
            }
            if (!cfg.autoModel || cfg.pulseMode || ctl.invert || mdS.size() < 60) return;
            // use the last ~8 s of the reel
            double tEnd = mdS.get(mdS.size() - 1)[0];
            java.util.ArrayList<double[]> s = new java.util.ArrayList<>();
            for (double[] p : mdS) if (p[0] >= tEnd - 8) s.add(p);
            double[] fit = ProbeFit.fit(s, mdC, ctl.A, ctl.G, ctl.D, Math.max(0.03, ctl.lat - 0.02));
            if (fit == null || fit[4] > 0.12) {
                diag.event(fit == null ? "Bar response fit skipped (bar barely moved or poor fit)" : String.format("Bar response fit too rough (%.2f)", fit[4]));
                return;
            }
            fits.add(fit);
            while (fits.size() > 3) fits.remove(0);
            double a = 0, g = 0, d = 0, l = 0;
            for (double[] x : fits) { a += x[0]; g += x[1]; d += x[2]; l += x[3]; }
            int n = fits.size();
            ctl.A = a / n; ctl.G = g / n; ctl.D = d / n; ctl.lat = l / n + 0.02;
            if (n >= 2 && !modelFrozen) {
                modelFrozen = true;
                ctl.learn = false;
                diag.event(String.format("Bar response measured and kept: speeds up %.1f, falls %.1f, drag %.1f, delay %.0f ms", ctl.A, ctl.G, ctl.D, ctl.lat * 1000));
            }
            Runnable cb = onProbeDone;
            if (modelFrozen && cb != null) cb.run();
        } catch (RuntimeException e) {
            diag.event("model fit error: " + e);
        }
    }

    private void startReel(ReelUi ui, long now) {
        noBites = 0;
        useColor = pendingColor;
        viaWhat = useColor ? "color" : "shape";
        if (useColor) colorReel.lock(ui); else tracker.lock(ui);
        reelStartMs = now;
        trace.setLength(0);
        trN = trIn = trFish = trFlips = 0;
        trLastHold = false;
        ctl.reset();
        mdS.clear();
        mdC.clear();
        mdHold = false;
        sj.reset();
        sjPhase = 0;
        sjTries = 0;
        stunUntilMs = 0;
        progress = -1;
        maxProgress = 0;
        lastHighMs = -100000;
        doneStreak = 0;
        lowConf = 0;
        lastGoodMs = now;
        diag.pillWidthPx = ui.pillW();
        diag.pillHeightPx = ui.pillH();
        diag.event(String.format("Reel found by %s (conf %.2f, bar %.0fpx)", viaWhat, ui.conf, ui.pillW()));
        enter(Stage.REEL, now);
    }

    private void reel(Frame f, long nowNs, long now) {
        if (!trk().locked()) {
            relock(f, now, "lost");
            if (now - lastGoodMs > 1500) finishReel(nearEnd(now), now);
            return;
        }
        trk().track(f, meas);
        diag.reelConf = meas.conf;
        diag.fishConf = meas.fishFound ? meas.fishConf : 0;
        if (meas.ok) {
            lastGoodMs = now;
            ReelUi ui = trk().model();
            diag.pillWidthPx = ui.pillW();
            diag.pillHeightPx = ui.pillH();
            if (meas.progressOk) {
                progress = meas.progress;
                maxProgress = Math.max(maxProgress, progress);
                if (progress >= 0.8) lastHighMs = now;
                diag.progress = progress;
                diag.progressConf = meas.progressConf;
            }
            publish(f, ui);
            if (probeActive) { probeStep(now); return; }
            boolean stunned = now < stunUntilMs;
            ctl.pulseMode = cfg.pulseMode;
            ctl.minFlip = cfg.holdMinMs / 1000.0;
            ctl.MAX_PULSE = cfg.pulseMaxMs / 1000.0;
            ctl.MIN_GAP = cfg.pulseGapMs / 1000.0;
            ctl.MIN_PULSE = cfg.pulseMinMs / 1000.0;
            boolean h = ctl.update(meas, ui, nowNs, cfg.sensitivity, stunned);
            // Publish the controller's internal prediction alongside the raw vision result. This lets
            // the live overlay distinguish what the camera actually detected from what the controller
            // is predicting while the fish is occluded by the bar.
            publishController(f, ui, h);
            if (!cfg.pulseMode && mdS.size() < 3000) {
                double tt = (now - reelStartMs) / 1000.0;
                if (h != mdHold || mdC.isEmpty()) { mdC.add(new double[] {tt, h ? 1 : 0}); mdHold = h; }
                double pwd = Math.max(8, ui.pillW());
                mdS.add(new double[] {tt, (ui.pillL + ui.pillR + 1) * 0.5 / pwd});
            }
            diag.modelA = ctl.A;
            diag.modelG = ctl.G;
            diag.modelD = ctl.D;
            diag.latencyMs = ctl.lat * 1000;
            diag.inputInverted = ctl.invert;
            diag.inputHealth = ctl.health;
            {
                // the fish marker is only detectable while it is outside the bar, so "not seen" counts as inside
                double ctr = (ui.pillL + ui.pillR) * 0.5;
                boolean inb = !meas.fishFound || Math.abs(meas.fishX - ctr) <= ui.pillW() / 2;
                inBarEma = 0.97 * inBarEma + 0.03 * (inb ? 1 : 0);
                trFish++;
                if (inb) trIn++;
                if (h != trLastHold) { trFlips++; trLastHold = h; }
                if (trN++ % 3 == 0 && trace.length() < 60000)
                    trace.append(String.format("%.2f,%.0f,%s,%d,%d\n", (now - reelStartMs) / 1000.0, ctr,
                            meas.fishFound ? String.format("%.0f", meas.fishX) : "hidden", h ? 1 : 0, inb ? 1 : 0));
                diag.detail = String.format("%s %s, %s, in bar %.0f%%", viaWhat, h ? "HOLD" : "release",
                        meas.fishFound ? String.format("fish %+.0f%% of bar", 100 * (meas.fishX - ctr) / ui.pillW()) : "fish inside bar",
                        inBarEma * 100);
            }
            if (ctl.needReset) {
                ctl.needReset = false;
                diag.recoveries++;
                diag.event("Presses not reaching the game: re-sending touch");
                in.resetInput();
            }
            if (sjPhase == 0 && cfg.autoReel && cfg.pulseMode) {
                int ms = ctl.takePulse();
                if (ms > 0 && canAct()) in.pulse(ms);
            } else if (sjPhase == 0 && cfg.autoReel) hold(h);
            else if (sjPhase == 0) in.hold(false);

            // automatic recalibration: low confidence for a while, or the UI changed size/position
            if (meas.conf < 0.5) lowConf++; else lowConf = 0;
            if ((lowConf >= 12 || trk().geometryChanged) && now - lastSearchMs >= 500) {
                trk().geometryChanged = false;
                lowConf = 0;
                relock(f, now, "low confidence or resize");
            }
            if (cfg.soulJudgement) handleSoul(f, ui, now);

            if (progress >= 0.99) {
                if (++doneStreak >= 4) finishReel(true, now);
            } else doneStreak = 0;
        } else {
            if (now - lastGoodMs > 350) in.hold(false);
            if (trk().failStreak >= 6) relock(f, now, "lost");
            if (now - lastGoodMs > (nearEnd(now) ? 500 : 1500)) finishReel(nearEnd(now), now);
        }
    }

    private boolean nearEnd(long now) {
        // a landed Soul Judgement adds ~55%, so a reel that ended soon after one was almost surely caught
        if (useColor && !colorReel.profile.hasProg) return now - reelStartMs >= 2500; // no progress meter in colour mode: a reel that ran a while and then ended counts as caught
        return progress >= 0.4 || now - lastHighMs < 2500 || (progress >= 0.25 && now - lastSoulMs < 10000);
    }

    private void relock(Frame f, long now, String why) {
        if (now - lastSearchMs < 200) return;
        lastSearchMs = now;
        diag.researches++;
        ReelUi ui = findReel(f, cfg.detectionTolerance);
        if (ui != null) {
            ReelUi cur = trk().model();
            if (cur != null && meas.ok && (ui.pillW() < 0.7 * cur.pillW() || ui.pillW() > 1.4 * cur.pillW())
                    && !"lost".equals(why)) {
                diag.event(String.format("Ignored odd re-lock candidate (%.0f px vs %.0f px)", ui.pillW(), cur.pillW()));
                return;
            }
            useColor = pendingColor;
            if (useColor) colorReel.lock(ui); else tracker.lock(ui);
            lastGoodMs = now;
            diag.event(String.format("Reel re-locked [%s] (conf %.2f)", why, ui.conf));
        }
    }

    private void finishReel(boolean caught, long now) {
        diag.vis = null;
        learnModel();
        if (trFish > 10) {
            double secs = (now - reelStartMs) / 1000.0;
            String sum = String.format("Reel %.1fs via %s: fish in bar %.0f%%, %d hold/release switches (%.1f/s), model A=%.1f G=%.1f D=%.1f lat=%.0fms, result %s",
                    secs, viaWhat, 100.0 * trIn / trFish, trFlips, trFlips / Math.max(0.1, secs), ctl.A, ctl.G, ctl.D, ctl.lat * 1000, caught ? "caught" : "lost");
            diag.event(sum);
            lastReelTrace = sum + "\nt_s,bar_centre_px,fish_px,hold,in_bar\n" + trace;
            trFish = 0;
        }
        in.hold(false);
        tracker.unlock();
        colorReel.unlock();
        sjPhase = 0;
        if (caught) {
            diag.catches++;
            diag.event("Caught a fish");
        } else {
            diag.escapes++;
            diag.event("Fish escaped / reel lost");
        }
        enter(Stage.COOLDOWN, now);
    }

    // ---- Soul Judgement -----------------------------------------------------------------------

    private void handleSoul(Frame f, ReelUi ui, long now) {
        if (sjPhase == 1) {
            if (now >= sjAtMs) {
                if (canAct()) in.tap(sjFx, sjFy);
                sjPhase = 2;
                sjAtMs = now + 1300;
                sjTries++;
                lastSjMs = now;
                sjMissing = 0;
            }
            return;
        }
        if (now - lastSjMs < 150) return;
        lastSjMs = now;
        SoulJudgement.Target t = sj.find(f, ui.pillT, cfg.detectionTolerance);
        diag.sjConf = t == null ? 0 : t.conf;
        if (t != null) diag.soulMark = new double[] {t.cx / f.w, t.cy / f.h, now};
        if (sjPhase == 0) {
            if (t != null && sj.ready(t, now)) {
                if (!canAct()) return;
                sjFx = (float) (t.cx / f.w);
                sjFy = (float) (t.cy / f.h);
                sjPre = progress;
                sjPhase = 1;
                sjAtMs = now + 90;
                in.hold(false);
                diag.event("Soul Judgement ready: tapping centre");
            } else if (t == null) {
                sj.ready(null, now);
            }
        } else if (sjPhase == 2) {
            if (t == null) sjMissing++; else sjMissing = 0;
            boolean jump = progress >= 0 && sjPre >= 0 && progress - sjPre >= 0.2;
            if (jump || sjMissing >= 2) {
                stunUntilMs = now + 4000;
                lastSoulMs = now;
                sj.fired(now);
                diag.soulCount++;
                diag.event(String.format("Soul Judgement landed%s; fish stunned 4s",
                        jump ? String.format(" (+%.0f%% progress)", (progress - sjPre) * 100) : ""));
                sjPhase = 0;
                sjTries = 0;
            } else if (now >= sjAtMs) {
                if (sjTries < 3) {
                    sjPhase = 1;
                    sjAtMs = now + 90;
                    diag.event("Soul Judgement tap not confirmed: retrying");
                } else {
                    sj.fired(now);
                    sjPhase = 0;
                    sjTries = 0;
                    diag.event("Soul Judgement gave up after 3 taps");
                }
            }
        }
    }

    // ---- clock ---------------------------------------------------------------------------------

    public void tick(long nowNs) {
        long now = nowNs / 1_000_000L;
        if (!running || paused) return;
        updateStats(now);
        if (stage != Stage.REEL) {
            if (cfg.stopAfterCatches > 0 && diag.catches - baseCatches >= cfg.stopAfterCatches) { stopSelf("Reached " + cfg.stopAfterCatches + " catches"); return; }
            if (cfg.stopAfterMin > 0 && now - sessionStartMs - pausedTotalMs >= cfg.stopAfterMin * 60_000L) { stopSelf("Ran for " + cfg.stopAfterMin + " minutes"); return; }
        }
        if (now - lastFrameMs > 2500) {
            in.hold(false);
            if (now - lastStaleMs > 5000) {
                lastStaleMs = now;
                diag.event("No screen frames for 2.5 s");
            }
            return;
        }
        switch (stage) {
            case CAST:
                if (!castHeld) {
                    if (now - stageStartMs >= cfg.stageSettleMs && canAct()) {
                        castHeld = true;
                        castAtMs = now;
                        castAskMs = cfg.castHoldMs + (cfg.castJitterMs > 0 ? rnd.nextInt(cfg.castJitterMs + 1) : 0);
                        in.pressFor(castAskMs);
                    }
                } else {
                    int ps = in.pressState();
                    if (ps == 1) {
                        long real = in.pressMeasuredMs();
                        castHeld = false;
                        diag.casts++;
                        castFails = 0;
                        diag.event("Cast: held " + real + " ms (asked " + castAskMs + ")");
                        if (real < castAskMs * 0.8) diag.event("Warning: the press ended early; raise the cast hold time");
                        enter(Stage.WAIT_BITE, now);
                    } else if (ps < 0 || now - castAtMs > castAskMs + 2000) {
                        castHeld = false;
                        in.resetInput();
                        castFails++;
                        diag.recoveries++;
                        diag.event("Cast press was not completed by Android (" + castFails + "); trying again");
                        stageStartMs = now + 600;
                    }
                }
                break;
            case WAIT_BITE:
                if (now - stageStartMs > cfg.biteTimeoutMs) {
                    diag.recoveries++;
                    noBites++;
                    if (cfg.maxNoBites > 0 && noBites >= cfg.maxNoBites) {
                        stopSelf(noBites + " casts in a row with no bite. Is the rod equipped, and are you standing at water?");
                        break;
                    }
                    diag.event("No bite or shake: casting again (" + noBites + " in a row)");
                    enter(cfg.autoCast ? Stage.CAST : Stage.WAIT_BITE, now);
                }
                break;
            case COOLDOWN:
                if (now - stageStartMs >= cfg.cooldownMs) enter(cfg.autoCast ? Stage.CAST : Stage.WAIT_BITE, now);
                break;
            case REEL:
                if (now - stageStartMs > cfg.maxReelSec * 1000L) {
                    diag.recoveries++;
                    diag.event("Reel took over " + cfg.maxReelSec + " s: resetting");
                    finishReel(false, now);
                }
                break;
            default:
                break;
        }
    }
}
